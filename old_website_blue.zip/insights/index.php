<?php
if(!isset($_SESSION)){session_start();}

  if(isset($_POST)):

    require_once('./model/db.php');
    require_once('./model/user.php');

    if(isset($_POST['action']) AND $_POST['action'] == 'login')
    {
      if(User::login($sql, $_POST['email'], $_POST['password']))
      {
        $_SESSION['email'] = $_POST['email'];
        $_SESSION['firstname'] = User::firstname($sql, $_POST['email']);
        header('Location: ./');
        die();
      }
      else
        $error_login = true;
    }
    else if(isset($_POST['action']) AND $_POST['action'] == 'signup')
    {
      if(User::signup($sql, $_POST['name'], $_POST['company'], $_POST['email'], $_POST['password']))
      {
        $_SESSION['email'] = $_POST['email'];
        $_SESSION['firstname'] = User::firstname($sql, $_POST['email']);
        header('Location: ./');
        die();
      }
      else
        $error_signup = true;
    }

  endif;

  if(isset($_GET)):

    if(isset($_GET['logout']))
      session_unset();

  endif;

?>
  <!DOCTYPE html>
	<html lang="pt-br" class="no-js">
	<head>
		<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
		<link rel="shortcut icon" href="img/fav.png">
		<meta name="description" content="">
		<meta charset="UTF-8">
		<title>Blue A.I. | Insights</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.7.2/css/all.min.css">
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jqueryui/1.12.1/jquery-ui.min.js"></script>
    <link rel="stylesheet" href="css/linearicons.css">
    <link rel="stylesheet" href="css/bootstrap.css">
    <link rel="stylesheet" href="css/main.css?v=1.0">
    <link rel="stylesheet" href="css/login.css">
		</head>
		<body>

		<header class="default-header">
			<div class="container">
				<div class="header-wrap">
					<div class="header-top d-flex justify-content-between align-items-center">
						<div class="logo">
							<a href="./" style="text-decoration: none;"><img src="img/blue-logo.png" height="30"> <span style="font-weight:400; color:#004085; font-size:19px; vertical-align: bottom; top: 3px; left: 8px; position: relative;"> Insights</span></a>
						</div>
						<div class="main-menubar d-flex align-items-center">
							<nav class="hide">
								<a href="../">Início</a>
                <a href="./">Insights</a>
              <?php if(isset($_SESSION['email'])): ?>
                <a href="./?logout">Sair</a>
              <?php endif; ?>
							</nav>
							<div class="menu-bar"><span class="lnr lnr-menu"></span></div>
						</div>
					</div>
				</div>
			</div>
		</header>

<?php

      //PAGINA DE LOGIN E CADASTRO
      if(!isset($_SESSION['email'])):

?>
      <div class="container" id="container">

        <div class="form-container sign-in-container">
      		<form action="./" method="post">
      			<h1>Login</h1>
            <?php if(isset($error_login)): ?>
              <br>
              <div class="alert alert-warning">
                <strong>Aviso!</strong> Email ou senha incorretos.
              </div>
            <?php endif; ?>
      			<div class="social-container">
      			</div>
      			<span></span>
      			<input type="email" name="email" placeholder="Email" />
      			<input type="password" name="password" placeholder="Senha" />
            <input type="hidden" name="action" value="login" />
      			<a href="#">Esqueceu sua senha?</a>
            <br />
      			<button>Entrar</button>
      		</form>
      	</div>
      	<div class="form-container sign-up-container">
      		<form action="./" method="post">
      			<h1>Criar Conta</h1>
            <?php if(isset($error_signup)): ?>
              <br>
              <div class="alert alert-warning">
                <strong>Aviso!</strong> Email já cadastrado.
              </div>
            <?php endif; ?>
      			<div class="social-container">
      			</div>
      			<span></span>
      			<input type="text" name="name" placeholder="Nome" required/>
            <input type="text" name="company" placeholder="Empresa" required/>
      			<input type="email" name="email" placeholder="Email" required/>
      			<input type="password" name="password" placeholder="Senha" minlength="8" required/>
            <input type="hidden" name="action" value="signup" />
            <br />
      			<button>Cadastrar</button>
      		</form>
      	</div>
      	<div class="overlay-container">
      		<div class="overlay">
      			<div class="overlay-panel overlay-left">
      				<h1>Já tem conta?</h1>
      				<p>Para manter-se conectado conosco, faça o login com suas informações</p>
      				<button class="ghost" id="signIn">Login</button>
      			</div>
      			<div class="overlay-panel overlay-right">
      				<h1>Cadastre-se!</h1>
      				<p>Insira seus dados e inicie sua jornada conosco gratuitamente</p>
      				<button class="ghost" id="signUp">Crie Sua Conta</button>
      			</div>
      		</div>
      	</div>
      </div>

<?php

      //PAINEL DO BLUE INSIGHTS
      else:

?>
      <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/leaflet@1.4.0/dist/leaflet.css"/>
      <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/Leaflet.awesome-markers/2.0.2/leaflet.awesome-markers.css"/>
      <link rel="stylesheet" href="https://rawcdn.githack.com/python-visualization/folium/master/folium/templates/leaflet.awesome.rotate.css"/>
      <script src="https://cdn.jsdelivr.net/npm/leaflet@1.4.0/dist/leaflet.js"></script>
      <script src="js/heatmap.js"></script>
      <script src="js/leaflet-heatmap.js"></script>
      <script src="https://cdnjs.cloudflare.com/ajax/libs/Leaflet.awesome-markers/2.0.2/leaflet.awesome-markers.js"></script>
      <script src="https://cdnjs.cloudflare.com/ajax/libs/modernizr/2.8.3/modernizr.min.js"></script>
      <script src="js/checkbox.js"></script>

      <div id="floatcontrol">
        <div class="container">
          <div class="row">
            <b>Painel de Controle:</b>
            <div class="radio">
              <input type="radio" name="radio1" id="radio1" checked>
              <label for="radio1">Dados de <u id="ano" style="text-decoration:none">2017</u></label>
            </div>
            <br>
            Doenças Crônicas:  
            <div class="checkbox">
              <input type="checkbox" id="checkbox1" checked>
              <label for="checkbox1">Diabéticos</label>
            </div>
            <div class="checkbox">
              <input type="checkbox" id="checkbox2">
              <label for="checkbox2">Hipertensos</label>
            </div>
          <br>
          Base de Dados:  
          <div class="radio">
            <input type="radio" name="radio2" id="radio2" checked>
            <label for="radio2">Vigitel</label>
          </div>
          </div>
        </div>
      </div>

      <div id="futuro" class="alert alert-info" style="position:absolute; right:0px; margin-top:10px; z-index: 999; display:none">
          Você ativou a Proxy de <b>Risco Futuro</b> da Blue Insights.<br>Utilizamos Machine Learning para prever a incidência das DCNTs nos próximos 5 anos. <i>Funcionalidade em modo beta.</i>
          <!--<button type="button" class="close" data-dismiss="alert">×</button>-->
      </div>
    

      <div class="folium-map" id="map"></div>

      <div class="slider-wrapper">
        <div class="wrap" id="slider">
        <div id="range-selector" class="ui-slider-handle"></div>
        </div>
      </div>

      <script>

        var anoglobal = 2017;

        jQuery(function(){
          initRangeSlider();
          
        });

        function initRangeSlider() {
          var handle = $("#range-selector");
          $('#slider').slider({
            min: 2006,
            max: 2022,
            value: 2017,
            create: function(){
              handle.text($(this).slider("value"));
            },
            slide : function(event, ui) {
              handle.text(ui.value);
              anoglobal = ui.value;
              $('#ano').html(ui.value);
              if(ui.value >= 2019)
                $('#futuro').fadeIn();
              else
                $('#futuro').fadeOut();

              if($('#checkbox1').is(':checked') && $('#checkbox2').is(':checked'))
              {
                heatmapLayer.setData(heat_map_hipdiab[anoglobal]);
                tabela = heat_map_hipdiab[anoglobal].data;
                mudarTabela(tabela);
              }
              else if($('#checkbox1').is(':checked'))
              {
                heatmapLayer.setData(heat_map_diabeticos[anoglobal]);
                tabela = heat_map_diabeticos[anoglobal].data;
                mudarTabela(tabela);
              }
              else if($('#checkbox2').is(':checked'))
              {
                heatmapLayer.setData(heat_map_hipertensos[anoglobal]);
                tabela = heat_map_hipertensos[anoglobal].data;
                mudarTabela(tabela);
              }
              else
              {
                heatmapLayer.setData(heat_map_null);
                tabela = {};
                mudarTabela(tabela);
              }


              console.log('oi');
            }
          });
        }

      </script>


      <div id="barra-lateral">
        <div class="container">
          <div class="row">
            <small>Análise ML da Blue Insights<br>Margem de Erro: ± 5%</small><br><br>
            <table class="table-bordered">

            </table><br>
          </div>
        </div>
      </div>


      <script>

      var heat_map_diabeticos = [];
      var heat_map_hipertensos = [];
      var heat_map_hipdiab = [];
      var tabela = {};

      <?php 
      for($year = 2006; $year <= 2022; $year++) {

        $jsondiab = file_get_contents('./JSONS/diabPerCity'.$year.'.json');
        $jsonhip = file_get_contents('./JSONS/hipPerCity'.$year.'.json');

        $jsondiab = substr($jsondiab, 1, -1);
        $jsonhip = substr($jsonhip, 1, -1);

        echo 'heat_map_diabeticos["'.$year.'"] = {data: ['.$jsondiab.']};';
        echo 'heat_map_hipertensos["'.$year.'"] = {data: ['.$jsonhip.']};';
        echo 'heat_map_hipdiab["'.$year.'"] = {data: ['.$jsonhip.','.$jsondiab.']};';

      }
      ?>

      heat_map_diabeticos['2017'] = {
          data: [{lat: -10.9162061, long: -37.0774655, count: 11.012345679012348}, {lat: -1.45056, long: -48.4682453, count: 9.270833333333334}, {lat: -19.9227318, long: -43.9450948, count: 11.603585657370518}, {lat: 2.8208478, long: -60.671958200000006, count: 8.18399044205496}, {lat: -20.464017300000002, long: -54.616294700000005, count: 14.271653543307087}, {lat: -15.598668599999998, long: -56.099130099999996, count: 12.290227048371177}, {lat: -25.4295963, long: -49.2712724, count: 13.475521085797384}, {lat: -27.5973002, long: -48.5496098, count: 11.472081218274115}, {lat: -3.7304512, long: -38.5217989, count: 11.297483966452885}, {lat: -16.680882, long: -49.2532691, count: 13.28125}, {lat: -7.1215981, long: -34.882028000000005, count: 12.312166747455162}, {lat: 0.0401529, long: -51.0569588, count: 8.96455872133426}, {lat: -9.647684300000002, long: -35.733926399999994, count: 13.375486381322956}, {lat: -3.1316333, long: -59.9825041, count: 10.085054678007289}, {lat: -5.805398, long: -35.208090500000004, count: 11.050545094152627}, {lat: -10.183560400000001, long: -48.333779299999996, count: 6.763285024154589}, {lat: -30.0324999, long: -51.23037670000001, count: 12.433478471214324}, {lat: -8.7494525, long: -63.87354379999999, count: 9.588299024918745}, {lat: -8.064193099999999, long: -34.878151700000004, count: 11.98246468582562}, {lat: -9.9765362, long: -67.82207779999999, count: 8.956854178044782}, {lat: -22.911013699999998, long: -43.2093727, count: 14.82028557360906}, {lat: -12.982249900000001, long: -38.48127720000001, count: 10.888671875}, {lat: -2.5319224, long: -44.2933276, count: 9.70258410531448}, {lat: -23.5506507, long: -46.633382399999995, count: 11.336633663366337}, {lat: -5.0896403, long: -42.809588, count: 8.672219500244978}, {lat: -20.3200917, long: -40.3376682, count: 13.284671532846716}, {lat: -15.7754462, long: -47.7970891, count: 10.912906610703043}]
          };

      heat_map_hipertensos['2017'] = {
        data: [{lat:-10.9162061,long:-37.0774655,count:35.6543209877},{lat:-1.45056,long:-48.4682453,count:30.5208333333},{lat:-19.9227318,long:-43.9450948,count:34.7609561753},{lat:2.8208478,long:-60.6719582,count:27.0609318996},{lat:-20.4640173,long:-54.6162947,count:41.6830708661},{lat:-15.5986686,long:-56.0991301,count:41.362290227},{lat:-25.4295963,long:-49.2712724,count:39.4571013088},{lat:-27.5973002,long:-48.5496098,count:38.730964467},{lat:-3.7304512,long:-38.5217989,count:30.044400592},{lat:-16.680882,long:-49.2532691,count:41.69921875},{lat:-7.1215981,long:-34.882028,count:35.8216190015},{lat:0.0401529,long:-51.0569588,count:30.7852675469},{lat:-9.6476843,long:-35.7339264,count:38.7159533074},{lat:-3.1316333,long:-59.9825041,count:30.4374240583},{lat:-5.805398,long:-35.2080905,count:36.4222001982},{lat:-10.1835604,long:-48.3337793,count:24.5410628019},{lat:-30.0324999,long:-51.2303767,count:40.9288824383},{lat:-8.7494525,long:-63.8735438,count:29.8483206934},{lat:-8.0641931,long:-34.8781517,count:36.8241597662},{lat:-9.9765362,long:-67.8220778,count:31.1851447297},{lat:-22.9110137,long:-43.2093727,count:45.0516986706},{lat:-12.9822499,long:-38.4812772,count:38.720703125},{lat:-2.5319224,long:-44.2933276,count:28.5226718674},{lat:-23.5506507,long:-46.6333824,count:32.3267326733},{lat:-5.0896403,long:-42.809588,count:31.7001469868},{lat:-20.3200917,long:-40.3376682,count:38.296836983},{lat:-15.7754462,long:-47.7970891,count:33.4732423924}]
      };

      heat_map_hipdiab['2017'] = {
        data: [{lat:-10.9162061,long:-37.0774655,count:35.6543209877},{lat:-1.45056,long:-48.4682453,count:30.5208333333},{lat:-19.9227318,long:-43.9450948,count:34.7609561753},{lat:2.8208478,long:-60.6719582,count:27.0609318996},{lat:-20.4640173,long:-54.6162947,count:41.6830708661},{lat:-15.5986686,long:-56.0991301,count:41.362290227},{lat:-25.4295963,long:-49.2712724,count:39.4571013088},{lat:-27.5973002,long:-48.5496098,count:38.730964467},{lat:-3.7304512,long:-38.5217989,count:30.044400592},{lat:-16.680882,long:-49.2532691,count:41.69921875},{lat:-7.1215981,long:-34.882028,count:35.8216190015},{lat:0.0401529,long:-51.0569588,count:30.7852675469},{lat:-9.6476843,long:-35.7339264,count:38.7159533074},{lat:-3.1316333,long:-59.9825041,count:30.4374240583},{lat:-5.805398,long:-35.2080905,count:36.4222001982},{lat:-10.1835604,long:-48.3337793,count:24.5410628019},{lat:-30.0324999,long:-51.2303767,count:40.9288824383},{lat:-8.7494525,long:-63.8735438,count:29.8483206934},{lat:-8.0641931,long:-34.8781517,count:36.8241597662},{lat:-9.9765362,long:-67.8220778,count:31.1851447297},{lat:-22.9110137,long:-43.2093727,count:45.0516986706},{lat:-12.9822499,long:-38.4812772,count:38.720703125},{lat:-2.5319224,long:-44.2933276,count:28.5226718674},{lat:-23.5506507,long:-46.6333824,count:32.3267326733},{lat:-5.0896403,long:-42.809588,count:31.7001469868},{lat:-20.3200917,long:-40.3376682,count:38.296836983},{lat:-15.7754462,long:-47.7970891,count:33.4732423924},{lat: -10.9162061, long: -37.0774655, count: 11.012345679012348}, {lat: -1.45056, long: -48.4682453, count: 9.270833333333334}, {lat: -19.9227318, long: -43.9450948, count: 11.603585657370518}, {lat: 2.8208478, long: -60.671958200000006, count: 8.18399044205496}, {lat: -20.464017300000002, long: -54.616294700000005, count: 14.271653543307087}, {lat: -15.598668599999998, long: -56.099130099999996, count: 12.290227048371177}, {lat: -25.4295963, long: -49.2712724, count: 13.475521085797384}, {lat: -27.5973002, long: -48.5496098, count: 11.472081218274115}, {lat: -3.7304512, long: -38.5217989, count: 11.297483966452885}, {lat: -16.680882, long: -49.2532691, count: 13.28125}, {lat: -7.1215981, long: -34.882028000000005, count: 12.312166747455162}, {lat: 0.0401529, long: -51.0569588, count: 8.96455872133426}, {lat: -9.647684300000002, long: -35.733926399999994, count: 13.375486381322956}, {lat: -3.1316333, long: -59.9825041, count: 10.085054678007289}, {lat: -5.805398, long: -35.208090500000004, count: 11.050545094152627}, {lat: -10.183560400000001, long: -48.333779299999996, count: 6.763285024154589}, {lat: -30.0324999, long: -51.23037670000001, count: 12.433478471214324}, {lat: -8.7494525, long: -63.87354379999999, count: 9.588299024918745}, {lat: -8.064193099999999, long: -34.878151700000004, count: 11.98246468582562}, {lat: -9.9765362, long: -67.82207779999999, count: 8.956854178044782}, {lat: -22.911013699999998, long: -43.2093727, count: 14.82028557360906}, {lat: -12.982249900000001, long: -38.48127720000001, count: 10.888671875}, {lat: -2.5319224, long: -44.2933276, count: 9.70258410531448}, {lat: -23.5506507, long: -46.633382399999995, count: 11.336633663366337}, {lat: -5.0896403, long: -42.809588, count: 8.672219500244978}, {lat: -20.3200917, long: -40.3376682, count: 13.284671532846716}, {lat: -15.7754462, long: -47.7970891, count: 10.912906610703043}]
      };

      var heat_map_null = {
        max: 1000000000000000,
        data: [{lat: 82.8628, long: 135.0000, count: 0}]
      };

      var baseLayer = L.tileLayer(
          "https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png",
          {"attribution": "Data by \u0026copy; \u003ca href=\"http://openstreetmap.org\"\u003eOpenStreetMap\u003c/a\u003e, under \u003ca href=\"http://www.openstreetmap.org/copyright\"\u003eODbL\u003c/a\u003e.", "detectRetina": false, "maxNativeZoom": 15, "maxZoom": 15, "minZoom": 3, "noWrap": false, "opacity": 1, "subdomains": "abc", "tms": false}
      );

      var cfg = {
        // radius should be small ONLY if scaleRadius is true (or small radius is intended)
        // if scaleRadius is false it will be the constant radius used in pixels
        "radius": 1.7,
        "blur": .75,
        "maxOpacity": .5, 
        // scales the radius based on map zoom
        "scaleRadius": true, 
        // if set to false the heatmap uses the global maximum for colorization
        // if activated: uses the data maximum within the current map boundaries 
        //   (there will always be a red spot with useLocalExtremas true)
        "useLocalExtrema": true,
        // which field name in your data represents the latitude - default "lat"
        latField: 'lat',
        // which field name in your data represents the longitude - default "lng"
        lngField: 'long',
        // which field name in your data represents the data value - default "value"
        valueField: 'count'
      };

      var heatmapLayer = new HeatmapOverlay(cfg);

      var map = L.map(
          "map",
          {
              center: [-15.77, -55.92],
              zoom: 4,
              zoomControl: true,
              preferCanvas: true,
              layers: [baseLayer, heatmapLayer]
          }
      );

      heatmapLayer.setData(heat_map_diabeticos['2017']);

      </script>

<?php
  
      endif;
?>

      <footer>
        <p>
          Copyright &copy; <script>document.write(new Date().getFullYear());</script> All rights reserved - Blue A.I. | Insights - Versão beta <img src="img/fav.png" height="10">
        </p>
      </footer>

    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.11.0/umd/popper.min.js" integrity="sha384-b/U6ypiBEHpOf/4+1nzFpr53nxSS+GLCkfwBdFNTxtclqqenISfwAzpKaMNFNmj4" crossorigin="anonymous"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/jquery.nice-select.min.js"></script>
    <script src="js/jquery.sticky.js"></script>
    <script src="js/jquery.counterup.min.js"></script>
    <script src="js/main.js?v=1.0"></script>
    <script type="text/javascript" src="js/login.js"></script>

<?php if(isset($error_signup)): ?>
    <script>container.classList.add("right-panel-active");</script>
<?php endif; ?>
    <!-- https://codepen.io/FlorinPop17/full/vPKWjd -->
		</body>
	</html>
