<?php 

//TODO: CRIAR VALIDADOR DE EMAIL E PASSWORD NO BACKEND

class User
{

	public static function firstname($sql, $email)
	{
		$pdo = $sql->prepare('SELECT name FROM bi_users WHERE email = ?'); 
		$pdo->bindParam(1, $email);
		$pdo->execute(); 

		$user = $pdo->fetch();
		$firstname = explode(' ', $user['name']);

		return $firstname[0];
	}

	public static function login($sql, $email, $password)
	{
		$pdo = $sql->prepare('SELECT * FROM bi_users WHERE email = ?'); 
		$pdo->bindParam(1, $email);
		$pdo->execute(); 

		$user = $pdo->fetch();

		if($user AND password_verify($password, $user['password']))
			return true;
		else
			return false;
	}

	public static function signup($sql, $name, $company, $email, $password)
	{
		$pdo = $sql->prepare('INSERT INTO bi_users (name, company, email, password) VALUES (?, ?, ?, ?)'); 

		$password = password_hash($password, PASSWORD_DEFAULT);

		$pdo->bindParam(1, $name);
		$pdo->bindParam(2, $company);
		$pdo->bindParam(3, $email);
		$pdo->bindParam(4, $password);
		$pdo->execute(); 

		if($pdo->errorCode() == '00000')
			return true;
		else
			return false;
	}

}