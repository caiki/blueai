<?php

date_default_timezone_set('America/Sao_Paulo');

//CRIA CONEXÃO GLOBAL COM O BANCO DE DADOS
$sql = new PDO('mysql:host=177.85.98.242:3306;dbname=blueaico_insights;charset=utf8', 'blueaico_admin', 'hiWkzbTTEigZm3c');