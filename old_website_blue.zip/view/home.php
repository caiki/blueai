			<!-- Start Header Area -->
			<header class="default-header">
				<div class="container">
					<div class="header-wrap">
						<div class="header-top d-flex justify-content-between align-items-center">
							<div class="logo">
								<a href="#home"><img src="img/blue-logo.png" alt="" height="30"></a>
							</div>
							<div class="main-menubar d-flex align-items-center">
								<nav class="hide">
									<a href="#home">Início</a>
									<a href="./insights">Insights</a>
									<a href="https://blueai.com.br/app/">Serviços</a>
									<a href="#appoinment">Contato</a>
									<a href="#consultant">Na Mídia</a>
								</nav>
								<div class="menu-bar"><span class="lnr lnr-menu"></span></div>
							</div>
						</div>
					</div>
				</div>
			</header>
			<!-- End Header Area -->

			<!-- start banner Area -->
			<section class="banner-area relative" id="home">
				<div class="container">
						<div class="row fullscreen align-items-center justify-content-center">
							<div class="banner-content col-lg-6 col-md-12">
								<h1 class="text-uppercase">
									A NOVA MANEIRA DE PREVER DOENÇAS CRÔNICAS
								</h1>
								<p>
									A Blue A.I integra fontes de dados e usa inteligência artificial para calcular o seu risco de ter uma doença crônica.
								</p>
								<a href=""><button class="primary-btn2 mt-20 text-uppercase ">Em Breve<span class="lnr lnr-arrow-right"></span></button></a>
							</div>
							<div class="col-lg-6 d-flex align-self-end img-right">
								<canvas id="canvas"></canvas>
							</div>
						</div>
				</div>
			</section>
			<!-- End banner Area -->
<!-- 

			<section class="feature-area section-gap" id="service">
				<div class="container">
					<div class="row">
						<div class="col-lg-6">
							<div class="single-feature d-flex flex-row pb-30">
								<div class="icon">
									<span class="lnr lnr-rocket"></span>
								</div>
								<div class="desc">
									<h4 class="text-uppercase">Tecnologia de Dados</h4>
									<p>
										Nosso principal diferencial técnico está na forma que integramos a informação existente em uma rede complexa de análises
									</p>
								</div>
							</div>
							<div class="single-feature d-flex flex-row pb-30">
								<div class="icon">
									<span class="lnr lnr-chart-bars"></span>
								</div>
								<div class="desc">
									<h4 class="text-uppercase">Previsão de Doenças</h4>
									<p>
										Através da inteligência artificial e machine learning, conseguimos prever doenças crônicas antes que elas aconteçam
									</p>
								</div>
							</div>
							<div class="single-feature d-flex flex-row">
								<div class="icon">
									<span class="lnr lnr-bug"></span>
								</div>
								<div class="desc">
									<h4 class="text-uppercase">Entenda Cada Situação</h4>
									<p>
										Tenha uma visão geral da operadora e o estado de saúde de seus pacientes e de seus quadro de funcionários
									</p>
								</div>
							</div>
						</div>
						<div class="col-lg-6">
							<div class="single-feature d-flex flex-row pb-30">
								<div class="icon">
									<span class="lnr lnr-heart-pulse"></span>
								</div>
								<div class="desc">
									<h4 class="text-uppercase">Entregue Mais Valor</h4>
									<p>
										Conecte dados de silos internos, facilite a colaboração com parceiros externos e agregue valor à sua oferta de serviços.
									</p>
								</div>
							</div>
							<div class="single-feature d-flex flex-row pb-30">
								<div class="icon">
									<span class="lnr lnr-paw"></span>
								</div>
								<div class="desc">
									<h4 class="text-uppercase">Agregamento de Dados</h4>
									<p>
										Conexões entre sistemas novos e existentes através de uma variedade de medidas de segurança e autorização.
									</p>
								</div>
							</div>
							<div class="single-feature d-flex flex-row">
								<div class="icon">
									<span class="lnr lnr-users"></span>
								</div>
								<div class="desc">
									<h4 class="text-uppercase">Eficiência Minuciosa</h4>
									<p>
										Identifique ações que colaboram para melhorar a condição de saúde dos beneficiários e simplifique suas decisões
									</p>
								</div>
							</div>
						</div>
					</div>
				</div>
			</section>

 -->

			<!-- Start consultans Area -->
			<section class=" blog-area section-gap" id="consultant">
				<div class="container">
					<div class="row d-flex justify-content-center">
						<div class="col-md-8 pb-80 header-text">
							<h1>Na Mídia</h1>
							<p>
								A Blue A.I. é vencedora da HackBrazil 2019, realizada por Harvard & MIT. Somos destaque em:
							</p>
						</div>
					</div>
					<div class="row">
						<div class="col-lg-3 col-md-3 vol-wrap">
							<div class="single-con">
								<div class="content">
								    <a href="https://g1.globo.com/sp/sao-carlos-regiao/noticia/2019/04/29/alunos-da-usp-ganham-premio-de-r-75-mil-com-software-que-calcula-risco-de-doencas-cronicas.ghtml" target="_blank">
								      <div class="content-overlay"></div>
								  		 <img class="content-image img-fluid d-block mx-auto" src="https://pngimage.net/wp-content/uploads/2018/06/g1-logo-png-1.png" style="padding:10px" alt="">
								    </a>
								 </div>
							</div>
						</div>
						<div class="col-lg-3 col-md-3 vol-wrap">
							<div class="single-con">
								<div class="content">
								    <a href="https://www.startse.com/noticia/startups/63733/startup-blue-calcula-propensao-a-doencas-cronicas-com-inteligencia-artificial" target="_blank">
								      <div class="content-overlay"></div>
								  		 <img class="content-image img-fluid d-block mx-auto" src="https://fi.co/documents/startse-side-banner-2017-02-13.png" style="padding:10px 20px; opacity:0.9" alt="">
								    </a>
								 </div>
							</div>
						</div>
						<div class="col-lg-3 col-md-3 vol-wrap">
							<div class="single-con">
								<div class="content">
								    <a href="http://www.saopaulo.sp.gov.br/spnoticias/ultimas-noticias/alunos-da-usp-criam-software-que-preve-risco-de-doencas-cronicas/" target="_blank">
								      <div class="content-overlay"></div>
								  		 <img class="content-image img-fluid d-block mx-auto" src="http://www.comunicacao.sp.gov.br/wp-content/uploads/2019/03/secom_governosp2019_cmyk_pos_h.png" style="opacity:0.6; padding:10px" alt="">
								    </a>
								 </div>
							</div>
						</div>
						<div class="col-lg-3 col-md-3 vol-wrap">
							<div class="single-con">
								<div class="content">
								    <a href="https://scet.berkeley.edu/brazil-startup-semester-students-ready-to-shake-healthcare-industry/" target="_blank">
								      <div class="content-overlay"></div>
								  		 <img class="content-image img-fluid d-block mx-auto" style="padding:30px 15px 30px 15px; opacity:0.7" src="https://ashoka.edu.in/static/images/default/2.png" alt="">
								    </a>
								 </div>
							</div>
						</div>

					</div>
				</div>
			</section>
			<!-- End consultans Area -->


			<!-- Start about Area -->
			<section class="about-area" id="appoinment">
				<div class="container-fluid">
					<div class="row d-flex justify-content-end align-items-center">
						<div class="col-lg-6 col-md-12 about-left no-padding">
							<img class="img-fluid" src="img/about-img.jpg" alt="">
						</div>
						<div class="col-lg-6 col-md-12 about-right no-padding">
							<h1>Fale com a Blue</h1>
							<form class="booking-form" id="myForm" action="donate.php">
								 	<div class="row">
								 		<div class="col-lg-12 d-flex flex-column">
							 				<input name="name" placeholder="Nome" onfocus="this.placeholder = ''" onblur="this.placeholder = 'Nome'" class="form-control mt-20" required="" type="text" required>
								 		</div>
							 			<div class="col-lg-6 d-flex flex-column">
											<input name="phone" placeholder="Telefone" onfocus="this.placeholder = ''" onblur="this.placeholder = 'Telefone'" class="form-control mt-20" required="" type="text" required>
										</div>
										<div class="col-lg-6 d-flex flex-column">
											<input id="email" name="email" class="single-in mt-20"  onblur="this.placeholder = 'Email'" type="email" placeholder="Email" required>
										</div>
										<div class="col-lg-12 flex-column">
											<textarea class="form-control mt-20" name="message" placeholder="Mensagem" onfocus="this.placeholder = ''" onblur="this.placeholder = 'Mensagem'" required=""></textarea>
										</div>

										<div class="col-lg-12 d-flex justify-content-end send-btn">
											<button class="submit-btn primary-btn mt-20 text-uppercase ">Enviar<span class="lnr lnr-arrow-right"></span></button>
										</div>

										<div class="alert-msg"></div>
									</div>
					  		</form>
							</div>
						</div>
					</div>
				</div>
			</section>
			<!-- End about Area -->

<!-- 
			<section class="facts-area pt-100 pb-100">
				<div class="container">
					<div class="row">
						<div class="col-md-4 single-fact">
							<h2 class="counter">70000</h2>
							<p class="text-uppercase">Pontos de Dados</p>
						</div>
						<div class="col-md-4 single-fact">
							<h2 class="counter">600</h2>
							<p class="text-uppercase">Pacientes Analisados</p>
						</div>
						<div class="col-md-4 single-fact">
							<h2 class="counter">90</h2>
							<p class="text-uppercase">Índices de Saúde</p>
						</div>
					</div>
				</div>
			</section>
 -->

			<!-- Start blog Area -->
			<section class="blog-area section-gap">
				<div class="container">
					<div class="row justify-content-center">
						<div class="col-md-8 pb-30 header-text">
							<h1>Acompanhe-Nos</h1>	
						</div>
					</div>
					<div class="row">
						<div class="single-blog col-lg-4 col-md-4">

							<a href="https://jornal.usp.br/universidade/premiado-no-mit-software-de-alunos-da-usp-preve-risco-de-doencas-cronicas/"><img class="f-img img-fluid mx-auto" src="https://jornal.usp.br/wp-content/uploads/2019/04/20190422_00_software_blue2.jpg" alt=""></a>
							<h4>
								<a href="https://jornal.usp.br/universidade/premiado-no-mit-software-de-alunos-da-usp-preve-risco-de-doencas-cronicas/">Premiado no MIT, software que prevê risco de doenças crônicas</a>
							</h4>
							<p>
								 A nova tecnologia, chamada Blue, integra e analisa um grande banco de dados hospitalares e laboratoriais, considerando desde consultas e exames realizados até pontos mais específicos, como nível de glicose, hábitos alimentares, frequência de atividade física e o histórico de saúde na família.
							</p>
						</div>
						<div class="single-blog col-lg-4 col-md-4">
							<a href="https://www.startse.com/noticia/startups/63733/startup-blue-calcula-propensao-a-doencas-cronicas-com-inteligencia-artificial?fbclid=IwAR3vTt2pRhMNN9_mE9gPIMXHkhOhZByoNsHbMrYv5HxGstf0WExl8wCR0tE"><img class="f-img img-fluid mx-auto" src="https://cee.fiocruz.br/sites/default/files/styles/medium/public/envelhecimento_simp%C3%B3sio_logo1_0.png?itok=JDrUInhh" alt=""></a>
							<h4>
								<a href="https://www.startse.com/noticia/startups/63733/startup-blue-calcula-propensao-a-doencas-cronicas-com-inteligencia-artificial?fbclid=IwAR3vTt2pRhMNN9_mE9gPIMXHkhOhZByoNsHbMrYv5HxGstf0WExl8wCR0tE">Startup Blue calcula propensão a doenças crônicas com inteligência artificial</a>
							</h4>
							<p>
								Foi testando a probabilidade de um dos jurados desenvolver uma doença crônica que a Blue ganhou o Hack Brazil 2019 – e o prêmio de R$ 75 mil. A startup utiliza inteligência artificial para analisar dados de saúde, levando em conta os dados médicos de cada pessoa e de sua família.
							</p>
						</div>
						<div class="single-blog col-lg-4 col-md-4">
							<a href="https://scet.berkeley.edu/brazil-startup-semester-students-ready-to-shake-healthcare-industry/"><img class="f-img img-fluid mx-auto" src="https://lh5.googleusercontent.com/AyZKjEQrvhjJoJQYWMbZNqEr4Ip4JZ3bfLlSEEB-xnzLC4KIWYvdZaHU1hQfn0pGcVQA87ipi4_VkQ0lAwoYAZuVsv-DpDvIJnKfdW6lUEGj1N7MHckD4pIfSzxl4L_jOp5m5zfW" alt=""></a>
							<h4>
								<a href="https://scet.berkeley.edu/brazil-startup-semester-students-ready-to-shake-healthcare-industry/">Brazil Startup Semester students ready to shake healthcare industry</a>
							</h4>
							<p>
								A big win at HackBrazil was only one step in their journey to shake the healthcare industry. Their startup, Blue, integrates data and uses artificial intelligence and machine learning to predict chronic disease.
							</p>
						</div>
					</div>
				</div>
			</section>
			<!-- end blog Area -->

			<!-- start footer Area -->
			<footer class="footer-area section-gap">
				<div class="container">
					<div class="row">
						<div class="col-lg-2  col-md-6">
							<div class="single-footer-widget">
								<h6>Produtos</h6>
								<ul class="footer-nav">
									<li><a href="">Blue CPF (Em Breve)</a></li>
									<li><a href="./insights">Blue Insights</a></li>
								</ul>
							</div>
						</div>
						<div class="col-lg-4  col-md-6">
							<div class="single-footer-widget mail-chimp">
								<h6 class="mb-20">Contato</h6>
								<h3>+55 11 98921-2989</h3>
								<h3><small>falecom@blueai.com.br</small></h3>
							</div>
						</div>
						<div class="col-lg-6  col-md-12">
							<div class="single-footer-widget newsletter">
								<h6>Newsletter</h6>
								<p>Enviamos apenas novidades, sem um único spam.</p>
								<div id="mc_embed_signup">
									<form target="_blank" novalidate="true" action="https://spondonit.us12.list-manage.com/subscribe/post?u=1462626880ade1ac87bd9c93a&amp;id=92a4423d01" method="get" class="form-inline">

										<div class="form-group row" style="width: 100%">
											<div class="col-lg-8 col-md-12">
												<input name="EMAIL" placeholder="Email" onfocus="this.placeholder = ''" onblur="this.placeholder = 'Enter Email '" required="" type="email">
												<div style="position: absolute; left: -5000px;">
													<input name="b_36c4fd991d266f23781ded980_aefe40901a" tabindex="-1" value="" type="text">
												</div>
											</div>

											<div class="col-lg-4 col-md-12">
												<button class="nw-btn primary-btn">Inscrever<span class="lnr lnr-arrow-right"></span></button>
											</div>
										</div>
										<div class="info"></div>
									</form>
								</div>
							</div>
						</div>
					</div>

					<div class="row footer-bottom d-flex justify-content-between">
						<p class="col-lg-8 col-sm-12 footer-text m-0">
							<!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. -->
							Copyright &copy; <script>document.write(new Date().getFullYear());</script> All rights reserved - Blue A.I. <img src="img/fav.png" height="10">
							<!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. -->
						</p>
						<div class="col-lg-4 col-sm-12 footer-social">
							<a href="https://facebook.com/blueai.com.br"><i class="fa fa-facebook"></i></a>
							<a href=""><i class="fa fa-twitter"></i></a>
						</div>
					</div>
				</div>
			</footer>
			<!-- End footer Area -->