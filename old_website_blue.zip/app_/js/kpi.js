document.addEventListener("DOMContentLoaded", function() {

wdtLoading.start({ speed: 1200 });
setTimeout(function() {
  wdtLoading.done();

  $('#loader').hide();
  $('#content').show();
  $('#footer').show();

  var chart1 = new Highcharts.Chart({
    chart: {
      type: 'pie',
      renderTo: 'highcharts'
    },
    title: {
      verticalAlign: 'middle',
      floating: true,
      text: '<h1>'+nscore+'</h1><br>da escala 100'
    },
    plotOptions: {
      pie: {
        colors: [
           '#F59640',
           '#35BEC1',
           '#A589D9',
           '#EDEDED'
         ],
        innerSize: '70%',
        dataLabels: {
            enabled: false
        },
      }
    },
    credits: {
        enabled: false
      },
    series: [{
      data: [
        ['Cardíaco', hs],
        ['Sanguíneo', ds],
        ['Hereditário', as],
        ['Restantes', 50*hs/100]
      ]
    }]
  });

setTimeout(function(){ $('#hide1').hide(); $('#show1').show(); }, 1000);
setTimeout(function(){ $('#hide2').hide(); $('#show2').show(); }, 2000);
setTimeout(function(){ $('#hide3').hide(); $('#show3').show(); }, 2200);

}, 6500);

});

(function() {
  function updateTimelineItems(event, firstRun) {
    var top = 0;
    var bottom = window.innerHeight;

    [].slice.call(document.querySelectorAll('.fs-timeline-item')).forEach(function(element, i) {
      var rect = element.getBoundingClientRect();
      if (rect.bottom >= top && rect.top <= bottom) {
        if (firstRun === true) {
          setTimeout(function() {
            this.classList.add('is-visible');
          }.bind(element), i * 120);
        } else {
          element.classList.add('is-visible');
        }
      } else {
        element.classList.remove('is-visible');
      }
    });
  }
  window.addEventListener('resize', updateTimelineItems);
  window.addEventListener('scroll', updateTimelineItems);
  updateTimelineItems(null, true);
})();







function aviso()
{
  $.ajax({
    type: 'POST',
    url: './app/aviso.php',
    data: {
    	  piPointName: piPointName,
        lab: lab,
        filter: filter
    },
    success: function (data) {
    	$("#aviso").html(data);
    }
	});
}
aviso();

function ajaxTopKpi(kpid)
{
  $.ajax({
    type: 'POST',
    url: './app/top.php',
    data: {
        kpid: kpid,
        req: 'topkpi'
    },
    success: function (data) {
      $("#topkpi").html(data);
    }
  });
}
ajaxTopKpi(kpid);

function ajaxInstantaneo (nome, begin, end) {
	document.getElementById("ajaxi").innerHTML = "";
  $('#instantaneo_classico').html('<br>');
  $('#loadingInstantaneo').show();
  $.ajax({
    type: 'POST',
    url: './app/kpi.php',
    async:true,
    data: {
        nome: nome,
        begin: begin,
        end: end,
        req: 'instantaneo',
    },
    success: function (data) {
      $('#ajaxi').html(data);
      $('#loadingInstantaneo').hide();
    }
  });
}
function ajaxDiario (nome, begin, end) {
	document.getElementById("ajaxd").innerHTML = "";
  $('#diario_classico').html('<br>');
  $('#diario_boxplot').html('<br>');
  $('#diario_classico').show();
  $('#diario_boxplot').show();
  $('#loadingDiario').show();
  $.ajax({
    type: 'POST',
    url: './app/kpi.php',
    async:true,
    data: {
        nome: nome,
        begin: begin,
        end: end,
        req: 'diario',
    },
    success: function (data) {
      $('#ajaxd').html(data);
      $('#loadingDiario').hide();
      openDiario(event, 'diario_classico');
      $(".tabd").addClass(" active");
    }
  });
}
function ajaxMensal (nome, begin, end) {
	document.getElementById("ajaxm").innerHTML = "";
  $('#mensal_classico').html('<br>');
  $('#mensal_boxplot').html('<br>');
  $('#mensal_classico').show();
  $('#mensal_boxplot').show();
  $('#loadingMensal').show();
  $.ajax({
    type: 'POST',
    url: './app/kpi.php',
    async:true,
    data: {
        nome: nome,
        begin: begin,
        end: end,
        req: 'mensal',
    },
    start_time: Date.now(),
    success: function (data) {
      $('#ajaxm').html(data);
      $('#loadingMensal').hide();
      $('#performance').html(((Date.now() - this.start_time)/1000).toPrecision(6));
      openMensal(event, 'mensal_classico');
      $(".tabm").addClass(" active");
    }
  });
}

window.onload = function() {

};

$("#instantaneo-date").dateRangePicker(
  {
    language:'pt',
    format: 'DD-MMM-YY',
    separator: ' até ',
    singleMonth: true,
    showShortcuts: false,
    monthSelect: true,
    yearSelect: true,
    autoClose: true,
    getValue: function(){return this.innerHTML;},setValue: function(s){this.innerHTML = s;}
  }
  ).bind('datepicker-change',function(event,obj)
  {
    if(obj.date2 > moment())
    {
      alert('A data não pode ser maior que o dia de hoje.');
      $("#instantaneo-date").data('dateRangePicker').setDateRange(begini.format('DD-MMM-YY'), endi.format('DD-MMM-YY'));
    }
    else
    {
      begini = moment(obj.date1); endi = moment(obj.date2); end = moment();
      if(endi.format('DD-MMM-YY') === end.format('DD-MMM-YY')) endi = end;
      session('i', new Array(begini.format(), endi.format()));
      ajaxInstantaneo(nome, begini.format(), endi.format());
      $("#datei").show();
    }
});
$("#instantaneo-date").data('dateRangePicker').setDateRange(begini.format('DD-MMM-YY'), endi.format('DD-MMM-YY'));

$("#diario-date").dateRangePicker(
  {
    language:'pt',
    format: 'DD-MMM-YY',
    separator: ' até ',
    singleMonth: true,
    showShortcuts: false,
    monthSelect: true,
    yearSelect: true,
    autoClose: true,
    getValue: function(){return this.innerHTML;},setValue: function(s){this.innerHTML = s;}
  }
  ).bind('datepicker-change',function(event,obj)
  {
    if(obj.date2 > moment())
    {
      alert('A data não pode ser maior que o dia de hoje.');
      $("#diario-date").data('dateRangePicker').setDateRange(begind.format('DD-MMM-YY'), endd.format('DD-MMM-YY'));
    }
    else
    {
      begind = moment(obj.date1); endd = moment(obj.date2);
      session('d', new Array(begind.format(), endd.format()));
      ajaxDiario(nome, begind.format(), endd.format());
      $("#dated").show();
    }
});
$("#diario-date").data('dateRangePicker').setDateRange(begind.format('DD-MMM-YY'),endd.format('DD-MMM-YY'));

$("#mensal-date").dateRangePicker(
  {
    language:'pt',
    format: 'MMM/YY',
    separator: ' até ',
    showShortcuts: false,
    monthSelect: true,
    yearSelect: true,
    autoClose: true,
    getValue: function(){return this.innerHTML;},setValue: function(s){this.innerHTML = s;}
  }
  ).bind('datepicker-change',function(event,obj)
  {
    if(obj.date2 > moment())
    {
      alert('A data não pode ser maior que o dia de hoje.');
      $("#mensal-date").data('dateRangePicker').setDateRange(beginm.format('MMM/YY'), endm.format('MMM/YY'));
    }
    else
    {
      beginm = moment(obj.date1); endm = moment(obj.date2);
      ajaxMensal(nome, beginm.format(), endm.format());
      $("#datem").show();
    }
});
$("#mensal-date").data('dateRangePicker').setDateRange(beginm.format('MMM/YY'), endm.format('MMM/YY'));

$("#instantaneo-check").click(function() { if($(this).is(":checked")) $("#instantaneo").fadeIn();else $("#instantaneo").fadeOut();});
$("#diario-check").click(function() { if($(this).is(":checked")) $("#diario").fadeIn(); else $("#diario").fadeOut();});
$("#mensal-check").click(function() { if($(this).is(":checked")) $("#mensal").fadeIn(); else $("#mensal").fadeOut();});

function openInstantaneo(evt, cityName) {
    var i, tabcontent;
    tabcontent = document.getElementsByClassName("tabcontent_instantaneo");
    for (i = 0; i < tabcontent.length; i++) {
        tabcontent[i].style.display = "none";
    }
    document.getElementById(cityName).style.display = "block";
}

function openDiario(evt, cityName) {
    var i, tabcontent, tablinks;
    tabcontent = document.getElementsByClassName("tabcontent_diario");
    for (i = 0; i < tabcontent.length; i++) {
        tabcontent[i].style.display = "none";
    }
    tablinks = document.getElementsByClassName("tablinks_diario");
    for (i = 0; i < tablinks.length; i++) {
        tablinks[i].className = tablinks[i].className.replace(" active", "");
    }
    document.getElementById(cityName).style.display = "block";
    evt.currentTarget.className += " active";
}

function openMensal(evt, cityName) {
    var i, tabcontent, tablinks;
    tabcontent = document.getElementsByClassName("tabcontent_mensal");
    for (i = 0; i < tabcontent.length; i++) {
        tabcontent[i].style.display = "none";
    }
    tablinks = document.getElementsByClassName("tablinks_mensal");
    for (i = 0; i < tablinks.length; i++) {
        tablinks[i].className = tablinks[i].className.replace(" active", "");
    }
    document.getElementById(cityName).style.display = "block";
    evt.currentTarget.className += " active";
}

function openTab(evt, cityName) {
    var i, tabs;
    tabs = document.getElementsByClassName("tabs");
    for (i = 0; i < tabs.length; i++) {
        tabs[i].style.display = "none";
    }
    document.getElementById(cityName).style.display = "block";
}

function closeTabs(evt) {
    var i, tabs;
    tabs = document.getElementsByClassName("tabs");
    for (i = 0; i < tabs.length; i++) {
        tabs[i].style.display = "block";
    }
    document.getElementById("config").style.display = "none";
    document.getElementById("ajuda").style.display = "none";
}

function restaurarData(tipo)
{
	if(tipo === 'i') {
		begini = moment().subtract(1, 'week'); endi = moment();
		$("#instantaneo-date").data('dateRangePicker').setDateRange(begini.format('DD-MMM-YY'), endi.format('DD-MMM-YY'));
		$("#datei").hide();
    setTimeout(function(){ session('i', 'unset'); }, 1500);
	}
	else if(tipo === 'd') {
		begind = moment().subtract(1, 'month'); endd = moment();
		$("#diario-date").data('dateRangePicker').setDateRange(begind.format('DD-MMM-YY'), endd.format('DD-MMM-YY'));
		$("#dated").hide();
    setTimeout(function(){ session('d', 'unset'); }, 1500);
	}
	else if(tipo === 'm') {
		beginm = moment().subtract(1, 'year'); endm = moment();
		$("#mensal-date").data('dateRangePicker').setDateRange(beginm.format('MMM/YY'), endm.format('MMM/YY'));
		$("#datem").hide();
	}
}

function session(tipo, arr)
{
  $.ajax({
    type: 'POST',
    url: './app/session.php',
    data: {
        arr: arr,
        tipo: tipo
    },
    success: function (data) {}
  });
}

function aplicarAjustes(nome, tipo)
{
	if(tipo === 'i')
		filter = $('input[name="filteri"]').val();
	else if(tipo === 'd')
		filter = $('input[name="filterd"]').val();
	else if(tipo === 'm')
		filter = $('input[name="filterm"]').val();
	filter = filter.replace(/\s/g,'');
  $.ajax({
    type: 'POST',
    url: './app/session.php',
    data: {
    	  nome: nome,
        tipo: tipo,
        filter: filter
    },
    success: function (data) {}
	});
	if(tipo === 'i') {
		openInstantaneo(event, 'instantaneo_classico');
		ajaxInstantaneo(nome, begini.format(), endi.format());
		$("#restaurari").show();
	}
	else if(tipo === 'd') {
		openDiario(event, 'diario_classico');
		ajaxDiario(nome, begind.format(), endd.format());
		$("#restaurard").show();
	}
	else if(tipo === 'm') {
		openMensal(event, 'mensal_classico');
		ajaxMensal(nome, beginm.format(), endm.format());
		$("#restaurarm").show();
	}
	aviso();
}

function restaurarAjustes(nome, tipo)
{
	filter = filterdefault;
  $.ajax({
    type: 'POST',
    url: './app/session.php',
    data: {
    	  nome: nome,
        tipo: 'r'
    },
    success: function (data) {}
	});
	if(tipo === 'i') {
		ajaxInstantaneo(nome, begini.format(), endi.format());
		$("#restaurari").hide();
	}
	else if(tipo === 'd') {
		ajaxDiario(nome, begind.format(), endd.format());
		$("#restaurard").hide();
	}
	else if(tipo === 'm') {
		ajaxMensal(nome, beginm.format(), endm.format());
		$("#restaurarm").hide();
	}
	aviso();
}

function listaHiopPeriodo(on, fullmonth)
{
  var hiop = [];
  if(on === 'inst')
    hiop = [kpid, begini.format(), endi.format(), on];
  else if(on === 'day')
    hiop = [kpid, begind.format(), endd.format(), on];
  else if (on === 'month')
    hiop = [kpid, beginm.format(), endm.format(), on];
  $('#hiop').load('./view/hiop.php', {view: 'list', kpid: hiop[0], begin: hiop[1], end: hiop[2], on: hiop[3], fullmonth: fullmonth});
}

function criarHiop(xaxis, yaxis, on)
{
  $('#hiop').load('./view/hiop.php', {view: 'create', kpid: kpid, on: on, xaxis: xaxis, yaxis: yaxis});
  $('#modalHiop').modal();
}

function deletarHiopId(id, on)
{
  if(confirm('DESEJA DELETAR ESTE HISTÓRICO?'))
  {
    $('#hiop').load('./app/hiop.php', {id: id, req: 'delete'}, function() {alert('DELETADO!');});
    listaHiopPeriodo(on);
    setTimeout(function(){
      ajaxInstantaneo(nome, begini.format(), endi.format());
      ajaxDiario(nome, begind.format(), endd.format());
      ajaxMensal(nome, beginm.format(), endm.format());
    }, 1000);
  }
}

var doubleClickTime = 0;
var threshold = 200;

function imprimir()
{

  if(typeof plot_diario !== 'undefined') {
    var arr = $("#diario_classico g.xtick text");
    var y = plot_diario.y;
    var count = arr.length;
    var i = 0;
    while(i < count)
    {
      $(arr[i]).prepend("<"+y[i].toFixed(2)+"> ");
      i++;
    }
  }

  if(typeof plot !== 'undefined') {
    $('#mensal_classico .xtick text').attr("transform", function() { return $(this).attr("transform") + "translate(50,30) rotate(30,0,327)" });

    var arr = $("#mensal_classico g.xtick text");
    var y = plot.y;
    var count = arr.length;
    var i = 0;
    while(i < count)
    {
      $(arr[i]).prepend("<"+y[i].toFixed(2)+"> ");
      i++;
    }
  }
}

window.onbeforeprint = function() {
    imprimir();
};
window.onafterprint = function() {
	Plotly.relayout('diario_classico',{'xaxis.autorange': true,'yaxis.autorange': true});
	Plotly.relayout('mensal_classico',{'xaxis.autorange': true,'yaxis.autorange': true});
};
