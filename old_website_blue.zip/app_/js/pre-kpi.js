var layout_options = {
  responsive: true,
  scrollZoom: false,
  displayModeBar: true,
  displaylogo: false,
  modeBarButtonsToRemove: ['sendDataToCloud', 'pan2d', 'select2d', 'lasso2d', /*'zoomIn2d', 'zoomOut2d',*/ 'hoverClosestCartesian', 'hoverCompareCartesian', 'toggleSpikelines']
}