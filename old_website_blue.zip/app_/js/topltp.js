
$carousel1 = $('.top1').flickity({
  cellAlign: 'left',
  contain: true,
  freeScroll: true,
  groupCells: 10,
  freeScrollFriction:0.1,
  wrapAround: true
});

$carousel2 = $('.top2').flickity({
  cellAlign: 'left',
  contain: true,
  freeScroll: true,
  groupCells: 10,
  freeScrollFriction:0.1,
  wrapAround: true
});

$carousel3 = $('.top3').flickity({
  cellAlign: 'left',
  contain: true,
  freeScroll: true,
  groupCells: 10,
  freeScrollFriction:0.1,
  wrapAround: true
});

function ajaxTop (area, timerange, limit, req) {
  $.ajax({
    type: 'POST',
    url: './app/top.php',
    data: {
        area: area,
        timerange: timerange,
        limit: limit,
        req: req
    },
    success: function (data) {
      switch(area) {
        case 1:
          var cellElements = $carousel1.flickity('getCellElements');
          $carousel1.flickity( 'remove', cellElements);
          var $cellElems = $(data);
          $carousel1.flickity( 'append', $cellElems);
          $carousel1.flickity('next');
          break;
        case 2:
          var cellElements = $carousel2.flickity('getCellElements');
          $carousel2.flickity( 'remove', cellElements);
          var $cellElems = $(data);
          $carousel2.flickity( 'append', $cellElems);
          $carousel2.flickity('next');
          break;
        case 3:
          var cellElements = $carousel3.flickity('getCellElements');
          $carousel3.flickity( 'remove', cellElements);
          var $cellElems = $(data);
          $carousel3.flickity( 'append', $cellElems);
          $carousel3.flickity('next');
          break;
      }
    }
  });
}

  //TOP INDICADORES
  $('select#topselect1').change(function() {
      ajaxTop(1, this.value, 50, 'toplist');
  });
  $('select#topselect2').change(function() {
      ajaxTop(2, this.value, 50, 'toplist');
  });
  $('select#topselect3').change(function() {
      ajaxTop(3, this.value, 50, 'toplist');
  });