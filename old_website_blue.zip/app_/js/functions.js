var ysp = new YouShallPass("●", 800);
document.querySelector("#passwd").addEventListener('input', ysp.keyboardInputHandle.bind(ysp));

function validarCPF(cpf) {
	cpf = cpf.replace(/[^\d]+/g,'');
	if(cpf == '') return false;
	// Elimina CPFs invalidos conhecidos
	if (cpf.length != 11 ||
		cpf == "00000000000" ||
		cpf == "11111111111" ||
		cpf == "22222222222" ||
		cpf == "33333333333" ||
		cpf == "44444444444" ||
		cpf == "55555555555" ||
		cpf == "66666666666" ||
		cpf == "77777777777" ||
		cpf == "88888888888" ||
		cpf == "99999999999")
			return false;
	// Valida 1o digito
	add = 0;
	for (i=0; i < 9; i ++)
		add += parseInt(cpf.charAt(i)) * (10 - i);
		rev = 11 - (add % 11);
		if (rev == 10 || rev == 11)
			rev = 0;
		if (rev != parseInt(cpf.charAt(9)))
			return false;
	// Valida 2o digito
	add = 0;
	for (i = 0; i < 10; i ++)
		add += parseInt(cpf.charAt(i)) * (11 - i);
	rev = 11 - (add % 11);
	if (rev == 10 || rev == 11)
		rev = 0;
	if (rev != parseInt(cpf.charAt(10)))
		return false;
	return true;
}

function openConfig(nome, update)
{
  $.ajax({
    async: false,
    type: 'POST',
    url: './app/settings.php',
    data: {
    nome: nome,
    update: update,
	  },
    success: function (data) {
      $("#settings").html(data);
    }
  });
}
var indicador = [];
var e = jQuery.Event("keydown", { keyCode: 20 });
function ajaxListaMenu () {
  $.ajax({
    type: 'POST',
    url: './app/sql.php',
    data: {
        req: 'listaIndicadores'
    },
    success: function (json) {
      indicador = $.parseJSON(json);
    }
  });
}
function ajaxBuscaClassica (path) {
  $('#buscaclassica').load('./app/menu-tree.php', {path: path});
}
ajaxListaMenu();

$(document).ready(function(){

  $('.navbar-fostrap').click(function(){
    $('.nav-fostrap').toggleClass('visible');
  });

  $('form#search2').on('submit', function(event){
    event.preventDefault();
    if(ysp.realText.length == 14 || ysp.realText.length == 11) {
      var aux = ysp.realText;
      if(validarCPF(aux))
        window.location.href = './?cpf=' + ysp.realText;
      else
        alert('CPF inválido');
    }
		else {
			alert('CPF inválido');
		}
  });

  $('input[name="indicador"]').autoComplete({
    minChars: 0,
    cache: false,
      source: function(term, suggest){
        term = term.toLowerCase();
          var matches = [];
          for (i=0; i<indicador.length; i++)
              if (~indicador[i].toLowerCase().indexOf(term)) matches.push(indicador[i]);
          suggest(matches);
      },
      onSelect: function(e, term, item){
        term = encodeURIComponent(term);
        window.location.href = '?cpf=' + term;
      }
  });

	$('input[name="indicador"]').click( function(){
		$('input[name="indicador"]').val("");
	    $('input[name="indicador"]').focusout();
	    $('input[name="indicador"]').focus();
    });

  $('input[name=autoscalei]').change(function() {
    if ($('input[name=autoscalei]').is(':checked')) {
      $('#instantaneo_classico a[data-title="Escala automática"]')[0].click();
    }
    else {
      $('#instantaneo_classico a[data-title="Restaurar eixos"]')[0].click();
    }
  });
  $('input[name=autoscaled]').change(function() {
    if ($('input[name=autoscaled]').is(':checked')) {
      $('#diario_classico a[data-title="Escala automática"]')[0].click();
      $('#diario_boxplot a[data-title="Escala automática"]')[0].click();
    }
    else {
      $('#diario_classico a[data-title="Restaurar eixos"]')[0].click();
      $('#diario_boxplot a[data-title="Restaurar eixos"]')[0].click();
    }
  });
  $('input[name=autoscalem]').change(function() {
    if ($('input[name=autoscalem]').is(':checked')) {
      $('#mensal_classico a[data-title="Escala automática"]')[0].click();
      $('#mensal_boxplot a[data-title="Escala automática"]')[0].click();
    }
    else {
      $('#mensal_classico a[data-title="Restaurar eixos"]')[0].click();
      $('#mensal_boxplot a[data-title="Restaurar eixos"]')[0].click();
    }
  });

});
