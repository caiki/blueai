
$carousel = $('.top').flickity({
  cellAlign: 'left',
  contain: true,
  groupCells: true,
  groupCells: 10,
  prevNextButtons: false
});

function ajaxTopHome (area, timerange, limit, req) {
  $('select').hide();
  $('.ts').css('border-bottom','0px');
  switch(area) {
    case 1:
      $('#ts1').css('border-bottom','2px solid');
      $('select#topselect1').show();
      break;
    case 2:
      $('#ts2').css('border-bottom','2px solid');
      $('select#topselect2').show();
      break;
    case 3:
      $('#ts3').css('border-bottom','2px solid');
      $('select#topselect3').show();
      break;
  }
  $.ajax({
    type: 'POST',
    url: './app/top.php',
    data: {
        area: area,
        timerange: timerange,
        limit: limit,
        req: req
    },
    success: function (data) {
      var cellElements = $carousel.flickity('getCellElements');
      $carousel.flickity( 'remove', cellElements);
      var $cellElems = $(data);
      $carousel.flickity( 'append', $cellElems);
    }
  });
}

  //TOP INDICADORES
  $('select#topselect1').change(function() {
      ajaxTopHome(1, this.value, 10, 'toplist');
  });
  $('select#topselect2').change(function() {
      ajaxTopHome(2, this.value, 10, 'toplist');
  });
  $('select#topselect3').change(function() {
      ajaxTopHome(3, this.value, 10, 'toplist');
  });