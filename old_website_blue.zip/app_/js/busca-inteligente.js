var busca = [];
function ajaxBusca () {
  $.ajax({
    type: 'POST',
    url: './app/sql.php',
    data: {
        req: 'listaIndicadores'
    },
    success: function (json) {
        busca = $.parseJSON(json);
    }
  });
}
ajaxBusca();

var ysp1 = new YouShallPass("●", 800);
document.querySelector("#passwd1").addEventListener('input', ysp1.keyboardInputHandle.bind(ysp1));

$('form#search1').on('submit', function(event){
  event.preventDefault();
  if(ysp1.realText.length == 14 || ysp1.realText.length == 11) {
    var aux = ysp1.realText;
    if(validarCPF(aux))
      window.location.href = './?cpf=' + ysp1.realText;
    else
      alert('CPF inválido');
  }
  else {
    alert('CPF inválido');
  }
});
$('input[name="busca"]').autoComplete({
  minChars: 1,
    source: function(term, suggest){
      term = term.toLowerCase();
        var matches = [];
        for (i=0; i<busca.length; i++)
            if (~busca[i].toLowerCase().indexOf(term)) matches.push(busca[i]);
        suggest(matches);
    },
    onSelect: function(e, term, item){
      term = encodeURIComponent(term);
      window.location.href = '?cpf=' + term;
    }
});
