<?php
	require_once('./app/sql.php');
?>
<div class="box tabs tabcontent" style="padding:5px 20px 5px 20px; margin:10px 0 10px 0;">
<div class="ajustes">
	<h1>Lista de KPIs Auxiliares</h1>
	<h2>Meus KPIs Auxiliares</h2>
	<table class="table table-striped table-hover">
	  <thead>
	    <tr>
	      <th>#</th>
	      <th>Nome do KPI Auxiliar</th>
	      <th>Configurações</th>
	    </tr>
	  </thead>
	  <tbody>
<?php
	$rows = SQL::listaMeusKpisAuxiliares($sql);
	if($rows) {
		$i = 1;
		foreach($rows as $row) {
			$nome = $row['nome'];
			echo '<tr>';
			echo '<th>'.$i.'</th>';
			echo '<td><a href="./?nome='.urlencode($nome).'">'.$nome.'</td>';
?>
			<td><a href="javascript: void(0)" onclick="openConfig(<?php echo "'$nome'"; ?>, 'modificar');"  data-toggle="modal" data-target="#modalConfig"><img title="Modificar" alt="Modificar" src="./images/settings.gif"></a> <a href="javascript: void(0)" onclick="openConfig(<?php echo "'$nome'"; ?>, 'modificar'); $('#deletar').submit(); "><img title="Deletar" alt="Deletar" src="./images/delete_icon.png"></a></td>
<?php
			echo '</tr>';
			$i++;
		}
	} else {echo '<th></th><td>VOCÊ AINDA NÃO CRIOU NENHUM KPI AUXILIAR</td><td></td>';}
?>
	  </tbody>
	</table>
	<h2>Todos KPIs Auxiliares</h2>
	<table class="table table-striped table-hover">
	  <thead>
	    <tr>
	      <th>#</th>
	      <th>Nome do KPI Auxiliar</th>
	      <th>Usuário</th>
	    </tr>
	  </thead>
	  <tbody>
<?php
	$rows = SQL::listaTodosKpisAuxiliares($sql);
	$i = 1;
	foreach($rows as $row) {
		echo '<tr>';
		echo '<th>'.$i.'</th>';
		echo '<td><a href="./?nome='.urlencode($row['nome']).'">'.$row['nome'].'</td>';
		echo '<td>'.$row['owner'].'</td>';
		echo '</tr>';
		$i++;
	}
?>
	  </tbody>
	</table>
</div>
</div>

<!-- Modal Modificar -->
<div class="modal fade" id="modalConfig" tabindex="-1" role="dialog" aria-hidden="true">
  <div class="modal-dialog modal-lg" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" style="float:left">Configurações</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close" style="float:right">
          <span aria-hidden="true" style="font-size:2em;">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        <div id="settings" class="ajustes"></div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal" style="font-size:1em;">Fechar</button>
      </div>
    </div>
  </div>
</div>