<div class="box tabs tabcontent" style="padding:5px 20px 5px 20px; margin:10px 0 10px 0;">
<div class="ajustes">
<style>
.top-cell {
width: 8.3vw;
height: 8.3vw;
</style>
	<h1>Top Indicadores Piores</h1>
	<h2>Lista Completa</h2>
	<br>
	<h2>Processo</h2>
	<div id="topselect">
		<select id="topselect1" class="styled-select slate">
		  <option value="2">Últimos 2 Dias</option>
		  <option value="7">Últimos 7 dias</option>
		  <option value="15">Últimos 15 dias</option>
		  <option value="30">Últimos 30 dias</option>
		  <option value="60">Últimos 60 dias</option>
		  <option value="90">Últimos 90 dias</option>
		</select>
	</div>
	<br>
	<center>
	<div class="top1 js-flickity">
	  <div class="top-cell"></div>
	</div>
	</center>

	<br>
	<h2>Qualidade</h2>
	<div id="topselect">
		<select id="topselect2" class="styled-select slate">
		  <option value="15">Últimos 15 Dias</option>
		  <option value="30">Últimos 30 dias</option>
		  <option value="60">Últimos 60 dias</option>
		  <option value="90">Últimos 90 dias</option>
		</select>
	</div>
	<br>
	<center>
	<div class="top2 js-flickity">
	  <div class="top-cell"></div>
	</div>
	</center>

	<br>
	<h2>Consumo</h2>
	<div id="topselect">
		<select id="topselect3" class="styled-select slate">
	  <option value="0">Últimos 15 Dias</option>
	  <option value="1">Últimos 30 dias</option>
	  <option value="2">Últimos 60 dias</option>
	  <option value="3">Últimos 90 dias</option>
	</select>
	<br>
	<center>
	<div class="top3 js-flickity">
	  <div class="top-cell"></div>
	</div>
	</center>

	<script src="./js/topltp.js"></script>
	<script>
	  ajaxTop(1, 2, 50, 'toplist');
	  ajaxTop(2, 15, 50, 'toplist');
	  ajaxTop(3, 0, 50, 'toplist');
	</script>
</div>
</div>