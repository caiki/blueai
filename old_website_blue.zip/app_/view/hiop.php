<?php
	require_once('../app/hiop.php');
	$kpid = $_POST['kpid'];
	$on = $_POST['on'];

if($_POST['view'] == 'create'):
	$yaxis = $_POST['yaxis'];
	$xaxis = str_replace('/', '-', $_POST['xaxis']);
	$xaxis = new DateTime($xaxis);
	if($on == 'month')
		$xaxis->modify('first day of this month');

	if($on == 'inst')
		echo '<b>Criar Novo Histórico Operacional em ' . $xaxis->format('d \d\e M \d\e Y \à\s H:i') . '</b><br><br>';
	else if($on == 'day')
		echo '<b>Criar Novo Histórico Operacional em ' . $xaxis->format('d \d\e M \d\e Y') . '</b><br><br>';
	else {
		echo '<b>Criar Novo Sumario Operacional em ' . $xaxis->format('M \d\e Y') . '</b><br><br>';
		echo '<div class="btni" style="text-align:center; background-color:orange"><b>Caso queira selecionar o dia do mes, use o grafico diario</b></div><br>';
	}
?>
	  <form id="formHiop" method="post">
	  	<input name="req" value="create" hidden>
	  	<input name="kpid" value="<?php echo $kpid; ?>" hidden>
	  	<input name="yaxis" value="<?php echo $yaxis; ?>" hidden>
	  	<input name="on" value="<?php echo $on; ?>" hidden>

	    <label>QUANDO</label>
	    <input type="text" value="<?php echo $xaxis->format('Y-m-d H:i'); ?>" name="xaxis" readonly required>
	    <small></small>

	    <label>ANOTAÇÃO NO GRÁFICO <img src="./images/speech_bubble.png" width=16></label>
	    <input type="text" value="" name="shortdesc" required>
	    <small>Descrição curta que irá aparecer no gráfico.</small>

	    <label>COMENTÁRIOS <img src="./images/text-file-ico.png" width=16></label>
	    <input type="text" value="" name="longdesc">
	    <small>Descrição longa que irá no histórico operacional.</small>

	    <input type="submit" value="CRIAR NOVO HISTÓRICO OPERACIONAL">
	  </form>

<script>
	$('#formHiop').on('submit', function(e){
		e.preventDefault();

		var xaxis = $('input[name="xaxis"]').val();
		var yaxis = $('input[name="yaxis"]').val();
		var on = $('input[name="on"]').val();
		var shortdesc = $('input[name="shortdesc"]').val();
		var longdesc = $('input[name="longdesc"]').val();

		$('#hiop').load('./app/hiop.php', {req: 'create', kpid: kpid, xaxis: xaxis, yaxis: yaxis, shortdesc: shortdesc, longdesc: longdesc, on: on});

		listaHiopPeriodo(on);

		setTimeout(function(){
			ajaxInstantaneo(nome, begini.format(), endi.format());
			ajaxDiario(nome, begind.format(), endd.format());
			ajaxMensal(nome, beginm.format(), endm.format());
		}, 1000);
	});
</script>

<?php
else:

	if($on == 'day' and !empty($_POST['fullmonth'])) {
		$begin = new DateTime($_POST['fullmonth']);
		$end = new DateTime($_POST['fullmonth']);
		$end->modify('+1 month');
	}
	else {
		$begin = new DateTime($_POST['begin']);
		$end = new DateTime($_POST['end']);
	}

	if($on == 'month') {
		echo '<b>Histórico Operacional de ' . $begin->format('M\/y') . ' à ' . $end->format('M\/y') . '</b><br><br>';
		echo '<div class="btni" style="text-align:center; background-color:#006064"><b>Sumario dos meses</b></div><br>';
	}
	else
		echo '<b>Histórico Operacional de ' . $begin->format('d-M-y') . ' à ' . $end->format('d-M-y') . '</b><br><br>';
		if($on == 'day' and !empty($_POST['fullmonth']))
			echo '<div class="btni" style="text-align:center; background-color:#006064"><b>Historico completo para o mes de '.$begin->format('M\/y').'</b></div><br>';

	if($on == 'inst') {
		$begin = $begin->format('Y-m-d');
		$end = $end->format('Y-m-d');
	} else if ($on == 'day') {
		$end->modify('+1 day');
		$begin = $begin->format('Y-m-d');
		$end = $end->format('Y-m-d');
	} else if ($on == 'month') {
		$end->modify('+1 month');
		$begin = $begin->format('Y-m').'-01';
		$end = $end->format('Y-m').'-01';
	}
?>
	<table class="table table-striped table-hover">
	  <thead>
	    <tr>
	      <th>#</th>
	      <th>Anotação</th>
	      <th>Comentários</th>
	      <th>Usuário</th>
	    </tr>
	  </thead>
	  <tbody>
<?php
	require_once('../app/admin.php');
	$rows = Hiop::listaHiopPeriodo($sql, $kpid, $begin, $end, $on);
	if($rows) {
		foreach($rows as $row) {
			echo '<tr>';
			echo '<th>'; $xaxis = new DateTime($row['xaxis']); if($on == 'inst') echo $xaxis->format('d-M-y H:i'); else if($on == 'day') echo $xaxis->format('d-M-y'); else echo $xaxis->format('M\/y');
			if($_SESSION['username'] == $row['user'] OR $config) {
			?>
			<br><a onclick="deletarHiopId(<?php echo $row['id']; ?>, '<?php echo $on; ?>');"><img title="Deletar" alt="Deletar" src="./images/delete_icon.png" width=11></a>
			<?php
			}
			echo '</th>';
			echo '<td>'.$row['shortdesc'].'</td>';
			echo '<td>'.$row['longdesc'].'</td>';
			echo '<td><small>'.$row['user'].'</small></td>';
			echo '</tr>';
		}
	} else {echo '<th></th><td>Não há nenhum histórico para o período selecionado.</td><td></td><td></td>';}
?>
	  </tbody>
	</table>
<?php
	if($on == 'month') {
		if(!empty($_POST['fullmonth'])) {
			$fullmonth = new DateTime(str_replace('/', '-', $_POST['fullmonth']));
			$fullmonth->modify('first day of this month midnight');
			echo '<div id="hiopextra"></div>';
			echo '<script>$("#hiopextra").load("./view/hiop.php", {view: "list", kpid: '.$kpid.', on: "day", fullmonth: "'.$fullmonth->format('c').'"});</script>';
		}
		else {
			echo '<div class="btni" style="text-align:center; background-color:#006064"><b>Clique na anotacao no grafico para ver o historico completo<br>do mes desejado</b></div><br>';
		}
	}

	if(!isset($fullmonth))
		echo '<div class="btni" style="text-align:center; background-color:#00C853"><b>Clique no Gráfico para Criar um Novo Histórico Operacional</b></div>';

endif;
?>

