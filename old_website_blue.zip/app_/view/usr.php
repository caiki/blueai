<div class="box tabs tabcontent" style="padding:5px 20px 5px 20px; margin:10px 0 10px 0;">
<div class="ajustes">
<?php 
	require_once('./app/sql.php');
	require_once('./app/user.php');
	$user = User::checkID($sql, $_SESSION['username']);
	if($user['pref']) $pref = unserialize($user['pref']); else $pref = array();
	if($user['freq']) $freq = unserialize($user['freq']); else $freq = array();
?>
	<h1>Usuario <i style="color:blue"><?php echo $_SESSION['username'] ?></i></h1>
	<h3>Atualizar Preferencias de Email</h3>
	<br>
	<form action="./app/user.php" method="post">
	<input value="userpref" name="req" required hidden>
	<input value="<?php echo $_SESSION['username'] ?>" name="id" required hidden>

	Nome: <input type="text" value="<?php echo $user['firstname'] ?>" name="firstname" required>
	<small></small>

	Sobrenome: <input type="text" value="<?php echo $user['lastname'] ?>" name="lastname" required>
	<small></small>

	Email @klabin.com.br: <input type="email" value="<?php echo $user['email'] ?>" name="email" required>
	<small></small>

	*Gostaria de receber Email dos Top Indicadores Piores: <br><br>
	<input type="checkbox" name="pref[]" value="1" <?php foreach ($pref as $f) {if($f == 1) echo 'checked';} ?>> Processo<br>
  	<input type="checkbox" name="pref[]" value="2" <?php foreach ($pref as $f) {if($f == 2) echo 'checked';} ?>> Qualidade<br>
  	<input type="checkbox" name="pref[]" value="3" <?php foreach ($pref as $f) {if($f == 3) echo 'checked';} ?>> Consumo<br>
  	<small></small>

	*Frequencia: <br><br>
	<input type="checkbox" name="freq[]" value="d" <?php foreach ($freq as $f) {if($f == 'd') echo 'checked';} ?>> Sumario Diario (Envio automatico todo dia as 8h)<br>
  	<input type="checkbox" name="freq[]" value="s" <?php foreach ($freq as $f) {if($f == 's') echo 'checked';} ?>> Sumario Semanal (Envio automatico toda sexta as 8h)<br>
  	<small></small>

  	<input type="submit" value="Atualizar">
	</form>

	<?php if(isset($_GET['swal'])) echo "<script>swal('Atualizado','','success');</script>" ?>

</div>
</div>