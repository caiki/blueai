<div id="loader">
<center>
  <div class="wdt-loading-screen">
    <div class="wdt-loading-phrases">

      <div class="wdt-loading-phrase-category" data-category="default">
        <div class="wdt-loading-phrase">Estabelecendo conexão segura...</div>
        <div class="wdt-loading-phrase">Buscando Hospitais...</div>
        <div class="wdt-loading-phrase">Buscando Vigitel...</div>
        <div class="wdt-loading-phrase">Buscando dataSUS...</div>
        <div class="wdt-loading-phrase">Integrando informações...</div>
      </div>

    </div>
    <div class="wdt-loading-bar-wrap"><div class="wdt-loading-bar"><div class="progress"></div></div></div>
  </div>
</center>
</div>
<div id="content" class="box" style="display:none">
  <div class="tab" style="background:#fff; padding:10px;">
    <div class="row">
      <div class="col-md-9">
        <div style="padding: 10px 0px 15px 15px;">
          <h1 style="font-weight:400; margin:0; padding-bottom:5px;">
            <?php $arr = explode(" ", $kpi->cadastro->nome); $i = 0;
            foreach($arr as $aux) {
              if($i==0) {
                echo $aux;
              }
              else {
                echo ' ';
                $length = strlen($aux) - 1;
                echo substr($aux, 0, 1);
                echo str_repeat("●", $length);
              }
              $i++;
            }
            ?>
          </h1>
          <p>Nasceu em <?php echo $kpi->cadastro->dataNascimento; ?>, <?php echo $kpi->cadastro->idade; ?> anos, de <?php echo $kpi->cadastro->signo; ?>.</p>
        </div>
      </div>
      <div class="col-md-2">
        <a href="javascript: void(0)" onclick='swal({
        title: "Paciente não deseja utilizar seus dados para consulta?",
        text: "Uma vez deletado, você não será capaz de recuperar este histórico novamente!",
        icon: "warning",
        buttons: true,
        dangerMode: true,
      })
      .then((willDelete) => {
        if (willDelete) {
          swal("Dados do paciente removidos!", {
            icon: "success",
          }).then((event) => {window.location.href = "./";})
        } else {
          swal("Seus dados estão seguros!");
        }
      });'><img src="./images/lock.png" width=16 style="margin:5px; vertical-align: middle">Privacidade</a>
      </div>
      <div class="col-md-1">
        <a href="javascript: void(0)" onclick="openTab(event, 'ajuda')"><img src="./images/help.png" width=16 style="margin:5px; vertical-align: middle">Ajuda</a>
      </div>
    </div>
    <div class="row" style="padding: 10px 0px 15px 15px;">
      <div class="col-md-4">
        Documento: <span style="color:blue"><?php echo '●●●.●●●.●●●-'.substr($kpi->cadastro->cpf, -2); ?></span>
        <br>
        Provável óbito: <span style="color:<?php $aux = $kpi->cadastro->obitoProvavel; if($aux === 'SIM') echo 'red'; else echo 'green';?>"><?php echo $aux ?></span>
      </div>
      <div class="col-md-4">
        Faixa de idade: <?php echo $kpi->cadastro->faixaIdade; ?>
        <br />
        Sexo: <?php if ($kpi->cadastro->sexo === 'M') echo 'Masculino'; else echo 'Feminino'; ?>
      </div>
      <div class="col-md-4">
        Geralmente frequenta hospitais em: <u><?php echo $kpi->enderecos[0]->uf; ?></u>
      </div>
    </div>
      <div class="row" style="padding: 10px 15px 15px 15px;">
        <section>
        <div class="col-md-4">
          <h2 style="font-weight:400;">Índice Geral de Saúde</h2>
          <br />
          <div id="highcharts" style="max-width:80%; height:300px">
          </div>
        </div>
        <div class="col-md-8">
          <h2 style="font-weight:400;">Tendências Genéticas</h2>
          <div class="row">
            <div class="col-md-1">
              <div class="dna" style="--strands: 16;">
                <div class="strand" style="--s: 0;"></div>
                <div class="strand" style="--s: 1;"></div>
                <div class="strand" style="--s: 2;"></div>
                <div class="strand" style="--s: 3;"></div>
                <div class="strand" style="--s: 4;"></div>
                <div class="strand" style="--s: 5;"></div>
                <div class="strand" style="--s: 6;"></div>
                <div class="strand" style="--s: 7;"></div>
                <div class="strand" style="--s: 8;"></div>
                <div class="strand" style="--s: 9;"></div>
                <div class="strand" style="--s: 10;"></div>
                <div class="strand" style="--s: 11;"></div>
                <div class="strand" style="--s: 12;"></div>
                <div class="strand" style="--s: 13;"></div>
                <div class="strand" style="--s: 14;"></div>
                <div class="strand" style="--s: 15;"></div>
              </div>
            </div>
            <div class="col-md-9">
              <?php
                echo '<a style="color:#0099cc" href="./?cpf=' . $kpi->cadastro->maeCpf . '">';

                $arr = explode(" ", $kpi->cadastro->maeNome); $i = 0;
                foreach($arr as $aux) {
                  if($i==0) {
                    echo $aux;
                  }
                  else {
                    echo ' ';
                    $length = strlen($aux) - 1;
                    echo substr($aux, 0, 1);
                    echo str_repeat("●", $length);
                  }
                  $i++;
                }

                 echo '</a> (Mãe)<br>';
                foreach($relatives->localizePessoasRelacionadas as $obj)
                {
                  if($obj->relacao === 'Avó' or $obj->relacao === 'Possível Parente') {
                    echo '<a style="color:#0099cc" href="./?cpf=' . $obj->documento . '">';

                    $arr = explode(" ", $obj->nome); $i = 0;
                    foreach($arr as $aux) {
                      if($i==0) {
                        echo $aux;
                      }
                      else {
                        echo ' ';
                        $length = strlen($aux) - 1;
                        echo substr($aux, 0, 1);
                        echo str_repeat("●", $length);
                      }
                      $i++;
                    }

                     echo '</a> (' . $obj->relacao . ')<br>';
                   }
                }
              ?>
            </div>
          </div>
          <div class="row" style="padding: 0px 0px 15px 15px;">
            <h2 style="font-weight:400;">Análise de Risco</h2>
            <div class="col-md-3 card" id="hide1" style="padding:10px; border-radius: 5px; border:2px solid #ddd">
              <center>
                <img src="./images/loading.gif" width="150"  />
              </center>
            </div>
            <div class="col-md-3 card" id="show1" style="display:none; padding:10px; border-radius: 5px; border:2px solid <?php if($heart >= 10) echo 'red'; else echo 'green'; ?>">
              <center>
                  <h1><b><?php echo $heart; ?>%</b></h1>
                  <img src="./images/pulse.gif" width="60"/>
                  <br /><b>Doenças Cardiovasculares</b><br /><i>chance próximos 10 anos</i><br />
              </center>
            </div>
            <div class="col-md-3 col-md-offset-1 card" id="hide2" style="padding:10px; border-radius: 5px; border:2px solid #ddd">
              <center>
                <img src="./images/loading.gif" width="150"  />
              </center>
            </div>
            <div class="col-md-3 col-md-offset-1 card" id="show2" style="display:none; padding:10px; border-radius: 5px; border:2px solid <?php if($diab >= 10) echo 'red'; else echo 'green'; ?>">
              <center>
                <h1><b><?php echo $diab; ?>%</b></h1>
                <img src="./images/pulse.gif" width="60"/>
                <br /><b>Diabetes Tipo 2</b><br /><i>chance próximos 5 anos</i><br />
              </center>
            </div>
            <div class="col-md-3 col-md-offset-1 card" id="hide3" style="padding:10px; border-radius: 5px; border:2px solid #ddd">
              <center>
                <img src="./images/loading.gif" width="150"  />
              </center>
            </div>
            <div class="col-md-3 col-md-offset-1 card" id="show3" style="display:none; padding:10px; border-radius: 5px; border:2px solid grey; background:#eee; ?>">
              <center>
                <h1 style="font-weight:normal; color:#888;">+ MÓDULOS <img src="./images/arrow-down.png" width="15" style="opacity:0.6"/></h1>

                <br /><b style="color:#999">...</b><br /><i style="color:#999">chance próximos ... anos</i><br />
              </center>
            </div>
          </div>
        </div>
        </section>
      </div>
      <div class="row" style="padding: 10px 15px 15px 15px;">
        <section>
          <div class="col-md-12">
            <h2 style="font-weight:400;">Histórico de Saúde</h2>
            <?php echo Blue::GetTimeline($cpf); ?>
          </div>
        </section>
      </div>
  </div>
</div>
