<div id="config" class="box tabs tabcontent" style="padding:5px 20px 5px 20px;">
	<div id="settings" class="ajustes">
	</div>
</div>

<script>$(document).ready(function(){openConfig('undefined', 'criarNovoKpi');});</script>