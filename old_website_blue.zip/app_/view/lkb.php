<?php

ob_implicit_flush(true);
ob_start();
if (ob_get_level() == 0) ob_start();

echo str_repeat(' ',1024*64);

flush();

	require_once('./app/sql.php');
	require_once('./app/piwebapi.php');

?>
<style>
.table > tbody > tr > td {line-height: 1 !important;}
.exp {width:150px !important; word-break: break-all;}
small {font-style: normal !important; margin:0 !important;}
</style>
<div class="box tabs tabcontent" style="padding:5px 20px 5px 20px; margin:10px 0 10px 0;">
<div class="ajustes">
	<h1>Tabela de KPIs</h1>

<?php
	$areas = array(1, 2, 3);
	foreach($areas as $area) {
		switch($area) {
			case 1:
				$aux = 'Processo'; break;
			case 2:
				$aux = 'Qualidade'; break;
			case 3:
				$aux = 'Consumo'; break;
		}
		echo '<h2>'.$aux.'</h2>
		<table class="table table-striped table-hover table-condensed">
		  <thead>
		    <tr>
		      <th>#</th>
		      <th>ID</th>
		      <th>URI</th>
		      <th>Nome</th>
		      <th>Tag</th>
		      <th>Exp Inst</th>
		      <th>Exp Diario</th>
		      <th>Exp Mensal</th>
		      <th>LIE <small style="font-weight:normal">(AF)</small></th>
		      <th>Meta <small style="font-weight:normal">(AF)</small></th>
		      <th>LSE <small style="font-weight:normal">(AF)</small></th>
		      <th></th>
		    </tr>
		  </thead>
		  <tbody>';

		$rows = SQL::listaKpisArea($sql, $area);
		$i = 1;
		foreach($rows as $row) {
			$id = $row['id'];
			$path = str_replace([POSFIXAF, POSFIXAF2], '', $row['paths']); 
			$nome = $row['nome'];
			$tag = $row['pipointname'];
			$ei = $row['expressioni'];
			$ed = $row['expressiond'];
			$em = $row['expressionm'];
			$paths = PREFIXAF.str_replace(PREFIXAF, '', $row['paths']);
			echo '<tr>';
			echo '<th>'.$i.'</th>';
			echo '<td>'.$id.'</td>';
			echo '<td class="exp"><small>'.$path.'<small></td>';
			echo '<td><a href="./?nome='.urlencode($nome).'">'.$nome.'</td>';
			echo '<td><small>'.$tag.'<small></td>';
			echo '<td class="exp"><small>'.$ei.'</small></td>';
			echo '<td class="exp"><small>'.$ed.'</small></td>';
			echo '<td class="exp"><small>'.$em.'</small></td>';
			echo '<th>'.PIWebAPI::GetAFConstantValue($paths.'|LIE').'</th>';
			echo '<th>'.PIWebAPI::GetAFConstantValue($paths.'|Meta').'</th>';
			echo '<th>'.PIWebAPI::GetAFConstantValue($paths.'|LSE').'</th>';
?>
			<td><a href="javascript: void(0)" onclick="openConfig(<?php echo "'$nome'"; ?>, 'modificar');"  data-toggle="modal" data-target="#modalConfig"><img title="Modificar" alt="Modificar" src="./images/settings.gif"></a></td>
<?php
			echo '</tr>';
			$i++;
echo str_pad('',4096)."\n";  
			ob_flush();
        flush();
		}
?>
	  </tbody>
	</table>
<?php } ob_end_flush();?>
</div>
</div>

<!-- Modal Modificar -->
<div class="modal fade" id="modalConfig" tabindex="-1" role="dialog" aria-hidden="true">
  <div class="modal-dialog modal-lg" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" style="float:left">Configurações</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close" style="float:right">
          <span aria-hidden="true" style="font-size:2em;">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        <div id="settings" class="ajustes"></div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal" style="font-size:1em;">Fechar</button>
      </div>
    </div>
  </div>
</div>