<link href="./css/busca.css" rel="stylesheet" type="text/css">
<center><h1>Bem-Vindo à nova ferramenta Blue.Ai</h1></center>
<center>
  <h3>Digite o CPF do paciente abaixo:</h3>
  <br>
  <form id="search1">
    <input type="search" placeholder="Busca inteligente" name="busca" id="passwd1">
  </form>
</center>
<br />
<p style="position:fixed; left:10px; bottom:30px; font-size:11px">Esta aplicação foi desenvolvida por <a href="https://blue4me.com" target="_blank"><b>Blue4me.com</b></a>. Entre em contato com a equipe Blue em caso de dúvidas ou sugestões.</p>
<br>
<script src="./js/busca-inteligente.js"></script>
<style>footer {display:none;}</style>
