<!--[if lte IE 8]>
<div class="alert alert-warning">
  <strong>AVISO!</strong> A versão do seu Internet Explorer está desatualizada para a ferramenta. <a href="https://www.microsoft.com/pt-br/download/Internet-Explorer-11-for-Windows-7-details.aspx" target="_blank"><u>Atualize</u></a> ou utilize o navegador recomendado <a href="https://www.google.com/chrome/" target="_blank"><u>Google Chrome</u></a>.
</div>
<![endif]-->
<div id="nav">
  <nav class="fixed-top">
    <div class="nav-fostrap">
      <ul>
        <li><a href="./" style="padding:0; padding-left:10px; background:#fff !important"><img src="./images/blue-logo.png" height=35></a></li>
        <li><a href="./">Início <img src="./images/home.png" width=14 style="margin:5px; vertical-align: middle"></a></li>
        <li><a>Busca Inteligente:</a>
          <form id="search2" style="display:inline;">
          <input class="input" size=50 id="passwd" name="indicador" placeholder="Digite o CPF do paciente..." type="text" value="">
          </form>
        </li>
        </li>
        <?php if(isset($_SESSION['username'])) { ?>
        <li><a href="./?req=usr">Usuário <img src="./images/user.png" width=16 style="margin:5px; vertical-align: middle"></a></li>
        <li><a href="./app/logout.php">Sair <img src="./images/logout.png" width=16 style="margin:5px; vertical-align: middle"></a></li>
        <?php } ?>
      </ul>
    </div>
    <div class="nav-bg-fostrap">
      <div class="navbar-fostrap"> <span></span> <span></span> <span></span> </div>
      <a href="" class="title-mobile">Blue.Ai</a>
    </div>
  </nav>
</div>
<?php if(isset($_SESSION['username'])): ?>


<?php endif; ?>
