<?php

require_once('config.php');

class PIWebAPI
{	

	public static function auth($postuser, $postpass)
	{
		$username = $postuser;
		$password = $postpass;

		$ch = curl_init(PIWEBAPI_URL);
		curl_setopt($ch, CURLOPT_HEADER, false);
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
		curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
		curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
		curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
		curl_setopt($ch, CURLOPT_HTTPAUTH, CURLAUTH_BASIC);
		curl_setopt($ch, CURLOPT_USERPWD, $username.':'.$password); 
		$result = json_decode(curl_exec($ch));

		if (isset($result->Links))
			return true;
		else
			return false;
	}	

	public static function CheckIfPIPointExists($piServerName, $piPointName)
	{
		$url = PIWEBAPI_URL . 'points?path=\\\\' . SERVERNAME . '\\' . $piPointName;
		$obj1 = PIWebAPI::GetJSONObject($url);
		try {
		if(($obj1->Name)!=null)
			return (true);
		else
			return (false);
		}
		catch (Exception $e) {
		
		}
	}

	public static function GetORTSRVPIWebId()
	{
		$service_url = PIWEBAPI_URL . '/dataservers';
		$obj = PIWebAPI::GetJSONObject($service_url);
		foreach ($obj->Items as $Item) {
			if($Item->Name == 'ORTSRVPI')
				return $Item->WebId;
		}
	}

	public static function GetAFWebId()
	{
		$service_url = PIWEBAPI_URL . '/dataservers';
		$obj = PIWebAPI::GetJSONObject($service_url);
		foreach ($obj->Items as $Item) {
			if($Item->Name == 'ORTSRV008-VM')
				return $Item->WebId;
		}
	}

	public static function GetPIPoint($piPointName) //ORTSRVPI
	{
		$service_url = PIWEBAPI_URL . 'points?path=\\\\' . SERVERNAME . '\\' . $piPointName;
		return PIWebAPI::GetJSONObject($service_url);
	}

	public static function GetAFPoint($path) //ORTSRV008-VM
	{
		$service_url = PIWEBAPI_URL . 'attributes?path=\\' . urlencode($path);
		return PIWebAPI::GetJSONObject($service_url);
	}

	public static function GetAFPointCron($path) //ORTSRV008-VM
	{
		$service_url = PIWEBAPI_URL . 'attributes?path=\\' . urlencode($path);
		return PIWebAPI::GetJSONObjectCron($service_url);
	}

	public static function GetCompressedValues($piPointName,$startTime,$endTime,$filter)
	{
		$obj_pipoint = PIWebAPI::GetPIPoint($piPointName);
		$url = $obj_pipoint->Links->{'RecordedData'} .'?starttime=' . $startTime . '&endtime=' . $endTime . '&maxcount=99999';
		if($filter) $url .= '&filterexpression=' . urlencode($filter);
		$obj = PIWebAPI::GetJSONObject($url);
		return $obj;
	}

	public static function GetInterpolatedValues($piPointName,$startTime,$endTime,$interval,$filter)
	{
		$obj_pipoint = PIWebAPI::GetPIPoint($piPointName);
		$url = $obj_pipoint->Links->{'InterpolatedData'} .'?starttime=' . $startTime . '&endtime=' . $endTime . '&interval=' . $interval;
		if($filter) $url .= '&filterexpression=' . urlencode($filter);
		$obj = PIWebAPI::GetJSONObject($url);
		return $obj;
	}
	
	public static function GetAFConstantValue($path)
	{
		$obj_pipoint = PIWebAPI::GetAFPoint($path);
		if(isset($obj_pipoint->Links->{'Value'})) {
			$url = $obj_pipoint->Links->{'Value'};
			$obj_value = PIWebAPI::GetJSONObject($url);
			return $obj_value->Value;
		}
		else
			return null;
	}

	public static function GetAFConstantValueCron($path)
	{
		$obj_pipoint = PIWebAPI::GetAFPointCron($path);
		if(isset($obj_pipoint->Links->{'Value'})) {
			$url = $obj_pipoint->Links->{'Value'};
			$obj_value = PIWebAPI::GetJSONObjectCron($url);
			return $obj_value->Value;
		}
		else
			return null;
	}

	public static function SearchPoint($piPointName)
	{
		$service_url = PIWEBAPI_URL . 'search/query?q=name:' . $piPointName;
		$obj_pipoint = PIWebAPI::GetJSONObject($service_url);
		var_dump($obj_pipoint);
	}

	public static function checkURL($url)
	{
		$obj_pipoint = PIWebAPI::GetJSONObject($url);
		var_dump($obj_pipoint->Items[0]->Name);
	}

    public static function GetCalculationExpression($expression, $startTime, $endTime, $summaryType, $calculationBasis, $interval) {
        $url = PIWEBAPI_URL . "calculation/summary?webId=" . PIWebAPI::GetORTSRVPIWebId() . "&expression=" . urlencode($expression) . "&starttime=" . $startTime . "&endtime=" . $endTime . "&summarytype=" . $summaryType . "&calculationbasis=" . $calculationBasis;
        if($interval) $url .= "&summaryduration=" . $interval;
		$obj = PIWebAPI::GetJSONObject($url);
		return $obj;
    }

    public static function GetInstCalculationExpression($expression, $startTime, $summaryType, $calculationBasis, $interval) {
        $url = PIWEBAPI_URL . "calculation/summary?webId=" . PIWebAPI::GetORTSRVPIWebId() . "&expression=" . urlencode($expression) . "&summarytype=" . $summaryType . "&calculationbasis=" . $calculationBasis;
        if($startTime) $url .= "&starttime=" . $startTime;
        if($interval) $url .= "&summaryduration=" . $interval;
		$obj = PIWebAPI::GetJSONObject($url);
		return $obj;
    }
	
    public static function GetCalculationValues($piPointName, $startTime, $endTime, $summaryType, $calculationBasis, $interval) {
        $url = PIWEBAPI_URL . "calculation/summary?expression='\\\\" . SERVERNAME . "\\" . $piPointName . "'&starttime=" . $startTime . "&endtime=" . $endTime . "&summarytype=" . $summaryType . "&calculationbasis=" . $calculationBasis . "&summaryduration=" . $interval;
		$obj = PIWebAPI::GetJSONObject($url);
		return $obj;
    }

    public static function GetSummaryValues($piPointName, $startTime, $endTime, $summaryType, $calculationBasis, $interval, $filter) {
		$obj_pipoint = PIWebAPI::GetPIPoint($piPointName);
		$url = $obj_pipoint->Links->{'SummaryData'} . '?starttime=' . $startTime . '&endtime=' . $endTime . '&summarytype=' . $summaryType . '&calculationbasis=' . $calculationBasis . '&summaryduration=' . $interval;
		if($filter) $url .= '&filterexpression=' . urlencode($filter);
		$obj = PIWebAPI::GetJSONObject($url);
		return $obj;
    }

    public static function BuildArray($Items)
    {
    	$array = array();
    	foreach($Items as $item)
    	{
    		if(isset($item->Value->Value))
				array_push($array, $item->Value->Value);
			else
				array_push($array, $item->Value);
    	}
    	return $array;
    }

    public static function GetAverage(array $a)
    {
    	$n = count($a);
    	if($n == 0)
    		return 0;
    	else
    		return array_sum($a) / $n;
    }

    public static function GetStdev(array $a) {
        $n = count($a);
        if ($n <= 1) {
            return 0;
        }

        $mean = array_sum($a) / $n;
        $carry = 0.0;
        foreach ($a as $val) {
            $d = ((double) $val) - $mean;
            $carry += $d * $d;
        }

        return sqrt($carry / $n);
    }
/*
    public static function GetAverage($Items)
    {
    	$i = 0;
    	$sum = 0;
    	foreach($Items as $item)
    	{
    		$i++;
    		if(isset($item->Value->Value))
				$sum += $item->Value->Value;
			else
				$sum += $item->Value;
    	}
    	if($i == 0)
    		return 0;
    	else
    		return $sum/$i;
    }
*/
	private static function GetJSONObject($url)
	{
		if(!isset($_SESSION['username']))
		{
		    header('Location:'.$_SERVER['PHP_SELF'].'?'.$_SERVER['QUERY_STRING']);
		    die;
		}

		$username = $_SESSION['username'];
		$password = $_SESSION['password'];

		$ch = curl_init($url);
		curl_setopt($ch, CURLOPT_HEADER, false);
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
		curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
		curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
		curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
		curl_setopt($ch, CURLOPT_HTTPAUTH, CURLAUTH_BASIC);
		curl_setopt($ch, CURLOPT_USERPWD, $username.':'.$password); 
		$result = curl_exec($ch);
		return json_decode($result);
	}	

	private static function GetJSONObjectCron($url)
	{
		$username = ADMINUSER;
		$password = ADMINPASS;

		$ch = curl_init($url);
		curl_setopt($ch, CURLOPT_HEADER, false);
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
		curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
		curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
		curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
		curl_setopt($ch, CURLOPT_HTTPAUTH, CURLAUTH_BASIC);
		curl_setopt($ch, CURLOPT_USERPWD, $username.':'.$password); 
		$result = curl_exec($ch);
		return json_decode($result);
	}	
}