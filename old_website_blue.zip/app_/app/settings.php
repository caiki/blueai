<?php

require_once('admin.php');

	if($_POST['nome'] != 'undefined') {
		require_once('sql.php');
		$kpi = SQL::GetKPI($sql, $_POST['nome']);

		if($kpi['owner'] == $_SESSION['username'])
			$config = true;
	}

	if($_POST['update'] == 'modificar'):
	?>
	  <form <?php if($config) echo 'action="./app/sql.php"';?> method="post">
	  	<input name="tipo" value="modificar" hidden>
	   	<input value="<?php echo $kpi['nome'] ?>" name="nome0" hidden>
	   	
	   	<?php if($kpi['categoria'] != 'KPIS AUXILIARES'): ?>
	    <label>Caminho Completo no AF</label>
	    <input type="text" value="<?php echo $kpi['paths'] ?>" name="paths" required <?php if(!$config) echo 'readonly';?>>
	    <small>Exemplo Klabin\Ortigueira\Ferramentas e Aplicações\...</small>
		<?php endif; ?>

	    <label>Nome do Indicador/Descrição no AF</label>
	    <input type="text" value="<?php echo $kpi['nome'] ?>" name="nome" <?php if(!$config) echo 'readonly';?>>
	    <small>Deve ser um identificador único</small>

	    <label>O indicador é uma Tag no PI ou uma Fórmula?</label><br>
		<input type="radio" name="varexp" value="variavel" <?php if($kpi['pipointname']) echo 'checked'; ?> <?php if(!$config) echo 'disabled';?>> Tag<br>
		<input type="radio" name="varexp" value="expressao" <?php if(!$kpi['pipointname']) echo 'checked'; ?> <?php if(!$config) echo 'disabled';?>> Fórmula<br>
		<small></small>

	    <label>Tag no PI</label>
	    <input type="text" name="pipointname" value="<?php echo $kpi['pipointname'] ?>" <?php if(!$kpi['pipointname']) echo 'readonly'; ?> <?php if(!$config) echo 'readonly';?>>
	    <small></small>

	    <label>Fórmula para KPI Instantâneo</label>
	    <input type="text" name="expressioni" value="<?php echo $kpi['expressioni'] ?>" <?php if($kpi['pipointname']) echo 'readonly'; ?> <?php if(!$config) echo 'readonly';?>>
	    <small>As variáveis de expressão são relativas ao atributo. Usar <b>'</b>.<b>'</b> para referenciar o atributo.</small>

	    <label>Fórmula para KPI Diário</label>
	    <input type="text" name="expressiond" value="<?php echo $kpi['expressiond'] ?>" <?php if($kpi['pipointname']) echo 'readonly'; ?> <?php if(!$config) echo 'readonly';?>>
	    <small>As variáveis de expressão são relativas ao atributo. Usar <b>'</b>.<b>'</b> para referenciar o atributo.</small>

	    <label>Fórmula para KPI Mensal</label>
	    <input type="text" name="expressionm" value="<?php echo $kpi['expressionm'] ?>" <?php if($kpi['pipointname']) echo 'readonly'; ?> <?php if(!$config) echo 'readonly';?>>
	    <small>As variáveis de expressão são relativas ao atributo. Usar <b>'</b>.<b>'</b> para referenciar o atributo.</small>

	    <label>A variável é de Laboratório?</label><br>
		<input type="radio" name="lab" value="true" <?php if($kpi['lab']) echo 'checked'; ?> <?php if(!$config) echo 'disabled';?>> Sim<br>
		<input type="radio" name="lab" value="false" <?php if(!$kpi['lab']) echo 'checked'; ?> <?php if(!$config) echo 'disabled';?>> Não<br>
		<small></small>

	    <label>Base de Cálculo</label><br>
	    <input type="radio" name="calculationbasis" value="eventweighted" <?php if($kpi['calculationbasis'] == 'eventweighted') echo 'checked';?> <?php if(!$config) echo 'disabled';?>> eventweighted<br>
		<input type="radio" name="calculationbasis" value="timeweighted" <?php if($kpi['calculationbasis'] == 'timeweighted') echo 'checked';?> <?php if(!$config) echo 'disabled';?>> timeweighted<br>
	    <small></small>

	    <label>Filtro</label>
	    <input type="text" value="<?php echo $kpi['filter']; ?>" name="filter" <?php if(!$kpi['pipointname']) echo 'readonly'; ?> <?php if(!$config) echo 'readonly';?>>
	    <small>As variáveis de expressão são relativas ao atributo. Usar <b>'</b>.<b>'</b> para referenciar o atributo.</small>

	    <label>Unidade</label>
	    <input type="text" name="unit" value="<?php echo $kpi['unit']; ?>" <?php if(!$config) echo 'readonly';?>>
	    <small>Deixe em branco para puxar automaticamente do AF.</small>

	    <label>Auto escala?</label><br>
		<input type="radio" name="autoscale" value="true" <?php if(!$kpi['max']) echo 'checked'; ?> <?php if(!$config) echo 'disabled';?>> Sim<br>
		<input type="radio" name="autoscale" value="false" <?php if($kpi['max']) echo 'checked'; ?> <?php if(!$config) echo 'disabled';?>> Não<br>
		<small>Selecione "Sim" para que o gráfico se autoregule. Selecione "Não" para definir máximos e mínimos.</small>

	    <label>Máximo</label>
	    <input type="number" name="max" value="<?php echo $kpi['max']; ?>" step="any" <?php if($kpi['max']) echo 'required'; ?> <?php if(!$kpi['max'] || !$config) echo 'readonly';?>>
	    <label>Mínimo</label>
	    <input type="number" name="min" value="<?php echo $kpi['min']; ?>" step="any" <?php if($kpi['min']) echo 'required'; ?> <?php if(!$kpi['max'] || !$config) echo 'readonly';?>>
	    <small></small>

	    <?php if($config) echo '<input type="submit" value="SALVAR MODIFICAÇÕES">';
	    else echo "<h3>APENAS USUÁRIOS ADMINISTRADORES PODEM ALTERAR PERMANENTEMENTE OS KPIS<br>ACESSE A ABA <b>'AJUSTES'</b> PARA MODIFICAÇÕES TEMPORÁRIAS</h3>"; ?>

	  </form>
	  <p><br></p>
	  <?php if($config): ?>
	  <form id="deletar" action="./app/sql.php" method="post" onsubmit="return confirm('Tem certeza que deseja deletar este KPI?');">
	  	<input name="tipo" value="deletar" hidden>
	  	<input name="nome" value="<?php echo $kpi['nome'] ?>" hidden>
	  	<input style="background-color:red;" type="submit" value="DELETAR KPI">
	  </form>
	  <?php endif; ?>
	<?php 
		elseif ($config and $_POST['update'] == 'criarNovoKpi'):
	?>
	<h1>CRIAR NOVO KPI</h1>
	<p><br></p>
	  <form action="./app/sql.php" method="post">
	  	<input name="tipo" value="criar" hidden>

	    <label>Caminho Completo no AF</label>
	    <input type="text" value="" name="paths" required>
	    <small>Exemplo Klabin\Ortigueira\Ferramentas e Aplicações\...</small>

	    <label>Nome do Indicador/Descrição no AF</label>
	    <input type="text" value="" name="nome" required>
	    <small>Deve ser um identificador único</small>

	    <label>O indicador é uma Tag no PI ou uma Fórmula?</label><br>
		<input type="radio" name="varexp" value="variavel" checked> Tag<br>
		<input type="radio" name="varexp" value="expressao"> Fórmula<br>
		<small></small>

	    <label>Tag no PI</label>
	    <input type="text" name="pipointname" value="">
	    <small></small>

	    <label>Fórmula para KPI Instantâneo</label>
	    <input type="text" name="expressioni" value="" readonly>
	    <small>As variáveis de expressão são relativas ao atributo. Usar <b>'</b>.<b>'</b> para referenciar o atributo.</small>

	    <label>Fórmula para KPI Diário</label>
	    <input type="text" name="expressiond" value="" readonly>
	    <small>As variáveis de expressão são relativas ao atributo. Usar <b>'</b>.<b>'</b> para referenciar o atributo.</small>

	    <label>Fórmula para KPI Mensal</label>
	    <input type="text" name="expressionm" value="" readonly>
	    <small>As variáveis de expressão são relativas ao atributo. Usar <b>'</b>.<b>'</b> para referenciar o atributo.</small>

	    <label>A variável é de Laboratório?</label><br>
		<input type="radio" name="lab" value="true"> Sim<br>
		<input type="radio" name="lab" value="false" checked> Não<br>
		<small></small>

	    <label>Base de Cálculo</label><br>
	    <input type="radio" name="calculationbasis" value="eventweighted" checked> eventweighted<br>
		<input type="radio" name="calculationbasis" value="timeweighted"> timeweighted<br>
	    <small></small>

	    <label>Filtro</label>
	    <input type="text" value="" name="filter">
	    <small>As variáveis de expressão são relativas ao atributo. Usar <b>'</b>.<b>'</b> para referenciar o atributo.</small>

	    <label>Unidade</label>
	    <input type="text" name="unit" value="" maxlength="15">
	    <small>Deixe em branco para puxar automaticamente do AF.</small>

	    <label>Auto escala?</label><br>
		<input type="radio" name="autoscale" value="true" checked> Sim<br>
		<input type="radio" name="autoscale" value="false"> Não<br>
		<small>Selecione "Sim" para que o gráfico se autoregule. Selecione "Não" para definir máximos e mínimos.</small>

	    <label>Máximo</label>
	    <input type="number" name="max" value="" step="any" readonly>
	    <label>Mínimo</label>
	    <input type="number" name="min" value="" step="any" readonly>
	    <small></small>
	  
	    <input type="submit" value="CRIAR NOVO KPI">
	  </form>

	<?php
		elseif ($_POST['update'] == 'criarKpiAux'):
	?>
	<h1>CRIAR NOVO KPI AUXILIAR</h1>
	<p><br></p>
	  <form action="./app/sql.php" method="post">
	  	<input name="tipo" value="criar" hidden>
	    <input value="KPIS AUXILIARES" name="categoria2" hidden>

	    <label>Nome do Indicador</label>
	    <input type="text" value="" placeholder="[SEU NOME] Nome do Indicador" name="nome" required>
	    <small>Dica: Utilize [SEU NOME] na frente do Indicador para facilitar a busca</small>

	    <label>O indicador é uma Tag no PI ou uma Fórmula?</label><br>
		<input type="radio" name="varexp" value="variavel" checked> Tag<br>
		<input type="radio" name="varexp" value="expressao"> Fórmula<br>
		<small></small>

	    <label>Tag no PI</label>
	    <input type="text" name="pipointname" value="">
	    <small></small>

	    <label>Fórmula para KPI Instantâneo</label>
	    <input type="text" name="expressioni" value="" readonly>
	    <small>As variáveis de expressão são relativas ao atributo. Usar <b>'</b>.<b>'</b> para referenciar o atributo.</small>

	    <label>Fórmula para KPI Diário</label>
	    <input type="text" name="expressiond" value="" readonly>
	    <small>As variáveis de expressão são relativas ao atributo. Usar <b>'</b>.<b>'</b> para referenciar o atributo.</small>

	    <label>Fórmula para KPI Mensal</label>
	    <input type="text" name="expressionm" value="" readonly>
	    <small>As variáveis de expressão são relativas ao atributo. Usar <b>'</b>.<b>'</b> para referenciar o atributo.</small>

	    <label>A variável é de Laboratório?</label><br>
		<input type="radio" name="lab" value="true"> Sim<br>
		<input type="radio" name="lab" value="false" checked> Não<br>
		<small></small>

	    <label>Base de Cálculo</label><br>
	    <input type="radio" name="calculationbasis" value="eventweighted" checked> eventweighted<br>
		<input type="radio" name="calculationbasis" value="timeweighted"> timeweighted<br>
	    <small></small>

	    <label>Filtro</label>
	    <input type="text" value="" name="filter">
	    <small>As variáveis de expressão são relativas ao atributo. Usar <b>'</b>.<b>'</b> para referenciar o atributo.</small>

	    <label>Unidade</label>
	    <input type="text" name="unit" value="" maxlength="15">
	    <small></small>

	    <label>Auto escala?</label><br>
		<input type="radio" name="autoscale" value="true" checked> Sim<br>
		<input type="radio" name="autoscale" value="false"> Não<br>
		<small>Selecione "Sim" para que o gráfico se autoregule. Selecione "Não" para definir máximos e mínimos.</small>

	    <label>Máximo</label>
	    <input type="number" name="max" value="" step="any" readonly>
	    <label>Mínimo</label>
	    <input type="number" name="min" value="" step="any" readonly>
	    <small></small>
	  
	    <input type="submit" value="CRIAR NOVO KPI AUXILIAR">
	  </form>

	<?php
	else:
		echo "<h3>APENAS USUÁRIOS ADMINISTRADORES PODEM ALTERAR PERMANENTEMENTE OS KPIS<br><br>ACESSE A ABA <b>'AJUSTES'</b> PARA MODIFICAÇÕES TEMPORÁRIAS</h3>";
	endif;
	?>
	<script>
	$(document).ready(function() {
	    $('input[type=radio][name=varexp]').change(function() {
	        if (this.value == 'variavel') {
	        	$('input[name=pipointname]').prop('readonly', false);
	            $('input[name=expressioni]').prop('readonly', true);
	            $('input[name=expressiond]').prop('readonly', true);
	            $('input[name=expressionm]').prop('readonly', true);
	            $('input[name=filter]').prop('readonly', false);
	        }
	        else if (this.value == 'expressao') {
	        	$('input[name=pipointname]').prop('readonly', true);
	            $('input[name=expressioni]').prop('readonly', false);
	            $('input[name=expressiond]').prop('readonly', false);
	            $('input[name=expressionm]').prop('readonly', false);
	            $('input[name=filter]').prop('readonly', true);
	        }
	    });
	    $('input[type=radio][name=autoscale]').change(function() {
	    	$('input[name=max]').val('');
	    	$('input[name=min]').val('');
	        if (this.value == 'true') {
	        	$('input[name=max]').prop('readonly', true);
	            $('input[name=min]').prop('readonly', true);
	        	$('input[name=max]').prop('required', false);
	            $('input[name=min]').prop('required', false);
	        }
	        else if (this.value == 'false') {
	        	$('input[name=max]').prop('readonly', false);
	            $('input[name=min]').prop('readonly', false);
	        	$('input[name=max]').prop('required', true);
	            $('input[name=min]').prop('required', true);
	        }
	    });
	});
	</script>