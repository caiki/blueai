<?php
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

require 'PHPMailer/Exception.php';
require 'PHPMailer/PHPMailer.php';
require 'PHPMailer/SMTP.php';

require 'user.php';
require 'top.php';
require 'sql.php';

$today = new DateTime();
$freq = array('s', 'd');
$flag = false;

foreach($freq as $f)
{
	$users = User::getAll($sql);
	
    if($f == 's' and date('D') != 'Fri')
        continue; //SKIP

    if($f == 's') {$subject = 'Sumario Semanal '; $catch = 'Nesta última semana';}
    else {$subject = 'Sumario Diario '; $catch = 'Nos últimos dias';}

    foreach($users as $u)
    {
        if($u['check'] == $today->format('d'))
            continue;

        if(!$u['freq'])
            continue;

        $foo = unserialize($u['freq']);
        $flag = false;
        foreach($foo as $fo)
        {
            if($fo == $f)
                $flag = true;
        }

        if(!$flag)
            continue;

        try {
            $mail = new PHPMailer(true);
            //$mail->SMTPDebug = 2;
            $mail->isSMTP();
            $mail->Host = '10.7.0.80';
            $mail->SMTPAuth = false; 
            $mail->SMTPAutoTLS = false;
            $mail->Port = 25;
            $mail->setFrom('no-reply-kpi@klabin.com.br', 'Klabin KPI');

            $mail->addAddress($u['email']); 

            $mail->isHTML(true);
            $mail->CharSet = 'UTF-8';
            $mail->Subject = 'Top Indicadores Fora - ' . $subject . $today->format('d/m/y');

            //HEADER
            $mail->Body = '<div><span style="font-size: normal;">Ol&aacute;, ' . $u['firstname'] . '!</span></div><div><span style="font-size: normal;">&nbsp;</span></div><div><span style="font-size: normal;">' . $catch . ', estes foram os&nbsp;<u>Top Indicadores Piores</u>&nbsp;que ficaram mais de '.TOLERANCE.'% fora de seus limites:</span></div><div><span style="font-size: normal;">&nbsp;</span></div>_';

            $area = unserialize($u['pref']);
            foreach($area as $a)
            {
                switch($a) {

                case 1:
                    $mail->Body .= '<div><span style="font-size: normal;"><strong>Processo:</strong></span></div>';
                    $subareas = SQL::listarSubAreas($sql, $a);
                    foreach($subareas as $sub) {
                        $mail->Body .= '<div><span style="font-size: normal;"><strong>◆ '.$sub.'</strong></span></div>';
                        if($f == 'd') $days = 2; else $days = 2;
                        $diai = new Datetime('today');
                        $diai->modify("-$days days");
                        $diaf = new Datetime('today');
                        $top = TOP::getTSA1($sql, 1, $sub, $diai->format('Y-m-d'), $diaf->format('Y-m-d'), TOLERANCE);
                        $mail->Body .= TOP::printMailBody($top);
                    }
                    break;

                case 2:
                    $mail->Body .= '<br><div><span style="font-size: normal;"><strong>Qualidade:</strong></span></div>';
                    $subareas = SQL::listarSubAreas($sql, $a);
                    foreach($subareas as $sub) {
                        $mail->Body .= '<div><span style="font-size: normal;"><strong>◆ '.$sub.'</strong></span></div>';
                        $days = 15;
                        $diai = new Datetime('today');
                        $diai->modify("-$days days");
                        $diaf = new Datetime('today');
                        $top = TOP::getTSA2($sql, 2, $sub, $diai->format('Y-m-d'), $diaf->format('Y-m-d'), TOLERANCE);
                        $mail->Body .= TOP::printMailBody($top);
                    }
                    break;

                case 3:
                    $mail->Body .= '<br><div><span style="font-size: normal;"><strong>Consumo:</strong></span></div>';
                    $subareas = SQL::listarSubAreas($sql, $a);
                    foreach($subareas as $sub) {
                        $mail->Body .= '<div><span style="font-size: normal;"><strong>◆ '.$sub.'</strong></span></div>';
                        $months = 0;
                        $diai = new Datetime('today');
                        $diai->modify("first day of this month");
                        if($months > 0)
                                $diai->modify("-$months months");
                        $diaf = new Datetime('today');
                        $top = TOP::getTSM($sql, 3, $sub, $diai->format('Y-m-d'), $diaf->format('Y-m-d'), TOLERANCE);
                        $mail->Body .= TOP::printMailBody($top);
                    }
                    break;
                }
                $mail->Body .= '_';
            }

            //FOOTER
            $mail->Body .= file_get_contents('../templates/emailtopfooter.php');

            echo $mail->Body;

            //$mail->send();
            echo 'Message has been sent';

            //User::updateCheck($sql, $u['id'], $today->format('d'));

        } catch (Exception $e) {
            echo 'Message could not be sent. Mailer Error: ', $mail->ErrorInfo;
        }
    }
}