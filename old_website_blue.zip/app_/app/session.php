<?php

	session_start();

	if(isset($_POST['nome']))
		$nome = $_POST['nome'];
	if(isset($_POST['tipo']))
		$tipo = $_POST['tipo'];
	if(isset($_POST['arr']))
		$arr = $_POST['arr'];

	if($tipo == 'r')
	{
		unset($_SESSION[$nome]['filter']);
	}
	else if($tipo == 'i')
	{
		if(is_array($arr))
		{
			$_SESSION['momentbegini'] = $arr[0];
			$_SESSION['momentendi'] = $arr[1];
		}
		else
		{
			unset($_SESSION['momentbegini']); unset($_SESSION['momentendi']); 
		}
	}
	else if($tipo == 'd')
	{
		if(is_array($arr))
		{
			$_SESSION['momentbegind'] = $arr[0];
			$_SESSION['momentendd'] = $arr[1];
		}
		else
		{
			unset($_SESSION['momentbegind']); unset($_SESSION['momentendd']); 
		}
	}
	else
	{
		$filter = $_POST['filter'];

		if(!isset($_SESSION[$nome]))
			$_SESSION[$nome] = array();

		$_SESSION[$nome]['filter'] = $filter;
	}