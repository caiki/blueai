<?php

require_once('db.php');

if(!isset($_SESSION)){session_start();}

class Hiop 
{
	public static function listaHiopPeriodo($sql, $kpid, $begin, $end, $on)
	{
		$on_inst = null;
		$on_day = null;
		$on_month = null;
		if($on == 'inst') $on_inst = 1;
		else if($on == 'day') $on_day = 1;
		else if($on == 'month') $on_month = 1;

		$query = $sql->prepare("SELECT * FROM hiop WHERE (kpid = ?) and (on_inst = ? or on_day = ? or on_month = ?) and (xaxis between ? and ?)"); 
		$query->bindParam(1, $kpid);
		$query->bindParam(2, $on_inst);
		$query->bindParam(3, $on_day);
		$query->bindParam(4, $on_month);
		$query->bindParam(5, $begin);
		$query->bindParam(6, $end);
		$query->execute(); 
		$rows = array();
		while($row = $query->fetch(PDO::FETCH_ASSOC))
		{
			$rows[] = $row;
		} 
		return $rows;
	}
	public static function createHiop($sql, $kpid, $xaxis, $yaxis, $user)
	{
		$query = $sql->prepare('INSERT INTO hiop (kpid, xaxis, yaxis, user) VALUES (?, ?, ?, ?)'); 
		$query->bindParam(1, $kpid);
		$query->bindParam(2, $xaxis);
		$query->bindParam(3, $yaxis);
		$query->bindParam(4, $user);
		$query->execute(); 

		$query = $sql->prepare('SELECT id FROM hiop WHERE user = ? ORDER BY id DESC'); 
		$query->bindParam(1, $user);
		$query->execute(); 
		$row = $query->fetch(); 
		return $row['id'];
	}
	public static function updateHiop($sql, $id,  $shortdesc, $longdesc, $on_inst, $on_day, $on_month)
	{
		$query = $sql->prepare('UPDATE hiop SET shortdesc = ?, longdesc = ?, on_inst = ?, on_day = ?, on_month = ? WHERE id = ?'); 
		$query->bindParam(1, $shortdesc);
		$query->bindParam(2, $longdesc);
		$query->bindParam(3, $on_inst);
		$query->bindParam(4, $on_day);
		$query->bindParam(5, $on_month);
		$query->bindParam(6, $id);
		$query->execute(); 
	}
	public static function deleteHiop($sql, $id)
	{
		$query = $sql->prepare('DELETE FROM hiop WHERE id=?'); 
		$query->bindParam(1, $id);
		$query->execute(); 
	}
}

if(isset($_POST['req']))
{
	if($_POST['req'] == 'delete')
	{
		Hiop::deleteHiop($sql, $_POST['id']);
	}
	else if($_POST['req'] == 'create')
	{
		$on = $_POST['on'];
		$on_inst = null;
		$on_day = null;
		$on_month = null;

		if($on == 'inst' || $on == 'day') {
			$on_inst = 1;
			$on_day = 1;
		}
		else if($on == 'month') {
			$on_month = 1;
		}

		$id = Hiop::createHiop($sql, $_POST['kpid'], $_POST['xaxis'], $_POST['yaxis'], $_SESSION['username']);
		Hiop::updateHiop($sql, $id, $_POST['shortdesc'], $_POST['longdesc'], $on_inst, $on_day, $on_month);
	}
}