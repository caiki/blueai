<?php

//CRON JOB UPDATE DATABASE

	$filehandle = fopen("lock.txt", "c+");

	//Prevent duplicate CronJobs
	if (flock($filehandle, LOCK_EX | LOCK_NB)) {

	require_once('piwebapi.php');
	require_once('sql.php');
	require_once('top.php');


	$Processo = TOP::Processo($sql);
	$Qualidade = TOP::Qualidade($sql);
	$Consumo = TOP::Consumo($sql);


////////////////////////////////DIA ANTERIOR////////////////////////////////////

	$dia = new Datetime('today');
	$dia->modify('-1 day');

//Area 1 = Processo DIA ANT
	$area = 1;
	if(!TOP::checkTDA($sql, $area, $dia->format('Y-m-d')))
	{
		$top = array();
		foreach($Processo as $kpi)
		{
			$kpid = $kpi['id'];
			$paths = PREFIXAF.str_replace(PREFIXAF, '', $kpi['paths']);
			$tempo = PIWebAPI::GetAFConstantValueCron($paths.'|Tempo_Dia_Ant');
			if(isset($tempo) AND !is_object($tempo))
				$top[$kpid] = $tempo;
		}
		asort($top);
		foreach($top as $kpid => $tempo)
		{
			TOP::insertTDA($sql, $area, $kpid, $tempo, $dia->format('Y-m-d'));
		}
		echo 'AREA 1: DADOS DIA ANT INSERIDOS<br>';
	}
	else
		echo 'AREA 1: DADOS DO DIA ANT JA INSERIDOS<br>';

//Area 2 = Qualidade ULTIMA ANALISE
//DIA = ULTIMA ANALISE | DIA_ANT = ANALISE ANTERIOR | MES = MES ANTERIOR | MES ANT = TRIMESTRE ANTERIOR
	$dia = new Datetime('today');
	$area = 2;
	if(!TOP::checkTDA($sql, $area, $dia->format('Y-m-d')))
	{
		$top = array();
		foreach($Qualidade as $kpi)
		{
			$kpid = $kpi['id'];
			$paths = PREFIXAF.str_replace(PREFIXAF, '', $kpi['paths']);
			$tempo = PIWebAPI::GetAFConstantValueCron($paths.'|Tempo_Dia');
			if(isset($tempo) AND !is_object($tempo))
				$top[$kpid] = $tempo;
		}
		asort($top);
		foreach($top as $kpid => $tempo)
		{
			TOP::insertTDA($sql, $area, $kpid, $tempo, $dia->format('Y-m-d'));
		}
		echo 'AREA 2: DADOS ULTIMA ANALISE INSERIDOS<br>';
	}
	else
		echo 'AREA 2: DADOS DA ULTIMA ANALISE JA INSERIDOS<br>';


////////////////////////////////MES ANTERIOR////////////////////////////////////

	$dia = new Datetime('today');
	$dia->modify('first day of last month');

//Area 1 = Processo MES ANT
	$area = 1;
	$checkTMA = TOP::checkTMA($sql, $area, $dia);
	if(!$checkTMA) //TOP MES ANTERIOR
	{
		$top = array();
		foreach($Processo as $kpi)
		{
			$kpid = $kpi['id'];
			$paths = PREFIXAF.str_replace(PREFIXAF, '', $kpi['paths']);
			$tempo = PIWebAPI::GetAFConstantValueCron($paths.'|Tempo_Mes_Ant');
			if(isset($tempo) AND !is_object($tempo))
				$top[$kpid] = $tempo;
		}
		asort($top);
		foreach($top as $kpid => $tempo)
		{
			TOP::insertTMA($sql, $area, $kpid, $tempo, $dia->format('Y-m-d'));
		}
		echo 'AREA 1: DADOS MES ANT INSERIDOS<br>';
	}
	else
	{
		$diaux = new Datetime($checkTMA['dia']);
		$diaux->modify('first day of this month');
		if($checkTMA['dia'] != $diaux->format('Y-m-d'))
		{
			TOP::dropTMA($sql, $area, $dia);
			$top = array();
			foreach($Processo as $kpi)
			{
				$kpid = $kpi['id'];
				$paths = PREFIXAF.str_replace(PREFIXAF, '', $kpi['paths']);
				$tempo = PIWebAPI::GetAFConstantValueCron($paths.'|Tempo_Mes_Ant');
				if(isset($tempo) AND !is_object($tempo))
					$top[$kpid] = $tempo;
			}
			asort($top);
			foreach($top as $kpid => $tempo)
			{
				TOP::insertTMA($sql, $area, $kpid, $tempo, $dia->format('Y-m-d'));
			}
			echo 'AREA 1: DADOS MES ANT INSERIDOS<br>';
		}
		else
			echo 'AREA 1: DADOS DO MES ANT JA INSERIDOS<br>';
	}

//Area 2 = Qualidade MES ANT
	$area = 2;
	$checkTMA = TOP::checkTMA($sql, $area, $dia);
	if(!$checkTMA) //TOP MES ANTERIOR
	{
		$top = array();
		foreach($Qualidade as $kpi)
		{
			$kpid = $kpi['id'];
			$paths = PREFIXAF.str_replace(PREFIXAF, '', $kpi['paths']);
			$tempo = PIWebAPI::GetAFConstantValueCron($paths.'|Tempo_Mes');
			if(isset($tempo) AND !is_object($tempo))
				$top[$kpid] = $tempo;
		}
		asort($top);
		foreach($top as $kpid => $tempo)
		{
			TOP::insertTMA($sql, $area, $kpid, $tempo, $dia->format('Y-m-d'));
		}
		echo 'AREA 2: DADOS MES ANT INSERIDOS<br>';
	}
	else
	{
		$diaux = new Datetime($checkTMA['dia']);
		$diaux->modify('first day of this month');
		if($checkTMA['dia'] != $diaux->format('Y-m-d'))
		{
			TOP::dropTMA($sql, $area, $dia);
			$top = array();
			foreach($Qualidade as $kpi)
			{
				$kpid = $kpi['id'];
				$paths = PREFIXAF.str_replace(PREFIXAF, '', $kpi['paths']);
				$tempo = PIWebAPI::GetAFConstantValueCron($paths.'|Tempo_Mes');
				if(isset($tempo) AND !is_object($tempo))
					$top[$kpid] = $tempo;
			}
			asort($top);
			foreach($top as $kpid => $tempo)
			{
				TOP::insertTMA($sql, $area, $kpid, $tempo, $dia->format('Y-m-d'));
			}
			echo 'AREA 2: DADOS MES ANT INSERIDOS<br>';
		}
		else
			echo 'AREA 2: DADOS DO MES ANT JA INSERIDOS<br>';
	}

//Area 3 = Consumo MES ANT
	$area = 3;
	$checkTMA = TOP::checkTMA($sql, $area, $dia);
	if(!$checkTMA) //TOP MES ANTERIOR
	{
		$top = array();
		foreach($Consumo as $kpi)
		{
			$kpid = $kpi['id'];
			$paths = PREFIXAF.str_replace(PREFIXAF, '', $kpi['paths']);
			$tempo = PIWebAPI::GetAFConstantValueCron($paths.'|Tempo_Mes_Ant');
			if(isset($tempo) AND !is_object($tempo))
				$top[$kpid] = $tempo;
		}
		asort($top);
		foreach($top as $kpid => $tempo)
		{
			TOP::insertTMA($sql, $area, $kpid, $tempo, $dia->format('Y-m-d'));
		}
		echo 'AREA 3: DADOS MES ANT INSERIDOS<br>';
	}
	else
	{
		$diaux = new Datetime($checkTMA['dia']);
		$diaux->modify('first day of this month');
		if($checkTMA['dia'] != $diaux->format('Y-m-d'))
		{
			TOP::dropTMA($sql, $area, $dia);
			$top = array();
			foreach($Consumo as $kpi)
			{
				$kpid = $kpi['id'];
				$paths = PREFIXAF.str_replace(PREFIXAF, '', $kpi['paths']);
				$tempo = PIWebAPI::GetAFConstantValueCron($paths.'|Tempo_Mes_Ant');
				if(isset($tempo) AND !is_object($tempo))
					$top[$kpid] = $tempo;
			}
			asort($top);
			foreach($top as $kpid => $tempo)
			{
				TOP::insertTMA($sql, $area, $kpid, $tempo, $dia->format('Y-m-d'));
			}
			echo 'AREA 3: DADOS MES ANT INSERIDOS<br>';
		}
		else
			echo 'AREA 3: DADOS DO MES ANT JA INSERIDOS<br>';
	}


////////////////////////////////MES ATUAL////////////////////////////////////

	$dia = new Datetime('today');

//Area 1 = Processo MES ATUAL
	$area = 1;
	if(!TOP::checkTM($sql, $area, $dia->format('Y-m-d'))) //TOP MES ANTERIOR
	{
		TOP::dropTMA($sql, $area, $dia);
		$top = array();
		foreach($Processo as $kpi)
		{
			$kpid = $kpi['id'];
			$paths = PREFIXAF.str_replace(PREFIXAF, '', $kpi['paths']);
			$tempo = PIWebAPI::GetAFConstantValueCron($paths.'|Tempo_Mes');
			if(isset($tempo) AND !is_object($tempo))
				$top[$kpid] = $tempo;
		}
		asort($top);
		foreach($top as $kpid => $tempo)
		{
			TOP::insertTMA($sql, $area, $kpid, $tempo, $dia->format('Y-m-d'));
		}
		echo 'AREA 1: DADOS MES ATUAL INSERIDOS<br>';
	}
	else
		echo 'AREA 1: DADOS DO MES ATUAL JA INSERIDOS<br>';


//Area 3 = Consumo MES ATUAL
	$area = 3;
	if(!TOP::checkTM($sql, $area, $dia->format('Y-m-d'))) //TOP MES ANTERIOR
	{
		TOP::dropTMA($sql, $area, $dia);
		$top = array();
		foreach($Consumo as $kpi)
		{
			$kpid = $kpi['id'];
			$paths = PREFIXAF.str_replace(PREFIXAF, '', $kpi['paths']);
			$tempo = PIWebAPI::GetAFConstantValueCron($paths.'|Tempo_Mes');
			if(isset($tempo) AND !is_object($tempo))
				$top[$kpid] = $tempo;
		}
		asort($top);
		foreach($top as $kpid => $tempo)
		{
			TOP::insertTMA($sql, $area, $kpid, $tempo, $dia->format('Y-m-d'));
		}
		echo 'AREA 3: DADOS MES ATUAL INSERIDOS<br>';
	}
	else
		echo 'AREA 3: DADOS DO MES ATUAL JA INSERIDOS<br>';


	flock($filehandle, LOCK_UN);  // don't forget to release the lock

	}

	fclose($filehandle);