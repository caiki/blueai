<?php

date_default_timezone_set('America/Sao_Paulo');

//URL DO SERVIDOR DO PI WEB API
CONST PIWEBAPI_URL = 'http://localhost/piwebapi/';

//URL API DA ASSERTIVAAPI_URL
CONST ASSERTIVA_URL = 'https://services-elb.assertivasolucoes.com.br:443/v1/localize/1000/consultar';
CONST ASSERTIVA_URL2 = 'https://services-elb.assertivasolucoes.com.br:443/v1/localize/1005/consultar';
CONST ASSERTIVA_AUTH = '455AA477-945C-4703-BA6A-B4FBDFCFDE9B';

//NOME DO SERVIDOR DO PI
CONST SERVERNAME = 'ORTSRVPI';

CONST PREFIXAF = '\\ORTSRV008-VM\Klabin_ORT\\';

CONST POSFIXAF = 'Klabin\Ortigueira\Ferramentas e Aplicações\Relatório de KPIs\\';
CONST POSFIXAF2 = 'Klabin\Ortigueira\Ferramentas e Aplicações\Relatório de KPIs - ';

//ENDEREÇO DA PASTA DE RELATÓRIO DE KPIs NO AF
CONST AFKPI = '\\ORTSRV008-VM\Klabin_ORT\Klabin\Ortigueira\Ferramentas e Aplicações\Relatório de KPIs';

//NOME VARIAVEIS DE CALCULO PI
CONST STDEV = '32';
CONST AVERAGE = 'average';
CONST MAXIMUM = 'maximum';

//MASTER USER CRON JOBS
CONST ADMINUSER = 'ort_kpi_indicadores';
CONST ADMINPASS = '0rt1ndiKL@';

//SUFIXO SUB AREAS
CONST PROCESSO = 'Processo';
CONST QUALIDADE = 'KPIs - Qualidade';
CONST CONSUMO = 'KPIs - Custo';

//TOLERANCIA DOS TOP PIORES
CONST TOLERANCE = 50; //50%
