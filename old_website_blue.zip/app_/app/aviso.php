<?php 

  $piPointName = $_POST['piPointName'];
  $lab = $_POST['lab'];
  $filter = $_POST['filter'];

  if($lab and $filter)
    echo "Analisando dados de Laboratório filtrado por $filter";
  else if($lab)
    echo 'Analisando dados de Laboratório';
  else if(!$piPointName and $filter)
    echo "Analisando dados calculados por Fórmula.<br>Não é possível aplicar filtro neste modo.<br>Tente incluí-lo na própria fórmula do cálculo.";
  else if($filter)
    echo "Analisando dados originais filtrados com $filter";
  else if(!$piPointName)
    echo "Analisando dados calculados por Fórmula";
  else
    echo 'Analisando dados originais';