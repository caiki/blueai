<?php

require_once('db.php');
require_once('config.php');

if(!isset($_SESSION)){session_start();}

class SQL 
{
	public static function GetKPI($sql, $nome)
	{
		$row = $sql->prepare('SELECT * FROM kpi WHERE nome=?'); 
		$row->bindParam(1, $nome);
		$row->execute(); 
		return $row->fetch();
	}
	public static function GetKpiId($sql, $nome)
	{
		$row = $sql->prepare('SELECT * FROM kpi WHERE nome=?'); 
		$row->bindParam(1, $nome);
		$row->execute(); 
		$row = $row->fetch();
		return $row['id'];
	}
	public static function GetKPIbyPath($sql, $path)
	{
		$row = $sql->prepare("SELECT nome FROM kpi WHERE paths LIKE '%$path'"); 
		$row->execute();
		$row = $row->fetch();
		return $row['nome'];
	}
	public static function GetAllPaths($sql)
	{
		$query = $sql->prepare('SELECT paths FROM kpi WHERE paths IS NOT NULL ORDER BY paths'); 
		$query->execute(); 
		$paths = array();
		while($row = $query->fetch(PDO::FETCH_ASSOC))
		{
			$path = str_replace([POSFIXAF, POSFIXAF2], '', $row['paths']);
				$paths[$path] = $path;
		}

		return $paths;
	}
	public static function listaIndicadores($sql)
	{
		$query = $sql->prepare('SELECT nome FROM kpi WHERE categoria <> "KPIS AUXILIARES" and paths is not null or categoria is null and paths is not null ORDER BY nome'); 
		$query->execute(); 
		$rows = array();
		while($row = $query->fetch(PDO::FETCH_ASSOC))
		{
			$rows[] = $row['nome'];
		} 
		return $rows;
	}
	public static function listaKpisArea($sql, $area)
	{
		switch($area) {
			case 1:
				$path = PROCESSO; break;
			case 2:
				$path = QUALIDADE; break;
			case 3:
				$path = CONSUMO; break;
		}

		$query = $sql->prepare("SELECT * FROM kpi WHERE paths LIKE '%$path%' ORDER BY paths"); 
		$query->execute(); 
		$rows = array();
		while($row = $query->fetch(PDO::FETCH_ASSOC))
		{
			$rows[] = $row;
		} 
		return $rows;
	}
	public static function listarSubAreas($sql, $area)
	{
		switch($area) {
			case 1:
				$path = PROCESSO; break;
			case 2:
				$path = QUALIDADE; break;
			case 3:
				$path = CONSUMO; break;
		}

		$query = $sql->prepare("SELECT DISTINCT paths FROM kpi WHERE paths LIKE '%$path%' ORDER BY paths ASC"); 
		$query->execute(); 
		$rows = array();
		while($row = $query->fetch(PDO::FETCH_ASSOC))
		{
			$subarea = explode($path, $row['paths']);
			$subarea = explode('\\', $subarea[1]);
			if($subarea[1] != end($rows))
				$rows[] = $subarea[1];
		} 
		return $rows;
	}
	public static function listaTodosKpisAuxiliares($sql)
	{
		$query = $sql->prepare('SELECT * FROM kpi WHERE categoria = "KPIS AUXILIARES" and owner <> ? OR categoria = "KPIS AUXILIARES" and owner IS NULL ORDER BY id'); 
		$query->bindParam(1, $_SESSION['username']);
		$query->execute(); 
		$rows = array();
		while($row = $query->fetch(PDO::FETCH_ASSOC))
		{
			$rows[] = $row;
		} 
		return $rows;
	}
	public static function listaMeusKpisAuxiliares($sql)
	{
		$query = $sql->prepare('SELECT * FROM kpi WHERE categoria = "KPIS AUXILIARES" and owner = ? ORDER BY id'); 
		$query->bindParam(1, $_SESSION['username']);
		$query->execute(); 
		$rows = array();
		while($row = $query->fetch(PDO::FETCH_ASSOC))
		{
			$rows[] = $row;
		} 
		return $rows;
	}
	public static function createKPI($sql, $nome, $categoria)
	{
		if(SQL::GetKPI($sql, $nome))
			return false;
		$query = $sql->prepare('INSERT INTO kpi (categoria, nome) VALUES (?, ?)'); 
		$query->bindParam(1, $categoria);
		$query->bindParam(2, $nome);
		return $query->execute(); 
	}
	public static function updateKPI($sql, $id, $paths, $nome, $pipointname, $expressioni, $expressiond, $expressionm, $calculationbasis, $lab, $filter, $unit, $owner, $max, $min)
	{
		$query = $sql->prepare('UPDATE kpi SET pipointname = ?, expressioni = ?, expressiond = ?, expressionm = ?, calculationbasis = ?, lab = ?, filter = ?, unit = ?, nome = ?, paths = ?, owner = ?, max = ?, min = ? WHERE id=?'); 
		$query->bindParam(1, $pipointname);
		$query->bindParam(2, $expressioni);
		$query->bindParam(3, $expressiond);
		$query->bindParam(4, $expressionm);
		$query->bindParam(5, $calculationbasis);
		$query->bindParam(6, $lab);
		$query->bindParam(7, $filter);
		$query->bindParam(8, $unit);
		$query->bindParam(9, $nome);
		$query->bindParam(10, $paths);
		$query->bindParam(11, $owner);
		$query->bindParam(12, $max);
		$query->bindParam(13, $min);
		$query->bindParam(14, $id);
		$query->execute(); 
	}
	public static function deleteKPI($sql, $nome)
	{
		$query = $sql->prepare('DELETE FROM kpi WHERE nome=?'); 
		$query->bindParam(1, $nome);
		$query->execute(); 
	}
}

if(isset($_POST['req']))
{
	if($_POST['req'] == 'listaIndicadores')
	{
		echo json_encode(SQL::listaIndicadores($sql));
	}
}
else if(isset($_POST['tipo']))
{
	if(!empty($_POST['categoria2']))
		$categoria = $_POST['categoria2'];
	else
		$categoria = null;

	$nome = $_POST['nome'];

	if(empty($_POST['paths']))
		$paths = null;
	else
		$paths = $_POST['paths'];

	if($_POST['tipo'] === 'modificar')
	{
		if(!empty($_POST['nome0']))
			$id = SQL::GetKpiId($sql, $_POST['nome0']);
		else
			$id = SQL::GetKpiId($sql, $nome);
	}
	else if($_POST['tipo'] === 'criar')
	{
		$r = SQL::createKPI($sql, $nome, $categoria);
		if(!$r) {
			echo 'ERRO: JÁ EXISTE UM KPI COM O MESMO NOME';
			die();
		}
		$id = SQL::GetKpiId($sql, $nome);
	}
	else if($_POST['tipo'] === 'deletar')
	{
		SQL::deleteKPI($sql, $nome);
		header('Location:../');
		die();
	}

	if($_POST['varexp'] === 'variavel')
	{
		$pipointname = $_POST['pipointname'];
		$expressioni = null; $expressiond = null; $expressionm = null;
	}
	else if($_POST['varexp'] === 'expressao')
	{
		$pipointname = null;
		$expressioni = $_POST['expressioni'];
		$expressiond = $_POST['expressiond'];
		$expressionm = $_POST['expressionm'];
	}

	if($_POST['lab'] === 'true')
		$lab = 1;
	else
		$lab = null;

	$calculationbasis = $_POST['calculationbasis'];

	if(empty($_POST['filter'])) $filter = null; else $filter = $_POST['filter'];

	if(empty($_POST['unit'])) $unit = null; else $unit = $_POST['unit'];

	if(empty($_POST['max'])) $max = null; else $max = $_POST['max'];

	if(empty($_POST['min']) and $_POST['min'] !== '0') $min = null; else $min = $_POST['min'];

	$owner = $_SESSION['username'];

	SQL::updateKPI($sql, $id, $paths, $nome, $pipointname, $expressioni, $expressiond, $expressionm, $calculationbasis, $lab, $filter, $unit, $owner, $max, $min);

	header('Location:../?nome='.urlencode($nome));
	die();
}