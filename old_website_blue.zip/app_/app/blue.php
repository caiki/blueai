<?php

require_once('config.php');

class Blue
{

	public static function auth($postuser, $postpass)
	{
		$username = $postuser;
		$password = $postpass;

    $admins = array('blueai'=>'1234', 'BLUEAI'=>'1234');

    $config = false;

    foreach($admins as $admin => $pw) {
    	if($admin === $username and $pw === $password)
    		$config = true;
    }

    return $config;
	}

  public static function GetCPF($cpf)
  {
		if(file_exists('./assets/' . $cpf . '_cpf.json'))
		{
			return json_decode(file_get_contents('./assets/' . $cpf . '_cpf.json'));
		}
		else
		{
	    $ch = curl_init();

	    curl_setopt($ch, CURLOPT_URL, ASSERTIVA_URL . '?cpf=' . $cpf);
	    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
	    curl_setopt($ch, CURLOPT_POST, 1);

	    $headers = array();
	    $headers[] = 'Content-Type: application/json';
	    $headers[] = 'Accept: application/json';
	    $headers[] = 'Authorization: ' . ASSERTIVA_AUTH;
	    curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
	    curl_setopt($ch, CURLOPT_USERAGENT, $_SERVER['HTTP_USER_AGENT']);

	    $result = curl_exec($ch);
	    if (curl_errno($ch)) {
	        return 'Error:' . curl_error($ch);
	    }
	    curl_close ($ch);

			return json_decode($result);
		}
  }

  public static function GetRelativesCPF($cpf)
  {
		if(file_exists('./assets/' . $cpf . '_relatives.json'))
		{
			return json_decode(file_get_contents('./assets/' . $cpf . '_relatives.json'));
		}
		else
		{
	    $ch = curl_init();

	    curl_setopt($ch, CURLOPT_URL, ASSERTIVA_URL2 . '?cpf=' . $cpf);
	    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
	    curl_setopt($ch, CURLOPT_POST, 1);

	    $headers = array();
	    $headers[] = 'Content-Type: application/json';
	    $headers[] = 'Accept: application/json';
	    $headers[] = 'Authorization: ' . ASSERTIVA_AUTH;
	    curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
	    curl_setopt($ch, CURLOPT_USERAGENT, $_SERVER['HTTP_USER_AGENT']);

	    $result = curl_exec($ch);
	    if (curl_errno($ch)) {
	        return 'Error:' . curl_error($ch);
	    }
	    curl_close ($ch);

			return json_decode($result);
		}
  }

	public static function GetTimeline($cpf)
  {
		if(file_exists('./assets/' . $cpf . '_timeline.html'))
		{
			return file_get_contents('./assets/' . $cpf . '_timeline.html');
		}
		else
		{
	   	return file_get_contents('./assets/no_timeline.html');
		}
  }

	public static function GetCSV($cpf)
	{
		if(file_exists('./assets/' . $cpf . '_csv.json'))
		{
			return json_decode(file_get_contents('./assets/' . $cpf . '_csv.json'), true);
		}
		else
		{
			//GERA SEMPRE O MESMO NUMERO ALEATORIO DADO O MESMO CPF
			//RETIRA A NECESSIDADE DE CRIAR UM COOKIE PARA OS DADOS
			mt_srand(crc32($cpf));
			$lowerRange = 1;
			$upperRange = 24;
			$line = mt_rand($lowerRange, $upperRange);

			$csv = file_get_contents('./assets/blueDB.csv');
			$array = array_map("str_getcsv", explode("\n", $csv));
			$header = $array[0];

			$arr = array();

			foreach($header as $key => $value)
			{
				$arr[$value] = $array[$line][$key];
			}

			return $arr;
		}
	}

	public static function GetHeartFeatures($arr)
	{
		$ch = curl_init();

		curl_setopt($ch, CURLOPT_URL, 'http://52.188.216.46:80/score' .
		'?data=[['.$arr['Age'].','.$arr['Sex_male'].','.$arr['cigsPerDay'].','.$arr['totChol'].','.$arr['sysBP'].','.$arr['Glucose'].']]');
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
		$headers = array();
		$headers[] = 'Content-Type: application/json';
		$headers[] = 'Accept: application/json';
		curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);

		$result = curl_exec($ch);
		if (curl_errno($ch)) {
				return 'Error:' . curl_error($ch);
		}
		curl_close ($ch);

		return json_decode($result);
	}

	public static function GetDiabFeatures($arr)
	{
		$ch = curl_init();

		curl_setopt($ch, CURLOPT_URL, 'http://20.42.35.156:80/score' .
		'?data=[['.$arr['Pregnancies'].','.$arr['Glucose'].','.$arr['BloodPressure'].','.$arr['SkinThickness'].','.$arr['Insulin']
		.','.$arr['BMI'].','.$arr['DiabetesPedigreeFunction'].','.$arr['Age'].']]');
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
		$headers = array();
		$headers[] = 'Content-Type: application/json';
		$headers[] = 'Accept: application/json';
		curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);

		$result = curl_exec($ch);
		if (curl_errno($ch)) {
				return 'Error:' . curl_error($ch);
		}
		curl_close ($ch);

		return json_decode($result);
	}

	public static function GetAlzFeatures($arr)
	{
		$ch = curl_init();

		curl_setopt($ch, CURLOPT_URL, 'http://52.151.226.178:80/score' .
		'?data=[['.$arr['ASF'].','.$arr['Age_Alz'].','.$arr['EDUC'].','.$arr['Group'].','.$arr['Hand']
		.','.$arr['M/F'].','.$arr['MMSE'].','.$arr['MR Delay'].','.$arr['SES'].','.$arr['eTIV'].','.$arr['nWBV'].']]');
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
		$headers = array();
		$headers[] = 'Content-Type: application/json';
		$headers[] = 'Accept: application/json';
		curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);

		$result = curl_exec($ch);
		if (curl_errno($ch)) {
				return 'Error:' . curl_error($ch);
		}
		curl_close ($ch);

		return json_decode($result);
	}

	public static function normalizei($aux)
	{
		if($aux >= 0 and $aux <= 0.2)
	    return 1;
	  else if($aux > 0.2 and $aux <= 0.4)
	    return 2;
	  else if($aux > 0.4 and $aux <= 0.6)
	    return 3;
	  else if($aux > 0.6 and $aux <= 0.8)
	    return 4;
	  else
	    return 5;
	}

  public static function formatarCPF($cnpj_cpf)
  {
    if (strlen(preg_replace("/\D/", '', $cnpj_cpf)) === 11) {
      $response = preg_replace("/(\d{3})(\d{3})(\d{3})(\d{2})/", "\$1.\$2.\$3-\$4", $cnpj_cpf);
    } else {
      $response = preg_replace("/(\d{2})(\d{3})(\d{3})(\d{4})(\d{2})/", "\$1.\$2.\$3/\$4-\$5", $cnpj_cpf);
    }

    return $response;
  }

}
