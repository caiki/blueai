<?php

ini_set('display_errors', true);
error_reporting(E_ERROR | E_WARNING | E_PARSE);

class TOP
{
	public static function Processo($sql)
	{
		$query = $sql->prepare("SELECT id, nome, paths FROM kpi WHERE paths LIKE '%Processo%' AND lab IS NULL"); 
		$query->execute();
		$rows = array();
		while($row = $query->fetch(PDO::FETCH_ASSOC))
		{
			$rows[] = $row;
		}
		return $rows;
	}

	public static function Qualidade($sql)
	{
		$query = $sql->prepare("SELECT id, nome, paths FROM kpi WHERE paths LIKE '%KPIs - Qualidade%' AND top IS NULL"); 
		$query->execute();
		$rows = array();
		while($row = $query->fetch(PDO::FETCH_ASSOC))
		{
			$rows[] = $row;
		}
		return $rows;
	}

	public static function Consumo($sql)
	{
		$query = $sql->prepare("SELECT id, nome, paths FROM kpi WHERE paths LIKE '%KPIs - Custo%'"); 
		$query->execute();
		$rows = array();
		while($row = $query->fetch(PDO::FETCH_ASSOC))
		{
			$rows[] = $row;
		}
		return $rows;
	}

	public static function checkTDA($sql, $area, $dia)
	{
		$query = $sql->prepare("SELECT * FROM topd WHERE area = ? AND dia = ?");
		$query->bindParam(1, $area);
		$query->bindParam(2, $dia);
		$query->execute();
		return $query->fetch();
	}

	public static function insertTDA($sql, $area, $kpid, $tempo, $dia)
	{
		$query = $sql->prepare("INSERT INTO topd (area, kpid, tempo, dia) VALUES (?, ?, ?, ?)"); 
		$query->bindParam(1, $area);
		$query->bindParam(2, $kpid);
		$query->bindParam(3, $tempo);
		$query->bindParam(4, $dia);
		return $query->execute(); 
	}

	public static function checkTMA($sql, $area, $dia)
	{
		$diai = clone $dia;
		$diaf = clone $dia;
		$diai->modify('first day of this month');
		$diaf->modify('last day of this month');
		$diai = $diai->format('Y-m-d');
		$diaf = $diaf->format('Y-m-d');
		$query = $sql->prepare("SELECT * FROM topm WHERE area = ? AND dia BETWEEN ? AND ?");
		$query->bindParam(1, $area);
		$query->bindParam(2, $diai);
		$query->bindParam(3, $diaf);
		$query->execute();
		return $query->fetch();
	}

	public static function insertTMA($sql, $area, $kpid, $tempo, $dia)
	{
		$query = $sql->prepare("INSERT INTO topm (area, kpid, tempo, dia) VALUES (?, ?, ?, ?)"); 
		$query->bindParam(1, $area);
		$query->bindParam(2, $kpid);
		$query->bindParam(3, $tempo);
		$query->bindParam(4, $dia);
		return $query->execute(); 
	}

	public static function dropTMA($sql, $area, $dia)
	{
		$diai = clone $dia;
		$diaf = clone $dia;
		$diai->modify('first day of this month');
		$diaf->modify('last day of this month');
		$diai = $diai->format('Y-m-d');
		$diaf = $diaf->format('Y-m-d');
		$query = $sql->prepare("DELETE FROM topm WHERE area = ? AND dia BETWEEN ? AND ?"); 
		$query->bindParam(1, $area);
		$query->bindParam(2, $diai);
		$query->bindParam(3, $diaf);
		return $query->execute(); 
	}

	public static function checkTM($sql, $area, $dia)
	{
		$query = $sql->prepare("SELECT * FROM topm WHERE area = ? AND dia = ?");
		$query->bindParam(1, $area);
		$query->bindParam(2, $dia);
		$query->execute();
		return $query->fetch();
	}

	public static function getTDA1($sql, $area, $diai, $diaf, $max)
	{
		$query = $sql->prepare("SELECT kpid, AVG(tempo) AS media, (SELECT nome FROM kpi WHERE id = kpid) AS nome, (SELECT paths FROM kpi WHERE id = kpid) AS paths FROM topd WHERE area = ? AND (SELECT lab FROM kpi WHERE id = kpid) IS NULL AND (SELECT id FROM kpi WHERE id = kpid) IS NOT NULL AND dia BETWEEN ? AND ? GROUP BY kpid ORDER BY media ASC"); 
		$query->bindParam(1, $area);
		$query->bindParam(2, $diai);
		$query->bindParam(3, $diaf);
		$query->execute();
		$rows = array();
		$i = 0;
		while($row = $query->fetch(PDO::FETCH_ASSOC))
		{
			$i++;
			$rows[] = $row;
			if($i == $max)
				return $rows;
		}
		return $rows;
	}

	//GET TOP SUB AREA 1 FILTER BY A MAXIMUM TOLERANCE
	public static function getTSA1($sql, $area, $subarea, $diai, $diaf, $tolerance)
	{
		$query = $sql->prepare("SELECT kpid, AVG(tempo) AS media, (SELECT nome FROM kpi WHERE id = kpid) AS nome, (SELECT paths FROM kpi WHERE id = kpid) AS paths FROM topd WHERE area = ? AND (SELECT lab FROM kpi WHERE id = kpid) IS NULL AND (SELECT id FROM kpi WHERE id = kpid) IS NOT NULL AND dia BETWEEN ? AND ? GROUP BY kpid HAVING paths LIKE '%$subarea%' ORDER BY media ASC"); 
		$query->bindParam(1, $area);
		$query->bindParam(2, $diai);
		$query->bindParam(3, $diaf);
		$query->execute();
		$rows = array();
		while($row = $query->fetch(PDO::FETCH_ASSOC))
		{
			if($row['media'] > $tolerance)
				return $rows;
			$rows[] = $row;
		}
		return $rows;
	}

	public static function getTDA2($sql, $area, $diai, $diaf, $max)
	{
		$query = $sql->prepare("SELECT kpid, AVG(tempo) AS media, (SELECT nome FROM kpi WHERE id = kpid) AS nome, (SELECT paths FROM kpi WHERE id = kpid) AS paths FROM topd WHERE area = ? AND (SELECT id FROM kpi WHERE id = kpid) IS NOT NULL AND dia BETWEEN ? AND ? GROUP BY kpid ORDER BY media ASC"); 
		$query->bindParam(1, $area);
		$query->bindParam(2, $diai);
		$query->bindParam(3, $diaf);
		$query->execute();
		$rows = array();
		$i = 0;
		while($row = $query->fetch(PDO::FETCH_ASSOC))
		{
			$i++;
			$rows[] = $row;
			if($i == $max)
				return $rows;
		}
		return $rows;
	}

	public static function getTSA2($sql, $area, $subarea, $diai, $diaf, $tolerance)
	{
		$query = $sql->prepare("SELECT kpid, AVG(tempo) AS media, (SELECT nome FROM kpi WHERE id = kpid) AS nome, (SELECT paths FROM kpi WHERE id = kpid) AS paths FROM topd WHERE area = ? AND (SELECT id FROM kpi WHERE id = kpid) IS NOT NULL AND dia BETWEEN ? AND ? GROUP BY kpid HAVING paths LIKE '%$subarea%' ORDER BY media ASC"); 
		$query->bindParam(1, $area);
		$query->bindParam(2, $diai);
		$query->bindParam(3, $diaf);
		$query->execute();
		$rows = array();
		while($row = $query->fetch(PDO::FETCH_ASSOC))
		{
			if($row['media'] > $tolerance)
				return $rows;
			$rows[] = $row;
		}
		return $rows;
	}

	public static function getTM($sql, $area, $diai, $diaf, $max)
	{
		$query = $sql->prepare("SELECT kpid, AVG(tempo) AS media, (SELECT nome FROM kpi WHERE id = kpid) AS nome, (SELECT paths FROM kpi WHERE id = kpid) AS paths FROM topm WHERE area = ? AND (SELECT id FROM kpi WHERE id = kpid) IS NOT NULL AND dia BETWEEN ? AND ? GROUP BY kpid ORDER BY media DESC"); 
		$query->bindParam(1, $area);
		$query->bindParam(2, $diai);
		$query->bindParam(3, $diaf);
		$query->execute();
		$rows = array();
		$i = 0;
		while($row = $query->fetch(PDO::FETCH_ASSOC))
		{
			$i++;
			$rows[] = $row;
			if($i == $max)
				return $rows;
		}
		return $rows;
	}

	public static function getTSM($sql, $area, $subarea, $diai, $diaf, $tolerance)
	{
		$query = $sql->prepare("SELECT kpid, AVG(tempo) AS media, (SELECT nome FROM kpi WHERE id = kpid) AS nome, (SELECT paths FROM kpi WHERE id = kpid) AS paths FROM topm WHERE area = ? AND (SELECT id FROM kpi WHERE id = kpid) IS NOT NULL AND dia BETWEEN ? AND ? GROUP BY kpid HAVING paths LIKE '%$subarea%' ORDER BY media DESC"); 
		$query->bindParam(1, $area);
		$query->bindParam(2, $diai);
		$query->bindParam(3, $diaf);
		$query->execute();
		$rows = array();
		while($row = $query->fetch(PDO::FETCH_ASSOC))
		{
			if($row['media'] <= 0)
				return $rows;
			$rows[] = $row;
		}
		return $rows;
	}

	public static function getArea($sql, $kpid)
	{
		$query = $sql->prepare("SELECT area FROM topm WHERE kpid = ?");
		$query->bindParam(1, $kpid);
		$query->execute();
		return $query->fetch();
	}

	public static function printMailBody($top)
	{
		$i = 0;

		if($top == null)
			return '<small>- Sem indicadores fora da tolerância.</small><br><br>';

	    foreach($top as $kpi)
	    {
	        $i++;
	        $paths = strtoupper($kpi['paths']);

	        if(strpos($paths, 'MC25') !== false) 
	            $mc = ' <u>[ MC25 ]</u>';
	        else if(strpos($paths, 'MC26') !== false)
	            $mc = ' <u>[ MC26 ]</u>';
	        else
	            $mc = '';

	        $html .= '<div><span style="font-size: normal;"><strong><span style="color: #cc0000;">#'.$i.'</span></strong>&nbsp;-&nbsp;&nbsp;<span style="color: #ffffff; background-color: #47828d;">'. $kpi['nome'] . $mc . '</span>&nbsp;&nbsp;-&nbsp;';
	        if($kpi['media'] >= 0 and $a == 3) $html .= '<span style="color: #ffffff; background-color: #e39042;">'; else if ($kpi['media'] >= 90) $html .= '<span style="color: #ffffff; background-color: #43A047;">'; else if ($kpi['media'] >= 80) $html .= '<span style="color: #ffffff; background-color: #c4be1f;">'; else if ($kpi['media'] >= 0) $html .= '<span style="color: #ffffff; background-color: #e39042;">'; else $html .= '<span style="color: #ffffff; background-color: #43A047;">';
	        $html .= number_format($kpi['media'], 2, ',', '') . '%</span>&nbsp; &nbsp;<a href="https://ortpi.klabin.com.br/depr/kpi/?nome=' . urlencode($kpi['nome']) . '"><u><span style="color: #0b5394;">Acessar&nbsp;↗</span></u></a></span></div>';
	    }
	    return $html.'<br>';		
	}

}

if(isset($_POST['req']))
{
	require_once('sql.php');
	if($_POST['req'] == 'tickerlist')
	{
		$diai = new Datetime('today');
		$diai->modify('-2 days');
		$diaf = new Datetime('today');

		//PROCESSO
		$top = TOP::getTDA1($sql, 1, $diai->format('Y-m-d'), $diaf->format('Y-m-d'), 5);
		$i = 0;

		if(empty($top)) {
			echo '<li class="ticker__item" data-ticker="item"><b style="color:#068434">PROCESSO: </b><a href="./?nome=" style="color:#068434"><b></b>Calc failed PI.</a></li>';
		}
		else {
			foreach($top as $kpi)
			{
				$i++;
				if((number_format($kpi['media'], 2, ',', ''))>90){
				echo '<li class="ticker__item" data-ticker="item"><b style="color:#068434">PROCESSO: </b><a href="./?nome=' . urlencode($kpi['nome']) . '" style="color:#068434"><b>' . $i . '.</b> '. $kpi['nome'] .' ' . number_format($kpi['media'], 2, ',', '') . '%</a></li>';
				}
				else if((number_format($kpi['media'], 2, ',', ''))>80){
					echo '<li class="ticker__item" data-ticker="item"><b style="color:#e8d20b">PROCESSO: </b><a href="./?nome=' . urlencode($kpi['nome']) . '" style="color:#e8d20b"><b>' . $i . '.</b> '. $kpi['nome'] .' ' . number_format($kpi['media'], 2, ',', '') . '%</a></li>';
				}
				else{
					echo '<li class="ticker__item" data-ticker="item"><b style="color:#D84315">PROCESSO: </b><a href="./?nome=' . urlencode($kpi['nome']) . '" style="color:#D84315"><b>' . $i . '.</b> '. $kpi['nome'] .' ' . number_format($kpi['media'], 2, ',', '') . '%</a></li>';
				}
			}
		}

		//QUALIDADE
		$diai = new Datetime('today');
		$diai->modify('-15 days');
		$top = TOP::getTDA2($sql, 2, $diai->format('Y-m-d'), $diaf->format('Y-m-d'), 5);
		$i = 0;

		if(empty($top)) {
			echo '<li class="ticker__item" data-ticker="item"><b style="color:#068434">QUALIDADE: </b><a href="./?nome=" style="color:#068434"><b></b>Calc failed PI.</a></li>';
		}
		else {
			foreach($top as $kpi)
			{
				$i++;
				echo '<li class="ticker__item" data-ticker="item"><b style="color:#D84315">QUALIDADE: </b><a href="./?nome=' . urlencode($kpi['nome']) . '" style="color:#D84315"><b>' . $i . '.</b> '. $kpi['nome'] .' ' . number_format($kpi['media'], 2, ',', '') . '%</a></li>';
			}
		}

		//CONSUMO
		$diai = new Datetime('first day of this month');
		$diaf = new Datetime('last day of this month');
		$top = TOP::getTM($sql, 3, $diai->format('Y-m-d'), $diaf->format('Y-m-d'), 5);
		$i = 0;

		if(empty($top)) {
			echo '<li class="ticker__item" data-ticker="item"><b style="color:#068434">CONSUMO: </b><a href="./?nome=" style="color:#068434"><b></b>Calc failed PI.</a></li>';
		}
		else {
			foreach($top as $kpi)
			{
				$i++;
				echo '<li class="ticker__item" data-ticker="item"><b style="color:#D84315">CONSUMO: </b><a href="./?nome=' . urlencode($kpi['nome']) . '" style="color:#D84315"><b>' . $i . '.</b> '. $kpi['nome'] .' ' . number_format($kpi['media'], 2, ',', '') . '%</a></li>';
			}
		}
	}
	else if($_POST['req'] == 'toplist')
	{
		switch($_POST['area']) {

		case 1:
			$days = $_POST['timerange'];
			$diai = new Datetime('today');
			$diai->modify("-$days days");
			$diaf = new Datetime('today');
			$top = TOP::getTDA1($sql, 1, $diai->format('Y-m-d'), $diaf->format('Y-m-d'), $_POST['limit']);
			break;

		case 2:
			$days = $_POST['timerange'];
			$diai = new Datetime('today');
			$diai->modify("-$days days");
			$diaf = new Datetime('today');
			$top = TOP::getTDA2($sql, 2, $diai->format('Y-m-d'), $diaf->format('Y-m-d'), $_POST['limit']);
			break;

		case 3:
			$months = $_POST['timerange'];
			$diai = new Datetime('today');
			$diai->modify("first day of this month");
			if($months > 0)
					$diai->modify("-$months months");
			$diaf = new Datetime('today');
			$top = TOP::getTM($sql, 3, $diai->format('Y-m-d'), $diaf->format('Y-m-d'), $_POST['limit']);
			break;
		}

		$i = 0;
		if(empty($top)) {
			echo '<div class="top-cell" id="kpi-"><a href="./?nome="><b style="color:red; font-size:1.3vw;"></b><br><p style="color:green; font-size:1.1vw; margin-top:0.5vw">Calc failed PI.</p><br><br>';
			echo '</p></a></div>';
		}
		else {
			foreach($top as $kpi)
			{
				$i++;
				echo '<div class="top-cell" id="kpi-'.$kpi['kpid'].'"><a href="./?nome=' . urlencode($kpi['nome']) . '"><b style="color:red; font-size:1.3vw;">#' . $i . '</b><br><p style="color:green; font-size:1.1vw; margin-top:0.5vw">'. $kpi['nome'] .'</p><br><br>';
				switch ($_POST['area']){
					case 1:
							if($kpi['media'] >= 90)
								echo '<p style="bottom: 5px; right: 5px; position: absolute; font-size:0.9vw; color:#43A047;">' . number_format($kpi['media'], 2, ',', '');
							else if($kpi['media'] >= 80)
								echo '<p style="bottom: 5px; right: 5px; position: absolute; font-size:0.9vw; color:#c4be1f;">' . number_format($kpi['media'], 2, ',', '');
							else
								echo '<p style="bottom: 5px; right: 5px; position: absolute; font-size:0.9vw; color:#ff4d4d;">' . number_format($kpi['media'], 2, ',', '');
							break;
					case 2:
							if($kpi['media'] >= 90)
								echo '<p style="bottom: 5px; right: 5px; position: absolute; font-size:0.9vw; color:#43A047;">' . number_format($kpi['media'], 2, ',', '');
							else if($kpi['media'] >= 80)
								echo '<p style="bottom: 5px; right: 5px; position: absolute; font-size:0.9vw; color:#c4be1f;">' . number_format($kpi['media'], 2, ',', '');
							else
								echo '<p style="bottom: 5px; right: 5px; position: absolute; font-size:0.9vw; color:#ff4d4d;">' . number_format($kpi['media'], 2, ',', '');
							break;
					case 3: 
							if($kpi['media'] >= 0)
								echo '<p style="bottom: 5px; right: 5px; position: absolute; font-size:0.9vw; color:#ff4d4d;">' . number_format($kpi['media'], 2, ',', '');
							else
								echo '<p style="bottom: 5px; right: 5px; position: absolute; font-size:0.9vw; color:#43A047;">' . number_format($kpi['media'], 2, ',', '');
							break;
				}

				echo '%</p></a></div>';
			}
		}
	}
	else if($_POST['req'] == 'topkpi')
	{
		$kpid = $_POST['kpid'];
		$area = TOP::getArea($sql, $kpid);

		if(isset($area))
			$area = $area['area'];
		else
			die;

		$diai = new Datetime('today');
		switch($area)
		{
			case 1:
			$diai->modify("-2 days");
			break;
			case 2:
			$diai->modify("-15 days");
			break;
			case 3:
			$diai->modify("first day of this month");
			break;
		}
		$diaf = new Datetime('today');
		$count = 0;

		$aux = new Datetime('today');
		$aux->modify("first day of this month");
		
		while($aux->format('d') != $diaf->format('d'))
		{
			switch($area)
			{
				case 1:
				$top = TOP::getTDA1($sql, 1, $diai->format('Y-m-d'), $diaf->format('Y-m-d'), 10);
				$diai->modify("-1 day"); $diaf->modify("-1 day");
				break;
				case 2:
				$top = TOP::getTDA2($sql, 2, $diai->format('Y-m-d'), $diaf->format('Y-m-d'), 10);
				$diai->modify("-1 day"); $diaf->modify("-1 day");
				break;
				case 3:
				$top = TOP::getTM($sql, 3, $diai->format('Y-m-d'), $diaf->format('Y-m-d'), 10);
				$diaf->modify('first day of this month');
				break;
			}
			if(empty($top)) {
				//$count = -1;
				break;
			}
			else {
				foreach($top as $kpi)
				{
					if($kpi['kpid'] == $kpid) {
						$count++;
						break;
					}
				}
			}

		}

		if($count == -1)
		echo '<p style="text-align:right">Este KPI ficou <b>Calc failed PI</b> na lista dos Top 10 Indicadores Piores neste mês.</p>
				<br>';
		else if($count == 1 and $area != 3)
			echo '<p style="text-align:right">Este KPI ficou <b style="color:red">#'.$count.'</b> dia na lista dos Top 10 Indicadores Piores neste mês.</p>
				<br>';
		else if($count and $area != 3)
			echo '<p style="text-align:right">Este KPI ficou <b style="color:red">#'.$count.'</b> dias na lista dos Top 10 Indicadores Piores neste mês.</p>
				<br>';
		else if($count)
			echo '<p style="text-align:right">Este KPI <b style="color:red">está</b> na lista dos Top 10 Indicadores Piores neste mês.</p>
				<br>';
		else
			echo '<p style="text-align:right">Este KPI ficou <b style="color:blue">#0</b> dias na lista dos Top 10 Indicadores Piores neste mês.</p>
				<br>';
	}
}