<?php

date_default_timezone_set('America/Sao_Paulo');

//CRIA CONEXÃO GLOBAL COM O BANCO DE DADOS
$sql = new PDO('mysql:host=localhost:3306;dbname=depr;charset=utf8', 'depr', '67ACDEBDAB923990001F0FFB017EB8ED41861105');