<?php
ini_set('display_errors', true);
error_reporting(E_ERROR);
//error_reporting(E_ERROR | E_WARNING | E_PARSE);
if (!empty($_POST))
{
  session_start();
  //echo '<b>Atenção, o sistema encontra-se em desenvolvimento de melhorias, algumas funcionalidades podem estar fora momentaneamente</b>';
  require_once('piwebapi.php');
  require_once('sql.php');
  require_once('hiop.php');

  $nome = $_POST['nome'];

  $kpi = SQL::GetKPI($sql, $nome);
  $kpid = $kpi['id'];
  $paths = PREFIXAF.str_replace(PREFIXAF, '', $kpi['paths']);
  $categoria = $kpi['categoria'];
  $piPointName = str_replace("'", "", $kpi['pipointname']);
  $expressioni = strtoupper(trim($kpi['expressioni']));
  $expressiond = strtoupper(trim($kpi['expressiond']));
  $expressionm = strtoupper(trim($kpi['expressionm']));
  $unit = PIWebAPI::GetAFConstantValue($paths.'|UOM');
  if(!$unit) $unit = $kpi['unit'];
  $calculationbasis = str_replace("-", "", $kpi['calculationbasis']);
  $filter = trim($kpi['filter']);
  $min = $kpi['min'];
  $max = $kpi['max'];

  if(isset($_SESSION[$nome]['filter']))
  {
    if(empty($_SESSION[$nome]['filter']))
      $filter = null;
    else
      $filter = trim($_SESSION[$nome]['filter']);
  }

  $LSE = PIWebAPI::GetAFConstantValue($paths.'|LSE');
  $LIE = PIWebAPI::GetAFConstantValue($paths.'|LIE');
  $Meta = PIWebAPI::GetAFConstantValue($paths.'|Meta');
  if($LIE > 899999) $LIE = null; if($LSE > 899999) $LSE = null; if($Meta > 899999) $Meta = null;

  if(empty($Meta))
    $Meta = 0;

  //Variaveis dinamicas na Formula
  if(!$piPointName)
  {
    $expressioni = str_replace("META", $Meta, $expressioni);
    $expressiond = str_replace("META", $Meta, $expressiond);
    $expressionm = str_replace("META", $Meta, $expressionm);
  }

  if($Meta == 0)
    $Meta = null;

  //KPI INSTANTANEO
  if($_POST['req'] == 'instantaneo')
  {
    $begin = new DateTime($_POST['begin'] . ' midnight'); //Data de hoje - 1 semana
    $end = new DateTime($_POST['end']); //Data do dia de Hoje;
    $end->modify('+1 day midnight');
    $sampling = '1m';
    $i = 0;
    $hiop = Hiop::listaHiopPeriodo($sql, $kpid, $_POST['begin'], $_POST['end'], 'inst');

    echo '<script>';

    echo '$("#meta").html(\'';
    if($Meta) echo '<span style="color:green">Meta: '.$Meta.'</span> | ';
    if($LSE) echo '<span style="color:red">LSE: '.$LSE.'</span> | ';
    if($LIE) echo '<span style="color:red">LIE: '.$LIE.'</span>';
    echo '\');';

    if($piPointName)
      $sampledData =  PIWebAPI::GetCompressedValues($piPointName, $begin->format('c'), $end->format('c'), $filter);
    else if($expressioni)
      $sampledData =  PIWebAPI::GetCalculationExpression($expressioni, $begin->format('c'), $end->format('c'), AVERAGE, $calculationbasis, $sampling);

    if(!$piPointName and !$expressioni):
      echo "$('#instantaneo_classico').html('ESTE KPI NÃO POSSUI DADOS INSTANTÂNEOS.'); $('#instantaneo-check').click();";

    else:
    echo "var data_instantaneo_classico = [
      {
        x: [";
      foreach ($sampledData->Items as $Item){
        if(!$piPointName) $Item = $Item->Value;
        if(is_numeric($Item->Value)) {
          $correctTimezone = new DateTime($Item->Timestamp);
          $correctTimezone->setTimezone(new DateTimeZone('America/Sao_Paulo'));
          echo "'".$correctTimezone->format('c')."',";
        }
      }
    echo "],
        y: [";
      foreach ($sampledData->Items as $Item){
        if(!$piPointName) $Item = $Item->Value;
        if(is_numeric($Item->Value))
          echo $Item->Value.',';
      }
      echo "],
        type: 'scatter'
      }
    ];";

    //LAYOUT
    echo 'var layout_instantaneo = {
      title: "<b>KPI Instantâneo</b> | '.$nome.'", 
      height:350,
      yaxis: {
        autorange:';
        if(empty($min) and empty($max)) echo 'true,'; else echo 'false,';
        echo '
        range: ['.$min.','.$max.'],
        title: "['.$unit.']"
      },
      shapes: [';
      if($LIE) echo '
        {
          type: "line",
          y0:'.$LIE.',
          y1:'.$LIE.',
          xref: "paper",
          x0:0,
          x1:1,
          line: {
            color: "rgb(219, 64, 82)",
            width: 4,
            dash: "dot"
          }
        },';
      if($LSE) echo '
        {
          type: "line",
          y0:'.$LSE.',
          y1:'.$LSE.',
          xref: "paper",
          x0:0,
          x1:1,
          line: {
            color: "rgb(219, 64, 82)",
            width: 4,
            dash: "dot"
          },
        },';
      if($Meta) echo '
        {
          type: "line",
          y0:'.$Meta.',
          y1:'.$Meta.',
          xref: "paper",
          x0:0,
          x1:1,
          line: {
            color: "#00C853",
            width: 4,
            dash: "dashdot"
          },
        }';
echo  ']';
if($hiop) {
  echo ',annotations: [';
  foreach($hiop as $hp) {
    $xaxis = $hp['xaxis'];
    $yaxis = 1.1*$hp['yaxis'];
    $shortdesc = $hp['shortdesc'];
  echo "{
      x: '$xaxis',
      y: $yaxis,
      text: '$shortdesc',
      showarrow: true,
      font: {
        color: '#ffffff',
      },
      align: 'center',
      arrowhead: 2,
      arrowsize: 1,
      arrowwidth: 2,
      arrowcolor: '#636363',
      ax: 10,
      ay: -40,
      bordercolor: '#c7c7c7',
      borderwidth: 2,
      borderpad: 4,
      bgcolor: '#ff7f0e',
      opacity: 0.8,
      captureevents: true
    },";
  }
  echo ']';
}
echo '};';

    echo "Plotly.newPlot('instantaneo_classico', data_instantaneo_classico, layout_instantaneo, layout_options);";

    echo "var instPlot = document.getElementById('instantaneo_classico');
        instPlot.on('plotly_doubleclick', function(data){
          doubleClickTime = new Date();
        });
        instPlot.on('plotly_click', function(data){
          var t0 = new Date();
          if (t0 - doubleClickTime > threshold) {
            setTimeout(function () {
              if (t0 - doubleClickTime > threshold) {
                criarHiop(data.points[0].x, data.points[0].y.toPrecision(4), 'inst');
              }
            },threshold);
          }
        });
        instPlot.on('plotly_clickannotation', function(event, data) {
          listaHiopPeriodo('inst', 0);
          $('#modalHiop').modal();
        });";

    echo "</script>";
  endif;
  }

  //KPI DIARIO
  else if($_POST['req'] == 'diario')
  {
    $begin = new DateTime($_POST['begin'] . ' midnight'); //Data de hoje - 1 mês
    $end = new DateTime($_POST['end'] . ' midnight'); //Data do dia de Hoje
    $end->modify('+1 day');
    $today = new DateTime('now');
    $media = array();
    $desvio = array();
    $cp = array();
    $cpk = array();
    $dia = array();
    $sampling = '10m';
    $i = 0;
    $TOT = strpos($expressiond, 'TOT_D');
    if($TOT) {
      $begin->modify('+1 day');
      $end->modify('+1 day');
      $today->modify('+1 day');
    }
    $aux = clone $begin;
    $hiop = Hiop::listaHiopPeriodo($sql, $kpid, $_POST['begin'], $_POST['end'], 'day');

    if(!$piPointName and !$expressiond):
      echo "<script>$('#diario_classico').html('ESTE KPI NÃO POSSUI DADOS DIÁRIOS.'); $('#diario-check').click(); </script>";

    else:
    echo '<script>';

    for($date = $begin; $date < $end; $date->modify('+1 day')){

      $aux->modify('+1 day');

      if($kpi['lab'])
        $aux->modify('-1 second');

      if($piPointName)
        $compressedValues =  PIWebAPI::GetCompressedValues($piPointName, $date->format('c'), $aux->format('c'), $filter);
      else
        $compressedValues = null;

      if($piPointName and $kpi['lab']) {
        $Items = PIWebAPI::BuildArray($compressedValues->Items);
        $media[$i] = PIWebAPI::GetAverage($Items);
        $desvio[$i] = 0; 
      }
      else if($piPointName and $filter) {
        $media_aux =  PIWebAPI::GetSummaryValues($piPointName, $date->format('c'), $aux->format('c'), AVERAGE, $calculationbasis, '1d', $filter);
        $desvio_aux =  PIWebAPI::GetSummaryValues($piPointName, $date->format('c'), $aux->format('c'), STDEV, $calculationbasis, '1d', $filter);
      } else if ($piPointName) {
        $media_aux =  PIWebAPI::GetCalculationValues($piPointName, $date->format('c'), $aux->format('c'), AVERAGE, $calculationbasis, '1d');
        $desvio_aux =  PIWebAPI::GetCalculationValues($piPointName, $date->format('c'), $aux->format('c'), STDEV, $calculationbasis, '1d');
      } else {
        if($TOT) {
          if(strpos($expressiond, '_D_ANT')) { //FORMULA COM TOT ANT
            $expressiondant = $expressiond;
            $expressiond = str_replace('_ANT', '', $expressiond);
          }
          else { //FORMULA COM TOT SEM ANT
            $expressiondant = str_replace('TOT_D', 'TOT_D_ANT', $expressiond);
          }
          if($date->format('Y-m-d') == $today->format('Y-m-d')) {
            //INSTANTANEO DO DIA
            $media_aux =  PIWebAPI::GetInstCalculationExpression($expressiond, $today->format('c'), AVERAGE, $calculationbasis, null);
            $desvio_aux =  PIWebAPI::GetInstCalculationExpression($expressiond, $today->format('c'), STDEV, $calculationbasis, null);
          } else {
            //TOTALIZADO ANTERIORES
            $media_aux =  PIWebAPI::GetInstCalculationExpression($expressiondant, $date->format('c'), AVERAGE, $calculationbasis, '1d');
            $desvio_aux =  PIWebAPI::GetInstCalculationExpression($expressiondant, $date->format('c'), STDEV, $calculationbasis, '1d');
          }
          $aux2 = clone $date;
          $aux2->modify('-1 day');
          $dia[$i] = $aux2->format('d-M-y');
        }
        else {
          $media_aux =  PIWebAPI::GetCalculationExpression($expressiond, $date->format('c'), $aux->format('c'), AVERAGE, $calculationbasis, '1d');
          $desvio_aux =  PIWebAPI::GetCalculationExpression($expressiond, $date->format('c'), $aux->format('c'), STDEV, $calculationbasis, '1d');
        }
      }

      //RETORNA 0 SE OS VALORES DE MÉDIA NÃO ESTÃO BONS PARA CALCULO
      if(isset($media[$i]))
        $nothing = 0;
      else if(!$media_aux->Items[0]->Value->Good)
        $media[$i] = 0;
      else if($media_aux->Items[0]->Value->Value == null)
        $media[$i] = 0;
      else
        $media[$i] = $media_aux->Items[0]->Value->Value;
      //RETORNA 0 SE OS VALORES DE DESVIO NÃO ESTÃO BONS PARA CALCULO
      if(isset($desvio[$i]))
        $nothing = 0;
      else if(!$desvio_aux->Items[0]->Value->Good)
        $desvio[$i] = 0;
      else if($desvio_aux->Items[0]->Value->Value == null)
        $desvio[$i] = 0;
      else
        $desvio[$i] = $desvio_aux->Items[0]->Value->Value;

      if(!$TOT)
        $dia[$i] = $date->format('d-M-y');

      //CALCULO CP
      if($desvio[$i])
        $cp[$i] = number_format(($LSE - $LIE)/(6*$desvio[$i]),2);
      else $cp[$i] = 0;
      //CALCULO CPK
      if($media[$i] and $desvio[$i])
        $cpk[$i] = number_format(min(($media[$i] - $LIE),($LSE - $media[$i]))/(3*$desvio[$i]),2);
      else $cpk[$i] = 0;

      //ESTETICA
      if($desvio[$i] > $media[$i])
        $desvio[$i] = $media[$i];

    //BOXPLOT
      echo 'var plot_diario'.$i.' = {
          y: [';
    if($compressedValues){
      foreach ($compressedValues->Items as $Value){
        if(is_numeric($Value->Value))
          echo $Value->Value.',';
      }
    }
      echo "],
      type: 'box',
      marker: {
          color: ";
            if (!$LIE and !$LSE) echo "'#43A047',";
            else if ($media[$i] >= $LIE and !$LSE) echo "'#43A047',";
            else if ($media[$i] <= $LSE and !$LIE) echo "'#43A047',";
            else if($media[$i] >= $LIE and $media[$i] <= $LSE) echo "'#43A047',";
            else echo "'rgb(219, 64, 82)',";
        echo "},
        boxpoints: true,
        boxmean: true,
      name : '".$dia[$i]."'};";

      $i++;
    }
    echo 'var data_diario_boxplot = [];';
    for($j = 0; $j < $i; $j++)
    {
      echo 'data_diario_boxplot.push(plot_diario'.$j.');';
    }

    //GRÁFICO DE BARRAS
    echo "var plot_diario = {
      x: [";
      for($j = 0; $j < $i; $j++)
        echo "'".$dia[$j]."',";
      echo "],
      y: [";
      for($j = 0; $j < $i; $j++)
        echo $media[$j].',';
      echo "],
         text: [";
      for($j = 0; $j < $i; $j++)
        echo "'CP: ".$cp[$j]."<br>CPK: ".$cpk[$j]."',";
      echo "],
      type: 'bar',
      error_y: {
        type: 'data',
        array: [";
        for($j = 0; $j < $i; $j++)
          echo $desvio[$j].',';
        echo "],
        visible: true
      },
      marker: {
          color: [";
          for($j = 0; $j < $i; $j++){
            if (!$LIE and !$LSE) echo "'#43A047',";
            else if ($media[$j] >= $LIE and !$LSE) echo "'#43A047',";
            else if ($media[$j] <= $LSE and !$LIE) echo "'#43A047',";
            else if($media[$j] >= $LIE and $media[$j] <= $LSE) echo "'#43A047',";
            else echo "'rgb(219, 64, 82)',";
          }
        echo "]},
    };
    var data_diario_classico = [plot_diario];";


    //LAYOUT
    echo 'var layout_diario = {
      title: "<b>KPI Diário</b> | '.$nome.'", 
      height:400,
      showlegend: false,
      yaxis: {
        autorange:';
        if(empty($min) and empty($max)) echo 'true,'; else echo 'false,';
        echo '
        range: ['.$min.','.$max.'],
        title: "['.$unit.']"
      },
      shapes: [';
      if($LIE) echo '
        {
          type: "line",
          y0:'.$LIE.',
          y1:'.$LIE.',
          xref: "paper",
          x0:0,
          x1:1,
          line: {
            color: "rgb(219, 64, 82)",
            width: 4,
            dash: "dot"
          }
        },';
      if($LSE) echo '
        {
          type: "line",
          y0:'.$LSE.',
          y1:'.$LSE.',
          xref: "paper",
          x0:0,
          x1:1,
          line: {
            color: "rgb(219, 64, 82)",
            width: 4,
            dash: "dot"
          },
        },';
      if($Meta) echo '
        {
          type: "line",
          y0:'.$Meta.',
          y1:'.$Meta.',
          xref: "paper",
          x0:0,
          x1:1,
          line: {
            color: "#00C853",
            width: 4,
            dash: "dashdot"
          },
        }';
echo  ']};';

echo 'var layout_diario_hiop = Object.assign({}, layout_diario);
      layout_diario_hiop.annotations = [';
if($hiop) {
  foreach($hiop as $hp) {
    $xaxis = new DateTime($hp['xaxis']);
    $xaxis = $xaxis->format('d-M-y');
    $yaxis = 1.1*$hp['yaxis'];
    $shortdesc = $hp['shortdesc'];
  echo "{
      x: '$xaxis',
      y: $yaxis,
      text: '$shortdesc',
      showarrow: true,
      font: {
        color: '#ffffff',
      },
      align: 'center',
      arrowhead: 2,
      arrowsize: 1,
      arrowwidth: 2,
      arrowcolor: '#636363',
      ax: 0,
      ay: -50,
      bordercolor: '#c7c7c7',
      borderwidth: 2,
      borderpad: 4,
      bgcolor: '#ff7f0e',
      opacity: 0.8,
      captureevents: true
    },";
  }
}
echo '];';

    echo "Plotly.newPlot('diario_classico', data_diario_classico, layout_diario_hiop, layout_options);";
    echo "Plotly.newPlot('diario_boxplot', data_diario_boxplot, layout_diario, layout_options);";

    echo 'document.getElementById("diario_boxplot").style.display = "none";';

    echo "var dayPlot = document.getElementById('diario_classico');
        dayPlot.on('plotly_doubleclick', function(data){
          doubleClickTime = new Date();
        });
        dayPlot.on('plotly_click', function(data){
          var t0 = new Date();
          if (t0 - doubleClickTime > threshold) {
            setTimeout(function () {
              if (t0 - doubleClickTime > threshold) {
                criarHiop(data.points[0].x, data.points[0].y.toPrecision(4), 'day');
              }
            },threshold);
          }
        });
        dayPlot.on('plotly_clickannotation', function(event, data) {
          listaHiopPeriodo('day', 0);
          $('#modalHiop').modal();
        });";

    echo '</script>';

    endif;
  }

  //KPI MENSAL
  else if($_POST['req'] == 'mensal')
  {
    $begin = new DateTime($_POST['begin'] . ' midnight'); $begin->modify('first day of this month');
    $end = new DateTime($_POST['end'] . ' midnight'); $end->modify('first day of this month');
    $today = new DateTime('now');
    if($_SESSION['endm'])
      $end->modify('+1 month');
    $_SESSION['endm'] = true; //PROBLEM EXTRA MONTH
    $media = array();
    $desvio = array();
    $mes = array();
    $sampling = '1h';
    $i = 0;
    $TOT = strpos($expressionm, 'TOT_M');
    if($TOT) {
      $begin->modify('+1 month');
      $end->modify('+1 month');
      $today->modify('+1 month');
    }
    $aux = clone $begin;
    $year = date('Y');
    $thisYear = new DateTime('first day of January ' . $year . ' midnight');
    $previousYear = date('Y',strtotime('-2 year'));
    $lastYear = date('Y',strtotime('-1 year'));
    if($begin->format('Y') != $previousYear) $previousYear = null;
    $hiop = Hiop::listaHiopPeriodo($sql, $kpid, $_POST['begin'], $_POST['end'], 'month');
    $hiopd = Hiop::listaHiopPeriodo($sql, $kpid, $_POST['begin'], $_POST['end'], 'day');

    if(!$piPointName and !$expressionm):
      echo "<script>$('#mensal_classico').html('ESTE KPI NÃO POSSUI DADOS MENSAIS.'); $('#mensal-check').click();</script>";

    else:
    echo '<script>';
    for($date = $begin; $date < $end; $date->modify('+1 month')){
        
      $aux->modify('+1 month');

      if($piPointName and $kpi['lab'])
        $recordedData =  PIWebAPI::GetCompressedValues($piPointName, $date->format('c'), $aux->format('c'), $filter);
      else if($piPointName)
        $recordedData =  PIWebAPI::GetInterpolatedValues($piPointName, $date->format('c'), $aux->format('c'), $sampling, $filter);
      else
        $recordedData = null;

      if($piPointName and $kpi['lab']) {
        $Items = PIWebAPI::BuildArray($recordedData->Items);
        $media[$i] = PIWebAPI::GetAverage($Items);
        $desvio[$i] = PIWebAPI::GetStdev($Items);
      }
      else if($piPointName and $filter) {
        $media_aux =  PIWebAPI::GetSummaryValues($piPointName, $date->format('c'), $aux->format('c'), AVERAGE, $calculationbasis, $date->diff($aux)->format('%a').'d', $filter);
        $desvio_aux =  PIWebAPI::GetSummaryValues($piPointName, $date->format('c'), $aux->format('c'), STDEV, $calculationbasis, $date->diff($aux)->format('%a').'d', $filter);
      } else if($piPointName) {
        $media_aux =  PIWebAPI::GetCalculationValues($piPointName, $date->format('c'), $aux->format('c'), AVERAGE, $calculationbasis, $date->diff($aux)->format('%a').'d');
        $desvio_aux =  PIWebAPI::GetCalculationValues($piPointName, $date->format('c'), $aux->format('c'), STDEV, $calculationbasis, $date->diff($aux)->format('%a').'d');
      } else if ($TOT) {  //TOTALIZADORES
        if(strpos($expressionm, '_M_ANT')) { //FORMULA COM TOT ANT
          $expressionmant = $expressionm;
          $expressionm = str_replace('_ANT', '', $expressionm);
        }
        else { //FORMULA COM TOT SEM ANT
          $expressionmant = str_replace('TOT_M', 'TOT_M_ANT', $expressionm);
        }
        if($date->format('Y-m') == $today->format('Y-m')) {
          //INSTANTANEO DO MES
          $media_aux =  PIWebAPI::GetInstCalculationExpression($expressionm, null, AVERAGE, $calculationbasis, null);
          $desvio_aux =  PIWebAPI::GetInstCalculationExpression($expressionm, null, STDEV, $calculationbasis, null);
        } else {
          //TOTALIZADO ANTERIORES
          $media_aux =  PIWebAPI::GetCalculationExpression($expressionmant, $date->format('c'), $aux->format('c'), AVERAGE, $calculationbasis, '1mo');
          $desvio_aux =  PIWebAPI::GetCalculationExpression($expressionmant, $date->format('c'), $aux->format('c'), STDEV, $calculationbasis, '1mo');
        }
        $aux2 = clone $date;
        $aux2->modify('-1 month');
        $mes[$i] = $aux2->format('M/y');
      }
      else { //SEM TOTALIZADORES
        if($date->format('Y-m') == $today->format('Y-m'))
          $media_aux =  PIWebAPI::GetCalculationExpression($expressionm, $date->format('c'), $today->format('c'), AVERAGE, $calculationbasis, '1d');
        else
          $media_aux =  PIWebAPI::GetCalculationExpression($expressionm, $date->format('c'), $aux->format('c'), AVERAGE, $calculationbasis, '1d');
        $Items = PIWebAPI::BuildArray($media_aux->Items);
        $media[$i] = PIWebAPI::GetAverage($Items);
        $desvio[$i] = PIWebAPI::GetStdev($Items);
      }

      //RETORNA 0 SE OS VALORES DE MÉDIA NÃO ESTÃO BONS PARA CALCULO
      if(isset($media[$i]))
        $nothing = 0;
      else if(!$media_aux->Items[0]->Value->Good)
        $media[$i] = 0;
      else if($media_aux->Items[0]->Value->Value == null)
        $media[$i] = 0;
      else
        $media[$i] = $media_aux->Items[0]->Value->Value;
      //RETORNA 0 SE OS VALORES DE DESVIO NÃO ESTÃO BONS PARA CALCULO
      if(isset($desvio[$i]))
        $nothing = 0;
      else if(!$desvio_aux->Items[0]->Value->Good)
        $desvio[$i] = 0;
      else if($desvio_aux->Items[0]->Value->Value == null)
        $desvio[$i] = 0;
      else
        $desvio[$i] = $desvio_aux->Items[0]->Value->Value;

      if(!$TOT)
        $mes[$i] = $date->format('M/y');

      //CALCULO CP
      if($desvio[$i])
        $cp[$i] = number_format(($LSE - $LIE)/(6*$desvio[$i]),2);
      else $cp[$i] = 0;
      //CALCULO CPK
      if($media[$i] and $desvio[$i])
        $cpk[$i] = number_format(min(($media[$i] - $LIE),($LSE - $media[$i]))/(3*$desvio[$i]),2);
      else $cpk[$i] = 0;

      //ESTETICA
      if($desvio[$i] > $media[$i])
        $desvio[$i] = $media[$i];

      echo 'var plot'.$i.' = {
          y: [';
    if($recordedData){
      foreach ($recordedData->Items as $Value){
        if(is_numeric($Value->Value))
          echo $Value->Value.',';
      }
    }
      echo "],
      type: 'box',
      marker: {
          color: ";
            if (!$LIE and !$LSE) echo "'#43A047',";
            else if ($media[$i] >= $LIE and !$LSE) echo "'#43A047',";
            else if ($media[$i] <= $LSE and !$LIE) echo "'#43A047',";
            else if($media[$i] >= $LIE and $media[$i] <= $LSE) echo "'#43A047',";
            else echo "'rgb(219, 64, 82)',";
        echo "},
        boxpoints: true,
        boxmean: true,
      name : '".$mes[$i]."'};";

      $i++;
    }
    echo 'var data_mensal_boxplot = [];';
    for($j = 0; $j < $i; $j++)
    {
      echo 'data_mensal_boxplot.push(plot'.$j.');';
    }

    $mediaAcumPreviousYear = null; $desvioAcumPreviousYear = null;
    $today = new DateTime('now');

  if($piPointName)
  {
    $mediaAcumYear = PIWebAPI::GetSummaryValues($piPointName, $thisYear->format('Y-m-d\TH:i:s\Z'), $today->format('Y-m-d\TH:i:s\Z'), AVERAGE, $calculationbasis, $thisYear->diff($today)->format('%a').'d', $filter); $mediaAcumYear = $mediaAcumYear->Items[0]->Value->Value;
    $desvioAcumYear = PIWebAPI::GetSummaryValues($piPointName, $thisYear->format('Y-m-d\TH:i:s\Z'), $today->format('Y-m-d\TH:i:s\Z'), STDEV, $calculationbasis, $thisYear->diff($today)->format('%a').'d', $filter); $desvioAcumYear = $desvioAcumYear->Items[0]->Value->Value;

    $mediaAcumLastYear = PIWebAPI::GetSummaryValues($piPointName, $lastYear.'-01-01T00:00:00Z', $year.'-01-01T00:00:00Z', AVERAGE, $calculationbasis, '365d', $filter); $mediaAcumLastYear = $mediaAcumLastYear->Items[0]->Value->Value; 
    $desvioAcumLastYear = PIWebAPI::GetSummaryValues($piPointName, $lastYear.'-01-01T00:00:00Z', $year.'-01-01T00:00:00Z', STDEV, $calculationbasis, '365d', $filter); $desvioAcumLastYear = $desvioAcumLastYear->Items[0]->Value->Value;

    if($previousYear) {
      $mediaAcumPreviousYear = PIWebAPI::GetSummaryValues($piPointName, $previousYear.'-01-01T00:00:00Z', $lastYear.'-01-01T00:00:00Z', AVERAGE, $calculationbasis, '365d', $filter); $mediaAcumPreviousYear = $mediaAcumPreviousYear->Items[0]->Value->Value;
      $desvioAcumPreviousYear = PIWebAPI::GetSummaryValues($piPointName, $previousYear.'-01-01T00:00:00Z', $lastYear.'-01-01T00:00:00Z', STDEV, $calculationbasis, '365d', $filter); $desvioAcumPreviousYear = $desvioAcumPreviousYear->Items[0]->Value->Value;
    }
  }
  else if ($TOT)
  {
    $thisYear->modify('+1 month');
    $today->modify('first day of this month midnight +1 month');

    $mediaAcumYear = PIWebAPI::GetCalculationExpression($expressionmant, $thisYear->format('Y-m-d\TH:i:s\Z'), $today->format('Y-m-d\TH:i:s\Z'), AVERAGE, $calculationbasis, '1mo');
    $Items = PIWebAPI::BuildArray($mediaAcumYear->Items);
    $mediaAcumYear = PIWebAPI::GetAverage($Items);
    $desvioAcumYear = PIWebAPI::GetStdev($Items);

    $mediaAcumLastYear = PIWebAPI::GetCalculationExpression($expressionmant, $lastYear.'-02-01T00:00:00Z', $year.'-02-01T00:00:00Z', AVERAGE, $calculationbasis, '1mo');
    $Items = PIWebAPI::BuildArray($mediaAcumLastYear->Items);
    $mediaAcumLastYear = PIWebAPI::GetAverage($Items);
    $desvioAcumLastYear = PIWebAPI::GetStdev($Items);

    if($previousYear) {
    $mediaAcumPreviousYear = PIWebAPI::GetCalculationExpression($expressionmant, $previousYear.'-02-01T00:00:00Z', $lastYear.'-02-01T00:00:00Z', AVERAGE, $calculationbasis, '1mo');
    $Items = PIWebAPI::BuildArray($mediaAcumPreviousYear->Items);
    $mediaAcumPreviousYear = PIWebAPI::GetAverage($Items);
    $desvioAcumPreviousYear = PIWebAPI::GetStdev($Items);

    }
  }
  else
  {
    $mediaAcumYear = PIWebAPI::GetCalculationExpression($expressionm, $thisYear->format('c'), $today->format('c'), AVERAGE, $calculationbasis, $thisYear->diff($today)->format('%a').'d'); $mediaAcumYear = $mediaAcumYear->Items[0]->Value->Value;
    $desvioAcumYear = PIWebAPI::GetCalculationExpression($expressionm, $thisYear->format('c'), $today->format('c'), STDEV, $calculationbasis, $thisYear->diff($today)->format('%a').'d'); $desvioAcumYear = $desvioAcumYear->Items[0]->Value->Value;
    $mediaAcumLastYear = PIWebAPI::GetCalculationExpression($expressionm, $lastYear.'-01-01T00:00:00Z', $year.'-01-01T00:00:00Z', AVERAGE, $calculationbasis, '365d'); $mediaAcumLastYear = $mediaAcumLastYear->Items[0]->Value->Value; //ArcMaxCollect exceed
    $desvioAcumLastYear = PIWebAPI::GetCalculationExpression($expressionm, $lastYear.'-01-01T00:00:00Z', $year.'-01-01T00:00:00Z', STDEV, $calculationbasis, '365d'); $desvioAcumLastYear = $desvioAcumLastYear->Items[0]->Value->Value;

    if($previousYear) {
    $mediaAcumPreviousYear = PIWebAPI::GetCalculationExpression($expressionm, $previousYear.'-01-01T00:00:00Z', $lastYear.'-01-01T00:00:00Z', AVERAGE, $calculationbasis, '365d'); $mediaAcumPreviousYear = $mediaAcumPreviousYear->Items[0]->Value->Value;
    $desvioAcumPreviousYear = PIWebAPI::GetCalculationExpression($expressionm, $previousYear.'-01-01T00:00:00Z', $lastYear.'-01-01T00:00:00Z', STDEV, $calculationbasis, '365d'); $desvioAcumPreviousYear = $desvioAcumPreviousYear->Items[0]->Value->Value;
    }
  }

    //ESTETICA
    if($desvioAcumLastYear > $mediaAcumLastYear)
      $desvioAcumLastYear = $mediaAcumLastYear;
    if($desvioAcumYear > $mediaAcumYear)
      $desvioAcumYear = $mediaAcumYear;
    if($previousYear && $desvioAcumPreviousYear > $mediaAcumPreviousYear)
      $desvioAcumPreviousYear = $mediaAcumPreviousYear;

    //BOXPLOT
    if($piPointName) {
      echo "var plotAcumYear = {
            y: [".($mediaAcumYear-$desvioAcumYear).",".$mediaAcumYear.",".($mediaAcumYear+$desvioAcumYear)."],
        type: 'box',
        marker: {
            color: '#757575'
          },
        name : 'Acum. ".$year."'};";

      echo "var plotAcumLastYear = {
            y: [".($mediaAcumLastYear-$desvioAcumLastYear).",".$mediaAcumLastYear.",".($mediaAcumLastYear+$desvioAcumLastYear)."],
        type: 'box',
        marker: {
            color: '#757575'
          },
        name : 'Acum. ".$lastYear."'};";

      echo 'data_mensal_boxplot.push(plotAcumYear);data_mensal_boxplot.push(plotAcumLastYear);';

      if($previousYear) {
        echo "var plotAcumPreviousYear = {
              y: [".($mediaAcumPreviousYear-$desvioAcumPreviousYear).",".$mediaAcumPreviousYear.",".($mediaAcumPreviousYear+$desvioAcumPreviousYear)."],
          type: 'box',
          marker: {
              color: '#757575'
            },
          name : 'Acum. ".$previousYear."'};";
          echo 'data_mensal_boxplot.push(plotAcumPreviousYear);';
      }
    }

    //GRÁFICO DE BARRAS
    echo "var plot = {
      x: [";
      for($j = 0; $j < $i; $j++)
        echo "'".$mes[$j]."',";
      echo "'Acum. ".$year."','Acum. ".$lastYear."','Acum. ".$previousYear."'],
      y: [";
      for($j = 0; $j < $i; $j++)
        echo $media[$j].',';
      echo $mediaAcumYear.','.$mediaAcumLastYear.','.$mediaAcumPreviousYear."],
         text: [";
      for($j = 0; $j < $i; $j++)
        echo "'CP: ".$cp[$j]."<br>CPK: ".$cpk[$j]."',";
      echo "],
      type: 'bar',
      error_y: {
        type: 'data',
        array: [";
        for($j = 0; $j < $i; $j++)
          echo $desvio[$j].',';
        echo $desvioAcumYear.','.$desvioAcumLastYear.','.$desvioAcumPreviousYear."],
        visible: true
      },
      marker: {
          color: [";
          for($j = 0; $j < $i; $j++){
            if (!$LIE and !$LSE) echo "'#43A047',";
            else if ($media[$j] >= $LIE and !$LSE) echo "'#43A047',";
            else if ($media[$j] <= $LSE and !$LIE) echo "'#43A047',";
            else if($media[$j] >= $LIE and $media[$j] <= $LSE) echo "'#43A047',";
            else echo "'rgb(219, 64, 82)',";
          }
        echo "'#757575','#757575','#757575']},
    };
    var data_mensal_classico = [plot];";

    //LAYOUT
    echo 'var layout_mensal = {
      title: "<b>KPI Mensal</b> | '.$nome.'", 
      height:450,
      showlegend: false,
      yaxis: {
        autorange:';
        if(empty($min) and empty($max)) echo 'true,'; else echo 'false,';
        echo '
        range: ['.$min.','.$max.'],
        title: "['.$unit.']"
      },
      shapes: [';
      if($LIE) echo '
        {
          type: "line",
          y0:'.$LIE.',
          y1:'.$LIE.',
          xref: "paper",
          x0:0,
          x1:1,
          line: {
            color: "rgb(219, 64, 82)",
            width: 4,
            dash: "dot"
          }
        },';
      if($LSE) echo '
        {
          type: "line",
          y0:'.$LSE.',
          y1:'.$LSE.',
          xref: "paper",
          x0:0,
          x1:1,
          line: {
            color: "rgb(219, 64, 82)",
            width: 4,
            dash: "dot"
          },
        },';
      if($Meta) echo '
        {
          type: "line",
          y0:'.$Meta.',
          y1:'.$Meta.',
          xref: "paper",
          x0:0,
          x1:1,
          line: {
            color: "#00C853",
            width: 4,
            dash: "dashdot"
          },
        }';
echo  ']};';

echo 'var layout_mensal_hiop = Object.assign({}, layout_mensal);
      layout_mensal_hiop.annotations = [';
if($hiop) {
  foreach($hiop as $hp) {
    $xaxis = new DateTime($hp['xaxis']);
    $xaxis = $xaxis->format('M\/y');
    $yaxis = 1.1*$hp['yaxis'];
    $shortdesc = $hp['shortdesc'];
  echo "{
      x: '$xaxis',
      y: $yaxis,
      text: '$shortdesc',
      showarrow: true,
      font: {
        color: '#ffffff',
      },
      align: 'center',
      arrowhead: 2,
      arrowsize: 1,
      arrowwidth: 2,
      arrowcolor: '#636363',
      ax: 0,
      ay: -50,
      bordercolor: '#c7c7c7',
      borderwidth: 2,
      borderpad: 4,
      bgcolor: '#ff7f0e',
      opacity: 0.8,
      captureevents: true
    },";
  }
}
if($hiopd) {
  $lastmo = 0;
  foreach($hiopd as $hp) {
    $xaxis = new DateTime($hp['xaxis']);
    $xaxis = $xaxis->format('M\/y');
    if(strcmp($lastmo, $xaxis)) {
    $yaxis = 1.1*$hp['yaxis'];
    echo "{
        x: '$xaxis',
        y: $yaxis,
        text: '<b> + </b>',
        showarrow: true,
        font: {
          color: '#ffffff',
          size: 14
        },
        align: 'center',
        arrowhead: 2,
        arrowsize: 1,
        arrowwidth: 2,
        arrowcolor: '#636363',
        ax: 0,
        ay: -30,
        bordercolor: '#c7c7c7',
        borderwidth: 2,
        borderpad: 5,
        bgcolor: '#ff7f0e',
        opacity: 0.8,
        captureevents: true
      },";
      $lastmo = $xaxis;
    }
  }
}
echo '];';

    echo "Plotly.newPlot('mensal_classico', data_mensal_classico, layout_mensal_hiop, layout_options);";
    echo "Plotly.newPlot('mensal_boxplot', data_mensal_boxplot, layout_mensal, layout_options);";

    echo 'document.getElementById("mensal_boxplot").style.display = "none";';

    echo "var monthPlot = document.getElementById('mensal_classico');
        monthPlot.on('plotly_doubleclick', function(data){
          doubleClickTime = new Date();
        });
        monthPlot.on('plotly_click', function(data){
          var t0 = new Date();
          if (t0 - doubleClickTime > threshold) {
            setTimeout(function () {
              if (t0 - doubleClickTime > threshold) {
                criarHiop(data.points[0].x, data.points[0].y.toPrecision(4), 'month');
              }
            },threshold);
          }
        });
        monthPlot.on('plotly_clickannotation', function(event, data) {
          console.log(event);
          listaHiopPeriodo('month', event.annotation.x);
          $('#modalHiop').modal();
        });";

    echo '</script>';
    endif;
  }
  else
  {
    echo 'ERRO: TIPO DE REQUISIÇÃO (INSTANTANEO, DIARIO, MENSAL) NÃO INFORMADA.';
  }
}
else
{
  echo 'ERRO: PARÂMETRO POST NÃO INFORMADO';
}
