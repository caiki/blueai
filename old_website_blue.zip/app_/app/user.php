<?php

class User
{
	public static function checkID($sql, $id)
	{
		$query = $sql->prepare("SELECT * FROM users WHERE id = ?");
		$query->bindParam(1, $id);
		$query->execute();
		return $query->fetch();
	}

	public static function createID($sql, $id)
	{
		$query = $sql->prepare("INSERT INTO users (id) VALUES (?)"); 
		$query->bindParam(1, $id);
		return $query->execute(); 
	}

	public static function updateUser($sql, $id, $firstname, $lastname, $email, $pref, $freq)
	{
		$query = $sql->prepare("UPDATE users SET firstname = ?, lastname = ?, email = ?, pref = ?, freq = ? WHERE id = ?"); 
		$query->bindParam(1, $firstname);
		$query->bindParam(2, $lastname);
		$query->bindParam(3, $email);
		$query->bindParam(4, $pref);
		$query->bindParam(5, $freq);
		$query->bindParam(6, $id);
		$query->execute(); 
	}

	public static function getAll($sql)
	{
		$query = $sql->prepare("SELECT * FROM users");
		$query->execute();
		$rows = array();
		while($row = $query->fetch(PDO::FETCH_ASSOC))
		{
			$rows[] = $row;
		} 
		return $rows;
	}

	public static function updateCheck($sql, $id, $check)
	{
		$query = $sql->prepare("UPDATE users SET users.check = ? WHERE id = ?"); 
		$query->bindParam(1, $check);
		$query->bindParam(2, $id);
		$query->execute(); 
	}

}

if(isset($_POST['req']))
{
	require_once('sql.php');
	if($_POST['req'] == 'userpref')
	{
		$id = $_POST['id'];
		$firstname = $_POST['firstname'];
		$lastname = $_POST['lastname'];
		$email = $_POST['email'];
		if(isset($_POST['pref'])) $pref = $_POST['pref']; else $pref = null;
		if(isset($_POST['freq'])) $freq = $_POST['freq']; else $freq = null;

		if(!User::checkID($sql, $id))
			User::createID($sql, $id);

		if(!$pref or !$freq)
		{
			$pref = null;
			$freq = null;
		}

		if($pref)
			User::updateUser($sql, $id, $firstname, $lastname, $email, serialize($pref), serialize($freq));
		else
			User::updateUser($sql, $id, $firstname, $lastname, $email, null, null);

		header('Location:../?req=usr&swal');
		die();
	}
}