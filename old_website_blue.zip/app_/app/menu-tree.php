<?php
    error_reporting(E_ERROR | E_WARNING | E_PARSE);
    require_once('sql.php');
    //$string3 = 'Qualidade\Linha Patibras\Temperatura No Passa\Bacana\Variável aqui';

    $flag = false;

    if(isset($_POST['path'])) {
        $thiskpi = $_POST['path'];
        $flag = true;
    }

    $paths = SQL::GetAllPaths($sql);
    //$paths[$string3] = $string3; //PROVISORIO
    $tree = explodeTree($paths, '\\');
    $i = 0;
    plotTree($tree);
    //https://codepen.io/anon/pen/jKZywP#anon-login
    //http://kvz.io/blog/2007/10/03/convert-anything-to-tree-structures-in-php/
    function explodeTree($array, $delimiter = '_', $baseval = false)
    {
        if(!is_array($array)) return false;
        $splitRE   = '/' . preg_quote($delimiter, '/') . '/';
        $returnArr = array();
        foreach ($array as $key => $val) {
            // Get parent parts and the current leaf
            $parts  = preg_split($splitRE, $key, -1, PREG_SPLIT_NO_EMPTY);
            $leafPart = array_pop($parts);

            // Build parent structure
            // Might be slow for really deep and large structures
            $parentArr = &$returnArr;
            foreach ($parts as $part) {
                if (!isset($parentArr[$part])) {
                    $parentArr[$part] = array();
                } elseif (!is_array($parentArr[$part])) {
                    if ($baseval) {
                        $parentArr[$part] = array('__base_val' => $parentArr[$part]);
                    } else {
                        $parentArr[$part] = array();
                    }
                }
                $parentArr = &$parentArr[$part];
            }

            // Add the final part to the structure
            if (empty($parentArr[$leafPart])) {
                $parentArr[$leafPart] = $val;
            } elseif ($baseval && is_array($parentArr[$leafPart])) {
                $parentArr[$leafPart]['__base_val'] = $val;
            }
        }
        return $returnArr;
    }
    function plotTree($arr, $indent=0, $mother_run=true){

        if ($mother_run) {
            // the beginning of plotTree. We're at rootlevel
            echo '<div id="tree">';
            echo '<ul class="tree">';
        }

        global $i;
        foreach ($arr as $k=>$v){
            $i++;
            // skip the baseval thingy. Not a real node.
            if ($k == "__base_val") continue;
            // determine the real value of this node.
            $show_val = (is_array($v) ? $v["__base_val"] : $v);
            // show the indents
            echo str_repeat("  ", $indent);
            if ($indent == 0) {
                // this is a root node. no parents
                if($k == 'Custo')
                    $k = 'Consumo';
                echo '<li><input type="checkbox" checked="checked" id="c'.$i.'" />
                      <label class="tree_label" for="c'.$i.'">'.$k.'</label>
                      <ul>';
            } elseif (is_array($v)){
                // this is a normal node. parents and children
                echo '  <li>
                            <input type="checkbox" id="c'.$i.'" />
                            <label for="c'.$i.'" class="tree_label">'.$k.'</label>
                            <ul>';
            } else {
                // this is a leaf node. no children
                echo '          <li><a href="./?nome=undefined&path='.urlencode($k).'"><span class="tree_label">'.$k.'</span></a></li>';

                if($GLOBALS['flag']) {
                    if($k == $GLOBALS['thiskpi'])
                        $GLOBALS['flag'] = false;
                    else
                        $GLOBALS['prevkpi'] = $k;
                }
                else if (isset($GLOBALS['thiskpi']) AND !isset($GLOBALS['nextkpi'])) {
                    $GLOBALS['nextkpi'] = $k;
                    echo '<script>$("#prevkpi").attr("href", "./?nome=undefined&path='.urlencode($GLOBALS['prevkpi']).'");
                            $("#nextkpi").attr("href", "./?nome=undefined&path='.urlencode($GLOBALS['nextkpi']).'");</script>';
                }
            }

            if (is_array($v)) {
                // this is what makes it recursive, rerun for childs
                plotTree($v, ($indent+1), false);
                echo '</ul>';
            }
        }

        if ($mother_run) {
            echo '</ul>';
            echo '</div>';
        }
    }
?>
<script>
function isNumber(n) {
  return !isNaN(parseFloat(n)) && isFinite(n);
}

function setFontSize(el) {
    var fontSize = el.val();
    
    if ( isNumber(fontSize) && fontSize >= 0.5 ) {
      $('body').css({ fontSize: fontSize + 'em' });
    } else if ( fontSize ) {
      el.val('1');
      $('body').css({ fontSize: '1em' });  
    }
}
</script>