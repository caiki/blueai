<?php

if(!isset($_SESSION)){session_start();}

//LISTA DE ADMINS QUE PODEM ALTERAR OS KPIS DO SISTEMA
$admins = array('rgoulart', 'ebatista', 'tcim00992131', 'crsferreira', 'klfs00130225', 'pcadaval', 'abertolazzo', 'kllo00122859', 'eavm00130822', 'wendelpd', 'klrp00123362', 'ort_kpi_indicadores');

$config = false;

foreach($admins as $admin) {
	if($admin === $_SESSION['username'])
		$config = true;
}