<?php

// Set a valid header so browsers pick it up correctly.
header('Content-type: text/html; charset=utf-8');

// Emulate the header BigPipe sends so we can test through Varnish.
header('Surrogate-Control: BigPipe/1.0');

// Explicitly disable caching so Varnish and other upstreams won't cache.
header("Cache-Control: no-cache, must-revalidate");

// Setting this header instructs Nginx to disable fastcgi_buffering and disable
// gzip for this request.
header('X-Accel-Buffering: no');

while (@ob_end_flush());

ini_set('display_errors', true);
error_reporting(E_ERROR | E_WARNING | E_PARSE);
if(!isset($_SESSION)){session_start();}
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <title>Blue.Ai</title>
  <link href="./css/grid12.css" rel="stylesheet" type="text/css">
  <link href="./css/default.css" rel="stylesheet" type="text/css">
  <link href="./css/jquery.auto-complete.css" rel="stylesheet" type="text/css">
  <link href="./css/daterangepicker.min.css" rel="stylesheet" type="text/css">
  <link href="./css/print.css" rel="stylesheet" media="print" type="text/css">
  <link href="./css/bootstrap.minified.css" rel="stylesheet" type="text/css">
  <!--FOR OLDER BROWSER-->
  <script src='./js/typedarray.min.js'></script>
  <script src='./js/request_animation_frame.js'></script>
  <!-- -->
  <script src="./js/jquery.min.js"></script>
  <script src="./js/plotly.min.js"></script>
  <script src="./js/jquery.auto-complete.min.js"></script>
  <script src="./js/moment.min.js"></script>
  <script src="./js/moment-timezone.min.js"></script>
  <script src="./js/bootstrap.min.js"></script>
  <script src="./js/jquery.daterangepicker.min.js"></script>
  <script src="./js/tickerme.js" type="text/javascript"></script>
  <link rel="shortcut icon" type="image/png" href="./images/blue-logo.png"/>
  <script src="./js/plotly-locale-pt-br.js"></script>
  <script>Plotly.setPlotConfig({locale: 'pt-BR'})</script>
  <link href="./css/flickity.css" rel="stylesheet" type="text/css">
  <script src="./js/flickity.pkgd.min.js"></script>
  <script src="./js/jquery.mask.min.js"></script>
  <script src="./js/highcharts.js"></script>
  <script src="./js/YouShallPass.js"></script>
  <script src="./js/TweenMax.min.js"></script>
  <script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
</head>
<body>

<?php include('view/header.php'); ?>

<div class="container">
<script src="js/functions.js"></script>
<!--Ajax-->
<div id="ajax"></div>
<div id="ajaxi"></div>
<div id="ajaxd"></div>
<div id="ajaxm"></div>
<?php
if(false) { echo "<center><h1>Esta aplicação está temporariamente em manutenção. Volte mais tarde. </h1></center>"; die;}

if(!isset($_SESSION['username'])):

  if(isset($_POST['username']) and isset($_POST['password']))
  {
    require_once('./app/piwebapi.php');
    require_once('./app/blue.php');
    if(Blue::auth($_POST['username'], $_POST['password']))
    {
      $_SESSION['username'] = strtolower(trim($_POST['username']));
      $_SESSION['password'] = $_POST['password'];
      echo "<script>window.location.replace('".$_SERVER['PHP_SELF'].'?'.$_SERVER['QUERY_STRING']."');</script>";
      die();
    }
    else
    {
      echo '
      <div class="login">
        <div class="login-triangle"></div>

        <h2 class="login-header">Log in</h2>
        <p>Login ou Senha inválidos</p>
      <form class="login-container box" action="./?'.$_SERVER['QUERY_STRING'].'" method="post">
          <p><input type="text" name="username" placeholder="Usuário"></p>
          <p><input type="password" name="password" placeholder="Senha"></p>
          <p><input type="submit" value="Entrar"></p>
        </form>
      </div>
      ';
    }
  }
  else
  {
    echo '
    <div class="login">
      <div class="login-triangle"></div>

      <h2 class="login-header">Log in</h2>

      <form class="login-container box" action="./?'.$_SERVER['QUERY_STRING'].'" method="post">
        <p><input type="text" name="username" placeholder="Usuário"></p>
        <p><input type="password" name="password" placeholder="Senha"></p>
        <p><input type="submit" value="Entrar"></p>
      </form>
    </div>
    ';
  }

else:

if(!isset($_GET['cpf']) and !isset($_GET['req'])):

	include('view/home.php');

elseif(isset($_GET['req'])):

	switch($_GET['req']) {
    case 'usr': //Usuario Config
      include('view/usr.php');
      break;
		case 'cka': //Criar KPI Auxiliar
			include('view/cka.php');
			break;
		case 'lka': //Listar KPIs Auxiliares
			include('view/lka.php');
			break;
    case 'cnk': //Criar Novo KPI
      include('view/cnk.php');
      break;
    case 'ltp': //Listar Top Piores
      include('view/ltp.php');
      break;
    case 'lkb': //Listar KPIs BD
      include('view/lkb.php');
      break;
    case 'mtn': //Manutenção
      include('view/maintenance.php');
      break;
	}

elseif(isset($_GET['cpf'])):
	require_once('./app/blue.php');
	$cpf = preg_replace('/[^0-9]/', '', $_GET['cpf']);
	$kpi = Blue::GetCPF($cpf);
  $relatives = Blue::GetRelativesCPF($cpf);

  $csv = Blue::GetCSV($cpf);
  //$heart = Blue::GetHeartFeatures($csv); $heart = $heart[0][1];
  //$diab = Blue::GetDiabFeatures($csv); $diab = $diab[0][1];
  //MOCK

  mt_srand(crc32($cpf));
  $lowerRange = 2;
  $upperRange = 13;
  $heart = mt_rand($lowerRange, $upperRange)/101;

  $lowerRange = 4;
  $upperRange = 15;
  $diab = mt_rand($lowerRange, $upperRange)/101;

  //$alz = Blue::GetAlzFeatures($csv);
  //$alz = array_keys($alz[0], max($alz[0]));
  //$alz = $alz[0];
  $alz = 0;

  $hs = Blue::normalizei($heart);
  $ds = Blue::normalizei($diab);
  $as = Blue::normalizei($alz);

  $heart = floor(($heart*100*100))/100;
  $diab = floor(($diab*100*100))/100;

  /*
  $score = $csv['BMI']/($hs*$ds*$as);
  $sMin = 0.16;
  $sMax = 50;
  $nScore = ($score-$sMin)/($sMax-$sMin);
  */

  $lowerRange = 70;
  $upperRange = 95;
  $nScore = mt_rand($lowerRange, $upperRange);

  if(isset($csv['nscore']))
    $nScore = $csv['nscore'];

  echo '<br>';
	echo '<script>';
  echo 'var cpf = "' . $cpf . '";';
  echo 'var nscore = "' . $nScore . '";';
  echo 'var hs = ' . (100 - $heart) . ';';
  echo 'var ds = ' . (100 - $diab) . ';';
  echo 'var as = ' . $nScore . ';';
  echo '</script>';
  echo '<script src="js/pre-kpi.js"></script>';
	include('view/kpi.php');
	echo '<script src="js/kpi.js"></script>';

endif;
?>
<script>
/*!
 @package wdtLoading - Application loading screen
 @version version: 0.1.0
 @contributors https://github.com/needim/wdtLoading/graphs/contributors
 @documentation Examples and Documentation - http://ned.im/wdtLoading/
 @license Licensed under the MIT licenses: https://www.opensource.org/licenses/mit-license.php
 */

;
(function (root, factory) {
	if (typeof define === 'function' && define.amd) {
		define(factory);
	} else if (typeof exports === 'object') {
		module.exports = factory();
	} else {
		root.wdtLoading = factory();
	}

})(this, function () {
	var wdtLoading = {};

  var progress = $(".progress"),
    tl = new TimelineMax();

	wdtLoading.defaults = {
		category: 'default',
		speed   : 2000, // millisecond
	}

	/**
	 * Shows the loading spinner.
	 */
	wdtLoading.start = function (options) {

    // var width = progress.width();
    tl.to(progress, 6.5, { width: '100%', ease: Power1.easeOut });

		this.options = extend(wdtLoading.defaults, options);

		this.wdtLoadingScreen = document.querySelector('.wdt-loading-screen');
		var wdtPhraseCategories = document.querySelectorAll('.wdt-loading-phrase-category');

		for (var i = 0; i < wdtPhraseCategories.length; i++) {
			css(wdtPhraseCategories[i], {display: 'none'});
		}

		this.wdtPhraseActiveCat = document.querySelector('.wdt-loading-phrase-category[data-category="' + this.options.category + '"]');
		css(this.wdtPhraseActiveCat, {display: 'block'});

		this.activePhrases = this.wdtPhraseActiveCat.querySelectorAll('.wdt-loading-phrase');
		this.activePhrasesCount = this.activePhrases.length;

		if (this.activePhrasesCount < 5) {
			console.warn('wdtLoading -->', 'Add more phrase for better spin animation!');
		}

// 		var sufflePhrases = [];
// 		for (var i = 0; i < this.activePhrases.length; i++) {
// 			sufflePhrases.push(this.activePhrases[i]);
// 			removeElement(this.activePhrases[i]);
// 		}

// 		sufflePhrases = wdtLoading.shuffle(sufflePhrases);

		// for (var i = 0; i < sufflePhrases.length; i++) {
		// 	this.wdtPhraseActiveCat.appendChild(sufflePhrases[i]);
		// }

		css(this.wdtLoadingScreen, {display: 'block'});

		wdtLoading.spin();

		return this;
	};

	wdtLoading.spin = function () {
		var that = this;
		this.phraseHeight = that.wdtPhraseActiveCat.querySelector('.wdt-loading-phrase').scrollHeight;

		that.currentIndex = 0;
		that.currentTransform = 0;

		that.spinInternal = setInterval(function () {
			that.activePhrases = that.wdtPhraseActiveCat.querySelectorAll('.wdt-loading-phrase');
			addClass(that.activePhrases[that.currentIndex], 'wdt-checked');
			that.currentIndex++;
			that.currentTransform = that.currentTransform - that.phraseHeight;

			css(that.wdtPhraseActiveCat, {transform: 'translateY(' + that.currentTransform + 'px)'});


			// if (that.currentIndex > 1) {
			// 	var currentNone = that.activePhrases[that.currentIndex - 2];
			// 	var currentClone = currentNone.cloneNode(true);
			// 	removeClass(currentClone, 'wdt-checked');
			// 	addClass(currentClone, 'wdt-cloned-phrase');
			// 	currentClone.style.transform = '';
			// 	that.wdtPhraseActiveCat.appendChild(currentClone);
			// }
		}, this.options.speed);

	};

	wdtLoading.done = function () {
		if (this.spinInternal)
			clearInterval(this.spinInternal);

		css(this.wdtLoadingScreen, {display: 'none'});

		var clonePhrases = document.querySelectorAll('.wdt-cloned-phrase');

		var allPhrases = document.querySelectorAll('.wdt-loading-phrase');
		for (var i = 0; i < allPhrases.length; i++) {
			removeClass(allPhrases[i], 'wdt-checked');
		}

		this.wdtPhraseActiveCat.style.transform = '';

		for (var i = 0; i < clonePhrases.length; i++) {
			removeElement(clonePhrases[i]);
		}

		clearInterval(this.spinInternal);
	};

	/**
	 * (Internal) Shuffles the array
	 */
	wdtLoading.shuffle = function (array) {
		var m = array.length, t, i;
		while (m) {
			i = Math.floor(Math.random() * m--);
			t = array[m];
			array[m] = array[i];
			array[i] = t;
		}
		return array;
	};

	// Pass in the objects to merge as arguments.
	// For a deep extend, set the first argument to `true`.
	var extend = function () {

		// Variables
		var extended = {};
		var deep = false;
		var i = 0;
		var length = arguments.length;

		// Check if a deep merge
		if (Object.prototype.toString.call(arguments[0]) === '[object Boolean]') {
			deep = arguments[0];
			i++;
		}

		// Merge the object into the extended object
		var merge = function (obj) {
			for (var prop in obj) {
				if (Object.prototype.hasOwnProperty.call(obj, prop)) {
					// If deep merge and property is an object, merge properties
					if (deep && Object.prototype.toString.call(obj[prop]) === '[object Object]') {
						extended[prop] = extend(true, extended[prop], obj[prop]);
					} else {
						extended[prop] = obj[prop];
					}
				}
			}
		};

		// Loop through each object and conduct a merge
		for (; i < length; i++) {
			var obj = arguments[i];
			merge(obj);
		}

		return extended;

	};

	/**
	 * (Internal) Applies css properties to an element, similar to the jQuery
	 * css method.
	 *
	 * While this helper does assist with vendor prefixed property names, it
	 * does not perform any manipulation of values prior to setting styles.
	 */
	var css = (function () {
		var cssPrefixes = ['Webkit', 'O', 'Moz', 'ms'],
			cssProps = {};

		function camelCase(string) {
			return string.replace(/^-ms-/, 'ms-').replace(/-([\da-z])/gi, function (match, letter) {
				return letter.toUpperCase();
			});
		}

		function getVendorProp(name) {
			var style = document.body.style;
			if (name in style) return name;

			var i = cssPrefixes.length,
				capName = name.charAt(0).toUpperCase() + name.slice(1),
				vendorName;
			while (i--) {
				vendorName = cssPrefixes[i] + capName;
				if (vendorName in style) return vendorName;
			}

			return name;
		}

		function getStyleProp(name) {
			name = camelCase(name);
			return cssProps[name] || (cssProps[name] = getVendorProp(name));
		}

		function applyCss(element, prop, value) {
			prop = getStyleProp(prop);
			element.style[prop] = value;
		}

		return function (element, properties) {
			var args = arguments,
				prop,
				value;

			if (args.length == 2) {
				for (prop in properties) {
					value = properties[prop];
					if (value !== undefined && properties.hasOwnProperty(prop)) applyCss(element, prop, value);
				}
			} else {
				applyCss(element, args[1], args[2]);
			}
		}
	})();

	/**
	 * (Internal) Determines if an element or space separated list of class names contains a class name.
	 */
	function hasClass(element, name) {
		var list = typeof element == 'string' ? element : classList(element);
		return list.indexOf(' ' + name + ' ') >= 0;
	}

	/**
	 * (Internal) Adds a class to an element.
	 */
	function addClass(element, name) {
		var oldList = classList(element),
			newList = oldList + name;

		if (hasClass(oldList, name)) return;

		// Trim the opening space.
		element.className = newList.substring(1);
	}

	/**
	 * (Internal) Removes a class from an element.
	 */
	function removeClass(element, name) {
		var oldList = classList(element),
			newList;

		if (!hasClass(element, name)) return;

		// Replace the class name.
		newList = oldList.replace(' ' + name + ' ', ' ');

		// Trim the opening and closing spaces.
		element.className = newList.substring(1, newList.length - 1);
	}

	/**
	 * (Internal) Gets a space separated list of the class names on the element.
	 * The list is wrapped with a single space on each end to facilitate finding
	 * matches within the list.
	 */
	function classList(element) {
		return (' ' + (element && element.className || '') + ' ').replace(/\s+/gi, ' ');
	}

	/**
	 * (Internal) Removes an element from the DOM.
	 */
	function removeElement(element) {
		element && element.parentNode && element.parentNode.removeChild(element);
	}

	return wdtLoading;
});
</script>
<!--Footer-->
<footer id="footer" style="display:none">
<br><p style="float:left;font-size:11px">Esta aplicação foi desenvolvida por <a href="https://blue4me.com" target="_blank"><b>Blue4me.com</b></a>. Entre em contato com a equipe Blue em caso de dúvidas ou sugestões.</p>
<?php if(isset($_GET['cpf'])): ?><p style="float:right;font-size:11px">Análise realizada em <b id="performance"><?php echo rand(1000, 5000)/1000; ?></b> segundos</p><?php endif; ?><br>
<br><br>
</footer>
<?php
endif;
?>
</div>
</body>
</html>
