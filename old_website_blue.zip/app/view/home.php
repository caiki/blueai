<link href="./css/busca.css" rel="stylesheet" type="text/css">
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js"></script>

<center><h1>Bem-Vindo à nova ferramenta Blue.Ai</h1></center>
<center>

  <form id="search1">
    <h4>Digite o CPF do paciente abaixo:</h4>
    <br>
    <input type="search" placeholder="Busca inteligente" name="busca" id="passwd1">
  </form>
  <h4>Toma medicamento para hipertensão?</h4>
  <br>
  <form id="search1">
    <label class="radio-inline">
      <input type="radio" name="medicado" value="sim"> Sim <br>
    </label>
    <label class="radio-inline">
      <input type="radio" name="medicado" value="não"> Não <br>
    </label>
  </form>
  <h4>Qual é o seu peso? (Kg)</h4>
  <br>
  <form id="search1">
    <input type="search" placeholder="Busca inteligente" name="busca" id="passwd1">
  </form>
  <h4>Qual é a sua estatura? (cm)</h4>
  <br>
  <form id="search1">
    <input type="search" placeholder="Busca inteligente" name="busca" id="passwd1">
  </form>
  <h4>Quantas frutas por dia você consome?</h4>
  <br>
  <form id="search1">
    <input type="search" placeholder="Busca inteligente" name="busca" id="passwd1">
  </form>
  <h4>Quantas horas por semana faz atividade física?</h4>
  <br>
  <form id="search1">
    <input type="search" placeholder="Busca inteligente" name="busca" id="passwd1">
  </form>
</center>
<br />
<br />
<p style="position:fixed; left:10px; bottom:30px; font-size:11px">Esta aplicação foi desenvolvida por <a href="https://blue4me.com" target="_blank"><b>Blue4me.com</b></a>. Entre em contato com a equipe Blue em caso de dúvidas ou sugestões.</p>
<br>
<script src="./js/busca-inteligente.js"></script>
<style>footer {display:none;}</style>
